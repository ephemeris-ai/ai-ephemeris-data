# swetest.php Pure PHP Preview

Version **0.1.3-preview** (2026-07-10). See `CHANGELOG.md` for release notes.

`swetest.php` is an experimental, astrology-focused PHP implementation around
Swiss Ephemeris `.se1` files. It is meant for environments where the official
`swetest` executable, a DLL, a PHP extension, or FFI cannot be used.

This package is not a complete replacement for the official Swiss Ephemeris C
library. It is a small, practical runtime extracted from the On-line Astrology
project and focused on the chart-calculation workflow used there.

## What It Does

- Reads Swiss Ephemeris `.se1` files directly from PHP.
- Calculates apparent geocentric ecliptic longitude, latitude, distance, and
  daily longitude speed for common astrology bodies.
- Supports tropical positions and Lahiri sidereal mode.
- Supports Sun, Moon, Mercury through Pluto, mean and true lunar node, mean and
  osculating lunar apogee, Earth, Chiron, Pholus, Ceres, Pallas, Juno, and Vesta
  when the required ephemeris files are available.
- Provides a small `swetest`-style query interface and array-based PHP helper
  functions.
- Optionally calculates houses through `swetest_sweph_extra.php`.
- Runs without external processes, native binaries, PHP extensions, DLLs, or FFI.

## What It Does Not Do

- It does not implement the full Swiss Ephemeris C API.
- It does not include eclipse, occultation, rise/set, heliacal, or full asteroid
  catalogue workflows.
- It does not bundle Swiss Ephemeris `.se1` data files.
- It is not a legal or licensing wrapper around Swiss Ephemeris. You are
  responsible for choosing and following the correct Swiss Ephemeris license.

## Package Contents

The release ZIP should contain:

- `src/swetest.php` - core pure PHP `.se1` reader and astrology calculator.
- `src/swetest_sweph_extra.php` - optional houses, time, and compatibility
  helpers used by `swetest_full_chart()`.
- `src/swetest_fixstars.php` - optional fixed-star helper.
- `examples/quickstart.php` - minimal PHP example.
- `ephe/` - empty placeholder directory for user-supplied `.se1` files.
- `CHANGELOG.md` - release notes.
- `LICENSE.md` - license references and project-operator license note.
- `NOTICE.md` - licensing and attribution notes.
- `README.md` - this file.

The release ZIP intentionally does not contain:

- `swetest.exe` or `swetest64.exe`
- Swiss Ephemeris `.se1` files
- private application configuration
- On-line Astrology user data or logs

## Requirements

- PHP 7.4 or newer is required. The package is currently tested with PHP 7.4.6.
- PHP 7.3 and older are not supported, because the source uses PHP 7.4 syntax
  such as typed properties and arrow functions.
- The PHP runtime must be allowed to read local files.
- Swiss Ephemeris `.se1` files must be placed in a directory you control.

## Ephemeris Files

Download Swiss Ephemeris data files from the official Astrodienst distribution:

- https://www.astro.com/ftp/swisseph/
- https://www.astro.com/swisseph/swedownload_e.htm

Put the needed `.se1` files into `ephe/`, or pass a custom directory to the
helper functions.

For common natal-chart work, you will usually need planetary and lunar files
whose names begin with `sepl` and `semo`. If you calculate Chiron, Pholus,
Ceres, Pallas, Juno, Vesta, or other asteroid-like bodies, you also need the
corresponding asteroid files.

## Quick Start

```php
<?php
require_once __DIR__ . '/src/swetest.php';

$epheDir = __DIR__ . '/ephe';

$chart = swetest_full_chart([
    'date' => '24.1.1963',
    'ut' => '02:06',
    'bodies' => '0123456789mtAB',
    'decimal' => true,
    'house' => [
        'longitude' => 14.42076,
        'latitude' => 50.08804,
        'system' => 'P',
    ],
], $epheDir);

echo json_encode($chart, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
```

You can also use a query string similar to `swetest`:

```php
$rows = swetest_calc('-b24.1.1963 -ut02:06 -p0123456789mt -dec', __DIR__ . '/ephe');
```

Or run the file directly from CLI:

```bash
php src/swetest.php -edir./ephe -b24.1.1963 -ut02:06 -p0123456789mt -fPZls
```

## Body Codes

- `0` Sun
- `1` Moon
- `2` Mercury
- `3` Venus
- `4` Mars
- `5` Jupiter
- `6` Saturn
- `7` Uranus
- `8` Neptune
- `9` Pluto
- `m` mean lunar node
- `t` true lunar node
- `A` mean lunar apogee
- `B` osculating lunar apogee
- `C` Earth
- `D` Chiron
- `E` Pholus
- `F` Ceres
- `G` Pallas
- `H` Juno
- `I` Vesta

## PHP API

### `swetest_calc($input, ?string $epheDir = null): array`

Returns a flat list of calculated body positions.

`$input` can be either an array:

```php
[
    'date' => '24.1.1963',
    'ut' => '02:06',
    'bodies' => '0123456789mt',
    'sidereal' => false,
    'decimal' => true,
]
```

or a compact query string:

```php
'-b24.1.1963 -ut02:06 -p0123456789mt -dec'
```

### `swetest_chart($input, ?string $epheDir = null): array`

Returns:

```php
[
    'positions' => [...],
    'houses' => null // or a house result array
]
```

If a house location is provided, the optional extra module is loaded and house
positions are added to each body.

### `swetest_full_chart($input, ?string $epheDir = null): array`

Alias for the chart workflow used by the On-line Astrology application.

### `swetest_text()` and `swetest_json()`

Convenience wrappers for text and JSON output.

## House Calculation

House calculation requires `src/swetest_sweph_extra.php`, which is loaded
automatically by `swetest_chart()` / `swetest_full_chart()` when house data is
requested.

Array form:

```php
'house' => [
    'longitude' => 14.42076,
    'latitude' => 50.08804,
    'system' => 'P',
]
```

Query-string form:

```text
-house14.42076,50.08804,P
```

## Accuracy And Validation

In July 2026 the port went through an independent line-by-line audit against
the Swiss Ephemeris **2.10.03** C sources (algorithms, constants, and all
numeric tables compared value by value), followed by a numeric verification
against the official `swetest` **2.10.03** binary. The audit was carried out
with Claude (Anthropic) under the project author's direction; the
resulting fixes are included in version 0.1.3-preview.

Measured agreement with the official binary (18 test dates spanning the years
−500 … +2300; Sun–Pluto, lunar nodes and apogees, Chiron–Vesta):

- ecliptic longitude and latitude: within **0.0002"** (the binary's printing
  precision);
- geocentric distance: within 5e-10 AU;
- house cusps, ASC/MC/ARMC (Placidus, Koch, Regiomontanus, Porphyry,
  Whole-sign, Equal; including polar latitudes): within **0.0002"**;
- Lahiri sidereal longitudes: within 0.009" (precomputed ayanamsha tables);
- daily longitude speed: within 1e-4 °/day (speeds are computed by numeric
  differentiation by design, while the C original uses analytic corrections).

Still, the package should be treated as experimental. For production or
research use:

- validate outputs against the official Swiss Ephemeris tools;
- keep a representative regression-test set for the date ranges and bodies you
  actually use;
- document which version of this package and which `.se1` files were used.

## Development Provenance

This package is a project-specific, AI-assisted PHP conversion around the Swiss
Ephemeris / `swetest` workflow. Most of the technical conversion and packaging
work was carried out with Codex under direction and review from the On-line
Astrology project author.

Cursor was also used with a selected Gemini model as a supporting tool. Google
Antigravity, Google's agentic development platform, was used mainly for result
checking and review of changes. In July 2026, Claude (Anthropic)
performed an independent audit of the port against the Swiss Ephemeris 2.10.03
C sources and a numeric verification against the official `swetest` binary;
the fixes from that audit are part of version 0.1.3-preview.

These tools should not be understood as authors of the astrological method or
as authoritative sources for the astronomical calculation model. The original
project direction, review, publication decision, and responsibility for
checking outputs remain with the project author.

## Licensing

Swiss Ephemeris is distributed by Astrodienst under a dual licensing model:
AGPL or the Swiss Ephemeris Professional License. The license choice must be
made before distributing software containing Swiss Ephemeris parts or activating
a public service that uses it.

This ZIP package does not include Swiss Ephemeris `.se1` data files,
`swetest.exe`, or other native Swiss Ephemeris binaries. It also does not grant
any Swiss Ephemeris license rights. If you use this package in your own
software, distributed app, or public service, you must choose and comply with
the applicable Swiss Ephemeris license model yourself.

Official references:

- https://www.astro.com/swisseph/
- https://www.astro.com/swisseph/swisseph.htm
- https://www.astro.com/swisseph/secont_e.pdf
- https://www.gnu.org/licenses/agpl-3.0.html

This preview package should be published only with a clear license notice and
attribution. If you use it outside the On-line Astrology project, review the
Swiss Ephemeris license terms and choose the model that applies to your own
software or service.

