<?php
$swetestTimeLimit = isset($_SERVER['OLA_SWETEST_TIME_LIMIT']) && is_numeric($_SERVER['OLA_SWETEST_TIME_LIMIT'])
    ? max(5, min(60, (int)$_SERVER['OLA_SWETEST_TIME_LIMIT']))
    : 45;
if (function_exists('set_time_limit')) { @set_time_limit($swetestTimeLimit); }
@ini_set('max_execution_time', (string)$swetestTimeLimit);

/**
 * swetest_pure_se1_v9.php
 *
 * Pure PHP port-in-progress of Swiss Ephemeris swetest/sweph core.
 * No EXE, no DLL, no PHP extension, no FFI.
 *
 * This version really reads Swiss Ephemeris .se1 files and ports the important
 * C routines read_const(), get_new_segment(), rot_back(), Chebyshev evaluation.
 *
 * Implemented in this core file: Sun, Moon, Mercury..Pluto from
 * sepl_*.se1/semo_*.se1, mean node and Swiss-style tangent true node,
 * tropical longitude/latitude, distance, speed, precession and nutation.
 * Optional Lahiri/sidereal helpers and houses live in swetest_sweph_extra.php.
 *
 * Not yet 1:1 complete Swiss Ephemeris: no eclipses/rise/set and no full C API.
 * This build focuses on astrology longitude accuracy from .se1 files.
 * Apparent positions include light-time, solar light deflection, annual
 * aberration, precession, and nutation for the bodies used by the web.
 */

final class SweSe1Error extends RuntimeException {}

if (!function_exists('swetest_starts_with')) {
    function swetest_starts_with(string $haystack, string $needle): bool
    {
        if ($needle === '') {
            return true;
        }
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

final class SweMath
{
    public const PI = M_PI;
    public const TWOPI = 2.0 * M_PI;
    public const DEG2RAD = M_PI / 180.0;
    public const RAD2DEG = 180.0 / M_PI;
    public const SEPS2000 = 0.39777715572793088;
    public const CEPS2000 = 0.91748206215761929;
    public const AUNIT_M = 1.49597870700e11;
    public const CLIGHT_M_S = 2.99792458e8;
    public const CLIGHT_AUDAY = self::CLIGHT_M_S * 86400.0 / self::AUNIT_M;
    public const HELGRAVCONST = 1.32712440017987e20;
    public const SUN_RADIUS_RAD = (959.63 / 3600.0) * self::DEG2RAD;

    public static function norm360(float $x): float
    {
        $r = fmod($x, 360.0);
        return $r < 0 ? $r + 360.0 : $r;
    }

    public static function norm180(float $x): float
    {
        return self::norm360($x + 180.0) - 180.0;
    }

    public static function mods3600(float $x): float
    {
        return $x - 1296000.0 * floor($x / 1296000.0);
    }

    /** @return array{L:float,l:float,D:float,F:float} Mean lunar elements in arc seconds, Swiss/Moshier form. */
    public static function meanLunarElementsArcsec(float $jdEt): array
    {
        $t = ($jdEt - 2451545.0) / 36525.0;
        $t2 = $t * $t;
        $fracT = fmod($t, 1.0);
        $z = [
            -1.312045233711e+01, -1.138215912580e-03, -9.646018347184e-06,
             3.146734198839e+01,  4.768357585780e-02, -3.421689790404e-04,
            -6.847070905410e+00, -5.834100476561e-03, -2.905334122698e-04,
            -5.663161722088e+00,  5.722859298199e-03, -8.466472828815e-05,
        ];

        $f = self::mods3600(1739232000.0 * $fracT + 295263.0983 * $t - 2.079419901760e-01 * $t + 335779.55755);
        $l = self::mods3600(1717200000.0 * $fracT + 715923.4728 * $t - 2.035946368532e-01 * $t + 485868.28096);
        $d = self::mods3600(1601856000.0 * $fracT + 1105601.4603 * $t + 3.962893294503e-01 * $t + 1072260.73512);
        $L = self::mods3600(1731456000.0 * $fracT + 1108372.83264 * $t - 6.784914260953e-01 * $t + 785939.95571);

        $f += (($z[2] * $t + $z[1]) * $t + $z[0]) * $t2;
        $l += (($z[5] * $t + $z[4]) * $t + $z[3]) * $t2;
        $d += (($z[8] * $t + $z[7]) * $t + $z[6]) * $t2;
        $L += (($z[11] * $t + $z[10]) * $t + $z[9]) * $t2;

        return ['L' => $L, 'l' => $l, 'D' => $d, 'F' => $f];
    }

    public static function julday(int $year, int $month, int $day, float $utHours = 0.0, bool $gregorian = true): float
    {
        if ($month <= 2) {
            $year--;
            $month += 12;
        }
        $a = intdiv($year, 100);
        $b = $gregorian ? 2 - $a + intdiv($a, 4) : 0;
        return floor(365.25 * ($year + 4716)) + floor(30.6001 * ($month + 1)) + $day + $b - 1524.5 + $utHours / 24.0;
    }

    /** @return array{0:int,1:int,2:int,3:float} */
    public static function revjul(float $jd, bool $gregorian = true): array
    {
        $z = (int)floor($jd + 0.5);
        $f = ($jd + 0.5) - $z;
        if (!$gregorian || $z < 2299161) {
            $a = $z;
        } else {
            $alpha = (int)floor(($z - 1867216.25) / 36524.25);
            $a = $z + 1 + $alpha - intdiv($alpha, 4);
        }
        $b = $a + 1524;
        $c = (int)floor(($b - 122.1) / 365.25);
        $d = (int)floor(365.25 * $c);
        $e = (int)floor(($b - $d) / 30.6001);
        $dayFloat = $b - $d - floor(30.6001 * $e) + $f;
        $day = (int)floor($dayFloat);
        $month = ($e < 14) ? $e - 1 : $e - 13;
        $year = ($month > 2) ? $c - 4716 : $c - 4715;
        $ut = ($dayFloat - $day) * 24.0;
        return [$year, $month, $day, $ut];
    }

    public static function meanObliquityDeg(float $jd): float
    {
        // Swiss default obliquity model: Vondrak/Capitaine/Wallace 2011.
        // Port of swi_ldp_peps() from swephlib.c; the C default is
        // SEMOD_PREC_DEFAULT_SHORT = SEMOD_PREC_VONDRAK_2011, not IAU 2006.
        static $pepol = [
            [8134.017132, 84028.206305],
            [5043.0520035, 0.3624445],
            [-0.00710733, -0.00004039],
            [0.000000271, -0.000000110],
        ];
        static $peper = [
            [409.90, 396.15, 537.22, 402.90, 417.15, 288.92, 4043.00, 306.00, 277.00, 203.00],
            [-6908.287473, -3198.706291, 1453.674527, -857.748557, 1173.231614, -156.981465, 371.836550, -216.619040, 193.691479, 11.891524],
            [753.872780, -247.805823, 379.471484, -53.880558, -90.109153, -353.600190, -63.115353, -28.248187, 17.703387, 38.911307],
            [-2845.175469, 449.844989, -1255.915323, 886.736783, 418.887514, 997.912441, -240.979710, 76.541307, -36.788069, -170.964086],
            [-1704.720302, -862.308358, 447.832178, -889.571909, 190.402846, -56.564991, -296.222622, -75.859952, 67.473503, 3.014055],
        ];
        $t = ($jd - 2451545.0) / 36525.0;
        $q = 0.0;
        $w = self::TWOPI * $t;
        for ($i = 0; $i < 10; $i++) {
            $a = $w / $peper[0][$i];
            $q += cos($a) * $peper[2][$i] + sin($a) * $peper[4][$i];
        }
        $pow = 1.0;
        for ($i = 0; $i < 4; $i++) {
            $q += $pepol[$i][1] * $pow;
            $pow *= $t;
        }
        return $q / 3600.0;
    }

    public static function ayanamshaLahiri(float $jd): float
    {
        // Precise Lahiri tables live in the optional Swiss API helper file.
        // Keep this core file usable without the large optional table files.
        static $extraTried = false;
        if (!function_exists('swetest_lahiri_ayanamsha') && !$extraTried) {
            $extraTried = true;
            $extraPath = __DIR__ . DIRECTORY_SEPARATOR . 'swetest_sweph_extra.php';
            if (is_file($extraPath)) {
                require_once $extraPath;
            }
        }
        if (function_exists('swetest_lahiri_ayanamsha')) {
            $ayan = swetest_lahiri_ayanamsha($jd);
            if (is_numeric($ayan)) {
                return (float)$ayan;
            }
        }
        throw new RuntimeException('Sidereal/Lahiri vypocet vyzaduje volitelny modul swetest_sweph_extra.php a ayan_lahiri tabulky.');
    }

    public static function ayanamshaLahiriApprox(float $jd): float
    {
        return self::ayanamshaLahiri($jd);
    }

    public static function deltaTSeconds(float $jdUt, int $denum = 441): float
    {
        // Swiss Ephemeris default Delta T model: Stephenson/Hohenkerk 2016
        // before 1955 and Astronomical Almanac/IERS table with Bessel
        // interpolation afterwards. Returned value is seconds.
        // C Swiss chooses the tidal acceleration from the .se1/JPL denum.
        $tidAcc = self::tidalAccelerationForDenum($denum);
        if ($jdUt < 2435108.5) {
            $dt = self::deltaTStephenson2016Seconds($jdUt, $tidAcc);
            if ($jdUt >= 2434108.5) {
                $dt += (1.0 - (2435108.5 - $jdUt) / 1000.0) * 0.6610218;
            }
            return $dt;
        }
        return self::deltaTAaSeconds($jdUt, $tidAcc);
    }

    public static function tidalAccelerationForDenum(int $denum): float
    {
        switch ($denum) {
            case 200: return -23.8946;
            case 403:
            case 404: return -25.580;
            case 405:
            case 406: return -25.826;
            case 421:
            case 422: return -25.85;
            case 430: return -25.82;
            case 431: return -25.80;
            case 440:
            case 441: return -25.936;
            default: return -25.80;
        }
    }

    private static function adjustDeltaTForTidAcc(float $ans, float $year, float $tidAcc, float $tidAcc0, bool $adjustAfter1955): float
    {
        if ($year < 1955.0 || $adjustAfter1955) {
            $b = $year - 1955.0;
            $ans += -0.000091 * ($tidAcc - $tidAcc0) * $b * $b;
        }
        return $ans;
    }

    private static function deltaTStephenson2016Seconds(float $jdUt, float $tidAcc): float
    {
        static $dtcf16 = [
            [1458085.5, 1867156.5, 20550.593, -21268.478, 11863.418, -4541.129],
            [1867156.5, 2086302.5, 6604.404, -5981.266, -505.093, 1349.609],
            [2086302.5, 2268923.5, 1467.654, -2452.187, 2460.927, -1183.759],
            [2268923.5, 2305447.5, 292.635, -216.322, -43.614, 56.681],
            [2305447.5, 2323710.5, 89.380, -66.754, 31.607, -10.497],
            [2323710.5, 2349276.5, 43.736, -49.043, 0.227, 15.811],
            [2349276.5, 2378496.5, 10.730, -1.321, 62.250, -52.946],
            [2378496.5, 2382148.5, 18.714, -4.457, -1.509, 2.507],
            [2382148.5, 2385800.5, 15.255, 0.046, 6.012, -4.634],
            [2385800.5, 2389453.5, 16.679, -1.831, -7.889, 3.799],
            [2389453.5, 2393105.5, 10.758, -6.211, 3.509, -0.388],
            [2393105.5, 2396758.5, 7.668, -0.357, 2.345, -0.338],
            [2396758.5, 2398584.5, 9.317, 1.659, 0.332, -0.932],
            [2398584.5, 2400410.5, 10.376, -0.472, -2.463, 1.596],
            [2400410.5, 2402237.5, 9.038, -0.610, 2.325, -2.497],
            [2402237.5, 2404063.5, 8.256, -3.450, -5.166, 2.729],
            [2404063.5, 2405889.5, 2.369, -5.596, 3.020, -0.919],
            [2405889.5, 2407715.5, -1.126, -2.312, 0.264, -0.037],
            [2407715.5, 2409542.5, -3.211, -1.894, 0.154, 0.562],
            [2409542.5, 2411368.5, -4.388, 0.101, 1.841, -1.438],
            [2411368.5, 2413194.5, -3.884, -0.531, -2.473, 1.870],
            [2413194.5, 2415020.5, -5.017, 0.134, 3.138, -0.232],
            [2415020.5, 2416846.5, -1.977, 5.715, 2.443, -1.257],
            [2416846.5, 2418672.5, 4.923, 6.828, -1.329, 0.720],
            [2418672.5, 2420498.5, 11.142, 6.330, 0.831, -0.825],
            [2420498.5, 2422324.5, 17.479, 5.518, -1.643, 0.262],
            [2422324.5, 2424151.5, 21.617, 3.020, -0.856, 0.008],
            [2424151.5, 2425977.5, 23.789, 1.333, -0.831, 0.127],
            [2425977.5, 2427803.5, 24.418, 0.052, -0.449, 0.142],
            [2427803.5, 2429629.5, 24.164, -0.419, -0.022, 0.702],
            [2429629.5, 2431456.5, 24.426, 1.645, 2.086, -1.106],
            [2431456.5, 2433282.5, 27.050, 2.499, -1.232, 0.614],
            [2433282.5, 2434378.5, 28.932, 1.127, 0.220, -0.277],
            [2434378.5, 2435473.5, 30.002, 0.737, -0.610, 0.631],
            [2435473.5, 2436569.5, 30.760, 1.409, 1.282, -0.799],
            [2436569.5, 2437665.5, 32.652, 1.577, -1.115, 0.507],
            [2437665.5, 2438761.5, 33.621, 0.868, 0.406, 0.199],
            [2438761.5, 2439856.5, 35.093, 2.275, 1.002, -0.414],
            [2439856.5, 2440952.5, 37.956, 3.035, -0.242, 0.202],
            [2440952.5, 2442048.5, 40.951, 3.157, 0.364, -0.229],
            [2442048.5, 2443144.5, 44.244, 3.198, -0.323, 0.172],
            [2443144.5, 2444239.5, 47.291, 3.069, 0.193, -0.192],
            [2444239.5, 2445335.5, 50.361, 2.878, -0.384, 0.081],
            [2445335.5, 2446431.5, 52.936, 2.354, -0.140, -0.166],
            [2446431.5, 2447527.5, 54.984, 1.577, -0.637, 0.448],
            [2447527.5, 2448622.5, 56.373, 1.649, 0.709, -0.277],
            [2448622.5, 2449718.5, 58.453, 2.235, -0.122, 0.111],
            [2449718.5, 2450814.5, 60.677, 2.324, 0.212, -0.315],
            [2450814.5, 2451910.5, 62.899, 1.804, -0.732, 0.112],
            [2451910.5, 2453005.5, 64.082, 0.675, -0.396, 0.193],
            [2453005.5, 2454101.5, 64.555, 0.463, 0.184, -0.008],
            [2454101.5, 2455197.5, 65.194, 0.809, 0.161, -0.101],
            [2455197.5, 2456293.5, 66.063, 0.828, -0.142, 0.168],
            [2456293.5, 2457388.5, 66.917, 1.046, 0.360, -0.282],
        ];
        $yearGreg = 2000.0 + ($jdUt - 2451545.0) / 365.2425;
        $dt = null;
        foreach ($dtcf16 as $r) {
            if ($jdUt < $r[0]) {
                break;
            }
            if ($jdUt < $r[1]) {
                $t = ($jdUt - $r[0]) / ($r[1] - $r[0]);
                $dt = $r[2] + $r[3] * $t + $r[4] * $t * $t + $r[5] * $t * $t * $t;
                break;
            }
        }
        if ($dt === null) {
            $t = ($yearGreg - 1825.0) / 100.0;
            $dt = -320.0 + 32.5 * $t * $t;
            $dt += ($yearGreg < -720.0) ? -179.7337208 : 269.4790417;
        }
        return self::adjustDeltaTForTidAcc($dt, $yearGreg, $tidAcc, -25.85, true);
    }

    private static function deltaTAaSeconds(float $jdUt, float $tidAcc): float
    {
        static $dt = [
            124.00, 119.00, 115.00, 110.00, 106.00, 102.00, 98.00, 95.00, 91.00, 88.00,
            85.00, 82.00, 79.00, 77.00, 74.00, 72.00, 70.00, 67.00, 65.00, 63.00,
            62.00, 60.00, 58.00, 57.00, 55.00, 54.00, 53.00, 51.00, 50.00, 49.00,
            48.00, 47.00, 46.00, 45.00, 44.00, 43.00, 42.00, 41.00, 40.00, 38.00,
            37.00, 36.00, 35.00, 34.00, 33.00, 32.00, 31.00, 30.00, 28.00, 27.00,
            26.00, 25.00, 24.00, 23.00, 22.00, 21.00, 20.00, 19.00, 18.00, 17.00,
            16.00, 15.00, 14.00, 14.00, 13.00, 12.00, 12.00, 11.00, 11.00, 10.00,
            10.00, 10.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00,
            9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 10.00, 10.00,
            10.00, 10.00, 10.00, 10.00, 10.00, 10.00, 10.00, 11.00, 11.00, 11.00,
            11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00, 11.00,
            11.00, 11.00, 11.00, 11.00, 12.00, 12.00, 12.00, 12.00, 12.00, 12.00,
            12.00, 12.00, 12.00, 12.00, 13.00, 13.00, 13.00, 13.00, 13.00, 13.00,
            13.00, 14.00, 14.00, 14.00, 14.00, 14.00, 14.00, 14.00, 15.00, 15.00,
            15.00, 15.00, 15.00, 15.00, 15.00, 16.00, 16.00, 16.00, 16.00, 16.00,
            16.00, 16.00, 16.00, 16.00, 16.00, 17.00, 17.00, 17.00, 17.00, 17.00,
            17.00, 17.00, 17.00, 17.00, 17.00, 17.00, 17.00, 17.00, 17.00, 17.00,
            17.00, 17.00, 16.00, 16.00, 16.00, 16.00, 15.00, 15.00, 14.00, 14.00,
            13.70, 13.40, 13.10, 12.90, 12.70, 12.60, 12.50, 12.50, 12.50, 12.50,
            12.50, 12.50, 12.50, 12.50, 12.50, 12.50, 12.50, 12.40, 12.30, 12.20,
            12.00, 11.70, 11.40, 11.10, 10.60, 10.20, 9.60, 9.10, 8.60, 8.00,
            7.50, 7.00, 6.60, 6.30, 6.00, 5.80, 5.70, 5.60, 5.60, 5.60,
            5.70, 5.80, 5.90, 6.10, 6.20, 6.30, 6.50, 6.60, 6.80, 6.90,
            7.10, 7.20, 7.30, 7.40, 7.50, 7.60, 7.70, 7.70, 7.80, 7.80,
            7.88, 7.82, 7.54, 6.97, 6.40, 6.02, 5.41, 4.10, 2.92, 1.82,
            1.61, .10, -1.02, -1.28, -2.69, -3.24, -3.64, -4.54, -4.71, -5.11,
            -5.40, -5.42, -5.20, -5.46, -5.46, -5.79, -5.63, -5.64, -5.80, -5.66,
            -5.87, -6.01, -6.19, -6.64, -6.44, -6.47, -6.09, -5.76, -4.66, -3.74,
            -2.72, -1.54, -.02, 1.24, 2.64, 3.86, 5.37, 6.14, 7.75, 9.13,
            10.46, 11.53, 13.36, 14.65, 16.01, 17.20, 18.24, 19.06, 20.25, 20.95,
            21.16, 22.25, 22.41, 23.03, 23.49, 23.62, 23.86, 24.49, 24.34, 24.08,
            24.02, 24.00, 23.87, 23.95, 23.86, 23.93, 23.73, 23.92, 23.96, 24.02,
            24.33, 24.83, 25.30, 25.70, 26.24, 26.77, 27.28, 27.78, 28.25, 28.71,
            29.15, 29.57, 29.97, 30.36, 30.72, 31.07, 31.35, 31.68, 32.18, 32.68,
            33.15, 33.59, 34.00, 34.47, 35.03, 35.73, 36.54, 37.43, 38.29, 39.20,
            40.18, 41.17, 42.23, 43.37, 44.4841, 45.4761, 46.4567, 47.5214, 48.5344, 49.5862,
            50.5387, 51.3808, 52.1668, 52.9565, 53.7882, 54.3427, 54.8713, 55.3222, 55.8197, 56.3000,
            56.8553, 57.5653, 58.3092, 59.1218, 59.9845, 60.7854, 61.6287, 62.2951, 62.9659, 63.4673,
            63.8285, 64.0908, 64.2998, 64.4734, 64.5736, 64.6876, 64.8452, 65.1464, 65.4574, 65.7768,
            66.0699, 66.3246, 66.6030, 66.9069, 67.2810, 67.6439, 68.1024, 68.5927, 68.9676, 69.2202,
            69.3612, 69.3593, 69.2945, 69.1833, 69.10, 69.00, 68.90, 68.80, 68.80,
        ];
        $tabStart = 1620;
        $tabsiz = count($dt);
        $tabEnd = $tabStart + $tabsiz - 1;
        $year = 2000.0 + ($jdUt - 2451544.5) / 365.25;

        if ($year <= $tabEnd) {
            $p0 = floor($year);
            $iy = (int)($p0 - $tabStart);
            if ($iy < 0) {
                return self::deltaTStephenson2016Seconds($jdUt, $tidAcc);
            }
            $ans = $dt[$iy];
            $k = $iy + 1;
            if ($k < $tabsiz) {
                $p = $year - $p0;
                $ans += $p * ($dt[$k] - $dt[$iy]);
                if (!($iy - 1 < 0 || $iy + 2 >= $tabsiz)) {
                    $d = [];
                    $k = $iy - 2;
                    for ($i = 0; $i < 5; $i++, $k++) {
                        $d[$i] = ($k < 0 || $k + 1 >= $tabsiz) ? 0.0 : $dt[$k + 1] - $dt[$k];
                    }
                    for ($i = 0; $i < 4; $i++) {
                        $d[$i] = $d[$i + 1] - $d[$i];
                    }
                    $b = 0.25 * $p * ($p - 1.0);
                    $ans += $b * ($d[1] + $d[2]);
                    if ($iy + 2 < $tabsiz) {
                        for ($i = 0; $i < 3; $i++) {
                            $d[$i] = $d[$i + 1] - $d[$i];
                        }
                        $b = 2.0 * $b / 3.0;
                        $ans += ($p - 0.5) * $b * $d[1];
                        if (!($iy - 2 < 0 || $iy + 3 > $tabsiz)) {
                            for ($i = 0; $i < 2; $i++) {
                                $d[$i] = $d[$i + 1] - $d[$i];
                            }
                            $b = 0.125 * $b * ($p + 1.0) * ($p - 2.0);
                            $ans += $b * ($d[0] + $d[1]);
                        }
                    }
                }
            }
            return self::adjustDeltaTForTidAcc($ans, $year, $tidAcc, -26.0, false);
        }

        $b = $year - 2000.0;
        if ($year < 2500.0) {
            $ans = $b * $b * $b * 121.0 / 30000000.0 + $b * $b / 1250.0 + $b * 521.0 / 3000.0 + 64.0;
            $b2 = $tabEnd - 2000.0;
            $ans2 = $b2 * $b2 * $b2 * 121.0 / 30000000.0 + $b2 * $b2 / 1250.0 + $b2 * 521.0 / 3000.0 + 64.0;
        } else {
            $b = 0.01 * ($year - 2000.0);
            $ans = $b * $b * 32.5 + 42.5;
            $ans2 = $ans;
        }
        if ($year <= $tabEnd + 100.0) {
            $ans3 = $dt[$tabsiz - 1];
            $ans += ($ans2 - $ans3) * ($year - ($tabEnd + 100.0)) * 0.01;
        }
        return $ans;
    }
    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    public static function precessJ2000ToDate(array $v, float $jd): array
    {
        $x = $v[0]; $y = $v[1]; $z = $v[2];
        if (abs($jd - 2451545.0) < 1e-12) {
            return [$x, $y, $z, $v[3] ?? 0.0, $v[4] ?? 0.0, $v[5] ?? 0.0];
        }
        // Swiss default precession model: Vondrak/Capitaine/Wallace 2011.
        $pmat = self::vondrakPrecessionMatrix($jd);
        return [
            $x*$pmat[0] + $y*$pmat[1] + $z*$pmat[2],
            $x*$pmat[3] + $y*$pmat[4] + $z*$pmat[5],
            $x*$pmat[6] + $y*$pmat[7] + $z*$pmat[8],
            $v[3] ?? 0.0, $v[4] ?? 0.0, $v[5] ?? 0.0
        ];
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    public static function precessDateToJ2000(array $v, float $jd): array
    {
        $x = $v[0]; $y = $v[1]; $z = $v[2];
        if (abs($jd - 2451545.0) < 1e-12) {
            return [$x, $y, $z, $v[3] ?? 0.0, $v[4] ?? 0.0, $v[5] ?? 0.0];
        }
        $pmat = self::vondrakPrecessionMatrix($jd);
        return [
            $x*$pmat[0] + $y*$pmat[3] + $z*$pmat[6],
            $x*$pmat[1] + $y*$pmat[4] + $z*$pmat[7],
            $x*$pmat[2] + $y*$pmat[5] + $z*$pmat[8],
            $v[3] ?? 0.0, $v[4] ?? 0.0, $v[5] ?? 0.0
        ];
    }

    /** @return array{lon:float,lat:float,dist:float} */
    public static function equToEclDate(array $v, float $jd): array
    {
        $eps = self::meanObliquityDeg($jd) * self::DEG2RAD;
        $x = $v[0];
        $y = cos($eps) * $v[1] + sin($eps) * $v[2];
        $z = -sin($eps) * $v[1] + cos($eps) * $v[2];
        $lon = self::norm360(atan2($y, $x) * self::RAD2DEG);
        $rxy = hypot($x, $y);
        $lat = atan2($z, $rxy) * self::RAD2DEG;
        $dist = sqrt($x*$x + $y*$y + $z*$z);
        return ['lon' => $lon, 'lat' => $lat, 'dist' => $dist];
    }

    /** @return array{lon:float,lat:float,dist:float} */
    public static function equToEclWithEps(array $v, float $epsRad): array
    {
        $x = $v[0];
        $y = cos($epsRad) * $v[1] + sin($epsRad) * $v[2];
        $z = -sin($epsRad) * $v[1] + cos($epsRad) * $v[2];
        $lon = self::norm360(atan2($y, $x) * self::RAD2DEG);
        $rxy = hypot($x, $y);
        $lat = atan2($z, $rxy) * self::RAD2DEG;
        $dist = sqrt($x*$x + $y*$y + $z*$z);
        return ['lon' => $lon, 'lat' => $lat, 'dist' => $dist];
    }

    public static function vecNorm3(array $v): float
    {
        return sqrt(($v[0] ?? 0.0)**2 + ($v[1] ?? 0.0)**2 + ($v[2] ?? 0.0)**2);
    }

    public static function dot3(array $a, array $b): float
    {
        return ($a[0] ?? 0.0)*($b[0] ?? 0.0) + ($a[1] ?? 0.0)*($b[1] ?? 0.0) + ($a[2] ?? 0.0)*($b[2] ?? 0.0);
    }

    /** @return array{0:float,1:float,2:float} */
    private static function cross3(array $a, array $b): array
    {
        return [
            ($a[1] ?? 0.0) * ($b[2] ?? 0.0) - ($a[2] ?? 0.0) * ($b[1] ?? 0.0),
            ($a[2] ?? 0.0) * ($b[0] ?? 0.0) - ($a[0] ?? 0.0) * ($b[2] ?? 0.0),
            ($a[0] ?? 0.0) * ($b[1] ?? 0.0) - ($a[1] ?? 0.0) * ($b[0] ?? 0.0),
        ];
    }

    /** @return array{0:float,1:float,2:float} */
    private static function prePeclVondrak(float $jd): array
    {
        static $pqpol = [
            [5851.607687, -1600.886300],
            [-0.1189000, 1.1689818],
            [-0.00028913, -0.00000020],
            [0.000000101, -0.000000437],
        ];
        static $pqper = [
            [708.15, 2309.0, 1620.0, 492.2, 1183.0, 622.0, 882.0, 547.0],
            [-5486.751211, -17.127623, -617.517403, 413.44294, 78.614193, -180.732815, -87.676083, 46.140315],
            [-684.66156, 2446.28388, 399.671049, -356.652376, -186.387003, -316.80007, 198.296701, 101.135679],
            [667.66673, -2354.886252, -428.152441, 376.202861, 184.778874, 335.321713, -185.138669, -120.97283],
            [-5523.863691, -549.74745, -310.998056, 421.535876, -36.776172, -145.278396, -34.74445, 22.885731],
        ];
        $t = ($jd - 2451545.0) / 36525.0;
        $p = 0.0; $q = 0.0; $w = self::TWOPI * $t;
        for ($i = 0; $i < 8; $i++) {
            $a = $w / $pqper[0][$i];
            $s = sin($a); $c = cos($a);
            $p += $c * $pqper[1][$i] + $s * $pqper[3][$i];
            $q += $c * $pqper[2][$i] + $s * $pqper[4][$i];
        }
        $pow = 1.0;
        for ($i = 0; $i < 4; $i++) {
            $p += $pqpol[$i][0] * $pow;
            $q += $pqpol[$i][1] * $pow;
            $pow *= $t;
        }
        $as2r = self::DEG2RAD / 3600.0;
        $p *= $as2r;
        $q *= $as2r;
        $z = max(0.0, 1.0 - $p * $p - $q * $q);
        $z = sqrt($z);
        $eps0 = 84381.406 * $as2r;
        $s = sin($eps0); $c = cos($eps0);
        return [$p, -$q * $c - $z * $s, -$q * $s + $z * $c];
    }

    /** @return array{0:float,1:float,2:float} */
    private static function prePequVondrak(float $jd): array
    {
        static $xypol = [
            [5453.282155, -73750.930350],
            [0.4252841, -0.7675452],
            [-0.00037173, -0.00018725],
            [-0.000000152, 0.000000231],
        ];
        static $xyper = [
            [256.75, 708.15, 274.2, 241.45, 2309.0, 492.2, 396.1, 288.9, 231.1, 1610.0, 620.0, 157.87, 220.3, 1200.0],
            [-819.940624, -8444.676815, 2600.009459, 2755.17563, -167.659835, 871.855056, 44.769698, -512.313065, -819.415595, -538.071099, -189.793622, -402.922932, 179.516345, -9.814756],
            [75004.344875, 624.033993, 1251.136893, -1102.212834, -2660.66498, 699.291817, 153.16722, -950.865637, 499.754645, -145.18821, 558.116553, -23.923029, -165.405086, 9.344131],
            [81491.287984, 787.163481, 1251.296102, -1257.950837, -2966.79973, 639.744522, 131.600209, -445.040117, 584.522874, -89.756563, 524.42963, -13.549067, -210.157124, -44.919798],
            [1558.515853, 7774.939698, -2219.534038, -2523.969396, 247.850422, -846.485643, -1393.124055, 368.526116, 749.045012, 444.704518, 235.934465, 374.049623, -171.33018, -22.899655],
        ];
        $t = ($jd - 2451545.0) / 36525.0;
        $x = 0.0; $y = 0.0; $w = self::TWOPI * $t;
        for ($i = 0; $i < 14; $i++) {
            $a = $w / $xyper[0][$i];
            $s = sin($a); $c = cos($a);
            $x += $c * $xyper[1][$i] + $s * $xyper[3][$i];
            $y += $c * $xyper[2][$i] + $s * $xyper[4][$i];
        }
        $pow = 1.0;
        for ($i = 0; $i < 4; $i++) {
            $x += $xypol[$i][0] * $pow;
            $y += $xypol[$i][1] * $pow;
            $pow *= $t;
        }
        $as2r = self::DEG2RAD / 3600.0;
        $x *= $as2r;
        $y *= $as2r;
        $z2 = $x * $x + $y * $y;
        return [$x, $y, $z2 < 1.0 ? sqrt(1.0 - $z2) : 0.0];
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float,6:float,7:float,8:float} */
    private static function vondrakPrecessionMatrix(float $jd): array
    {
        $peqr = self::prePequVondrak($jd);
        $pecl = self::prePeclVondrak($jd);
        $v = self::cross3($peqr, $pecl);
        $w = self::vecNorm3($v);
        if ($w <= 0.0) {
            return [1.0,0.0,0.0, 0.0,1.0,0.0, 0.0,0.0,1.0];
        }
        $eqx = [$v[0] / $w, $v[1] / $w, $v[2] / $w];
        $v = self::cross3($peqr, $eqx);
        return [$eqx[0], $eqx[1], $eqx[2], $v[0], $v[1], $v[2], $peqr[0], $peqr[1], $peqr[2]];
    }

    /**
     * IAU 2000B nutation, matching the Swiss Ephemeris default model.
     * The 77 luni-solar terms are the NLS_2000B subset from swenut2000a.h.
     * Coefficients are in 0.1 microarcseconds, exactly as in Swiss C.
     * @return array{dpsi:float,deps:float,epsMean:float,epsTrue:float}
     */
    public static function nutationShort(float $jdEt): array
    {
        $t = ($jdEt - 2451545.0) / 36525.0;
        $M = self::norm360((485868.249036 + $t * (1717915923.2178 + $t * (31.8792 + $t * (0.051635 + $t * -0.00024470)))) / 3600.0) * self::DEG2RAD;
        $SM = self::norm360((1287104.79305 + $t * (129596581.0481 + $t * (-0.5532 + $t * (0.000136 + $t * -0.00001149)))) / 3600.0) * self::DEG2RAD;
        $F = self::norm360((335779.526232 + $t * (1739527262.8478 + $t * (-12.7512 + $t * (-0.001037 + $t * 0.00000417)))) / 3600.0) * self::DEG2RAD;
        $D = self::norm360((1072260.70369 + $t * (1602961601.2090 + $t * (-6.3706 + $t * (0.006593 + $t * -0.00003169)))) / 3600.0) * self::DEG2RAD;
        $Om = self::norm360((450160.398036 + $t * (-6962890.5431 + $t * (7.4722 + $t * (0.007702 + $t * -0.00005939)))) / 3600.0) * self::DEG2RAD;
        static $terms = [
            [0, 0, 0, 0, 1, -172064161, -174666, 33386, 92052331, 9086, 15377],
            [0, 0, 2, -2, 2, -13170906, -1675, -13696, 5730336, -3015, -4587],
            [0, 0, 2, 0, 2, -2276413, -234, 2796, 978459, -485, 1374],
            [0, 0, 0, 0, 2, 2074554, 207, -698, -897492, 470, -291],
            [0, 1, 0, 0, 0, 1475877, -3633, 11817, 73871, -184, -1924],
            [0, 1, 2, -2, 2, -516821, 1226, -524, 224386, -677, -174],
            [1, 0, 0, 0, 0, 711159, 73, -872, -6750, 0, 358],
            [0, 0, 2, 0, 1, -387298, -367, 380, 200728, 18, 318],
            [1, 0, 2, 0, 2, -301461, -36, 816, 129025, -63, 367],
            [0, -1, 2, -2, 2, 215829, -494, 111, -95929, 299, 132],
            [0, 0, 2, -2, 1, 128227, 137, 181, -68982, -9, 39],
            [-1, 0, 2, 0, 2, 123457, 11, 19, -53311, 32, -4],
            [-1, 0, 0, 2, 0, 156994, 10, -168, -1235, 0, 82],
            [1, 0, 0, 0, 1, 63110, 63, 27, -33228, 0, -9],
            [-1, 0, 0, 0, 1, -57976, -63, -189, 31429, 0, -75],
            [-1, 0, 2, 2, 2, -59641, -11, 149, 25543, -11, 66],
            [1, 0, 2, 0, 1, -51613, -42, 129, 26366, 0, 78],
            [-2, 0, 2, 0, 1, 45893, 50, 31, -24236, -10, 20],
            [0, 0, 0, 2, 0, 63384, 11, -150, -1220, 0, 29],
            [0, 0, 2, 2, 2, -38571, -1, 158, 16452, -11, 68],
            [0, -2, 2, -2, 2, 32481, 0, 0, -13870, 0, 0],
            [-2, 0, 0, 2, 0, -47722, 0, -18, 477, 0, -25],
            [2, 0, 2, 0, 2, -31046, -1, 131, 13238, -11, 59],
            [1, 0, 2, -2, 2, 28593, 0, -1, -12338, 10, -3],
            [-1, 0, 2, 0, 1, 20441, 21, 10, -10758, 0, -3],
            [2, 0, 0, 0, 0, 29243, 0, -74, -609, 0, 13],
            [0, 0, 2, 0, 0, 25887, 0, -66, -550, 0, 11],
            [0, 1, 0, 0, 1, -14053, -25, 79, 8551, -2, -45],
            [-1, 0, 0, 2, 1, 15164, 10, 11, -8001, 0, -1],
            [0, 2, 2, -2, 2, -15794, 72, -16, 6850, -42, -5],
            [0, 0, -2, 2, 0, 21783, 0, 13, -167, 0, 13],
            [1, 0, 0, -2, 1, -12873, -10, -37, 6953, 0, -14],
            [0, -1, 0, 0, 1, -12654, 11, 63, 6415, 0, 26],
            [-1, 0, 2, 2, 1, -10204, 0, 25, 5222, 0, 15],
            [0, 2, 0, 0, 0, 16707, -85, -10, 168, -1, 10],
            [1, 0, 2, 2, 2, -7691, 0, 44, 3268, 0, 19],
            [-2, 0, 2, 0, 0, -11024, 0, -14, 104, 0, 2],
            [0, 1, 2, 0, 2, 7566, -21, -11, -3250, 0, -5],
            [0, 0, 2, 2, 1, -6637, -11, 25, 3353, 0, 14],
            [0, -1, 2, 0, 2, -7141, 21, 8, 3070, 0, 4],
            [0, 0, 0, 2, 1, -6302, -11, 2, 3272, 0, 4],
            [1, 0, 2, -2, 1, 5800, 10, 2, -3045, 0, -1],
            [2, 0, 2, -2, 2, 6443, 0, -7, -2768, 0, -4],
            [-2, 0, 0, 2, 1, -5774, -11, -15, 3041, 0, -5],
            [2, 0, 2, 0, 1, -5350, 0, 21, 2695, 0, 12],
            [0, -1, 2, -2, 1, -4752, -11, -3, 2719, 0, -3],
            [0, 0, 0, -2, 1, -4940, -11, -21, 2720, 0, -9],
            [-1, -1, 0, 2, 0, 7350, 0, -8, -51, 0, 4],
            [2, 0, 0, -2, 1, 4065, 0, 6, -2206, 0, 1],
            [1, 0, 0, 2, 0, 6579, 0, -24, -199, 0, 2],
            [0, 1, 2, -2, 1, 3579, 0, 5, -1900, 0, 1],
            [1, -1, 0, 0, 0, 4725, 0, -6, -41, 0, 3],
            [-2, 0, 2, 0, 2, -3075, 0, -2, 1313, 0, -1],
            [3, 0, 2, 0, 2, -2904, 0, 15, 1233, 0, 7],
            [0, -1, 0, 2, 0, 4348, 0, -10, -81, 0, 2],
            [1, -1, 2, 0, 2, -2878, 0, 8, 1232, 0, 4],
            [0, 0, 0, 1, 0, -4230, 0, 5, -20, 0, -2],
            [-1, -1, 2, 2, 2, -2819, 0, 7, 1207, 0, 3],
            [-1, 0, 2, 0, 0, -4056, 0, 5, 40, 0, -2],
            [0, -1, 2, 2, 2, -2647, 0, 11, 1129, 0, 5],
            [-2, 0, 0, 0, 1, -2294, 0, -10, 1266, 0, -4],
            [1, 1, 2, 0, 2, 2481, 0, -7, -1062, 0, -3],
            [2, 0, 0, 0, 1, 2179, 0, -2, -1129, 0, -2],
            [-1, 1, 0, 1, 0, 3276, 0, 1, -9, 0, 0],
            [1, 1, 0, 0, 0, -3389, 0, 5, 35, 0, -2],
            [1, 0, 2, 0, 0, 3339, 0, -13, -107, 0, 1],
            [-1, 0, 2, -2, 1, -1987, 0, -6, 1073, 0, -2],
            [1, 0, 0, 0, 2, -1981, 0, 0, 854, 0, 0],
            [-1, 0, 0, 1, 0, 4026, 0, -353, -553, 0, -139],
            [0, 0, 2, 1, 2, 1660, 0, -5, -710, 0, -2],
            [-1, 0, 2, 4, 2, -1521, 0, 9, 647, 0, 4],
            [-1, 1, 0, 1, 1, 1314, 0, 0, -700, 0, 0],
            [0, -2, 2, -2, 1, -1283, 0, 0, 672, 0, 0],
            [1, 0, 2, 2, 1, -1331, 0, 8, 663, 0, 4],
            [-2, 0, 2, 2, 2, 1383, 0, -2, -594, 0, -2],
            [-1, 0, 0, 0, 2, 1405, 0, 4, -610, 0, 2],
            [1, 1, 2, -2, 2, 1290, 0, 0, -556, 0, 0],
        ];
        $dpsi = 0.0;
        $deps = 0.0;
        for ($i = count($terms) - 1; $i >= 0; $i--) {
            $r = $terms[$i];
            $arg = $r[0] * $M + $r[1] * $SM + $r[2] * $F + $r[3] * $D + $r[4] * $Om;
            $sinArg = sin($arg);
            $cosArg = cos($arg);
            $dpsi += ($r[5] + $r[6] * $t) * $sinArg + $r[7] * $cosArg;
            $deps += ($r[8] + $r[9] * $t) * $cosArg + $r[10] * $sinArg;
        }
        $unit = self::DEG2RAD / 3600.0 / 10000000.0;
        $dpsi *= $unit;
        $deps *= $unit;
        $epsMean = self::meanObliquityDeg($jdEt) * self::DEG2RAD;
        return ['dpsi' => $dpsi, 'deps' => $deps, 'epsMean' => $epsMean, 'epsTrue' => $epsMean + $deps];
    }
    public static function applyNutation(array $v, float $jdEt): array
    {
        $nu = self::nutationShort($jdEt);
        $psi = $nu['dpsi'];
        $eps = $nu['epsTrue'];
        $eps0 = $nu['epsMean'];
        $sinpsi = sin($psi); $cospsi = cos($psi);
        $sineps = sin($eps); $coseps = cos($eps);
        $sineps0 = sin($eps0); $coseps0 = cos($eps0);
        $m = [
            [$cospsi, $sinpsi * $coseps, $sinpsi * $sineps],
            [-$sinpsi * $coseps0, $cospsi * $coseps * $coseps0 + $sineps * $sineps0, $cospsi * $sineps * $coseps0 - $coseps * $sineps0],
            [-$sinpsi * $sineps0, $cospsi * $coseps * $sineps0 - $sineps * $coseps0, $cospsi * $sineps * $sineps0 + $coseps * $coseps0],
        ];
        $x = $v[0]*$m[0][0] + $v[1]*$m[1][0] + $v[2]*$m[2][0];
        $y = $v[0]*$m[0][1] + $v[1]*$m[1][1] + $v[2]*$m[2][1];
        $z = $v[0]*$m[0][2] + $v[1]*$m[1][2] + $v[2]*$m[2][2];
        $vx = ($v[3] ?? 0.0)*$m[0][0] + ($v[4] ?? 0.0)*$m[1][0] + ($v[5] ?? 0.0)*$m[2][0];
        $vy = ($v[3] ?? 0.0)*$m[0][1] + ($v[4] ?? 0.0)*$m[1][1] + ($v[5] ?? 0.0)*$m[2][1];
        $vz = ($v[3] ?? 0.0)*$m[0][2] + ($v[4] ?? 0.0)*$m[1][2] + ($v[5] ?? 0.0)*$m[2][2];
        return [$x, $y, $z, $vx, $vy, $vz];
    }

    /** Annual aberration of light, ported from Swiss Ephemeris aberr_light(). */
    public static function aberrLight(array $xx, array $earthBary): array
    {
        $u = [$xx[0], $xx[1], $xx[2]];
        $ru = self::vecNorm3($u);
        if ($ru <= 0.0) return $xx;
        $v = [
            ($earthBary[3] ?? 0.0) / self::CLIGHT_AUDAY,
            ($earthBary[4] ?? 0.0) / self::CLIGHT_AUDAY,
            ($earthBary[5] ?? 0.0) / self::CLIGHT_AUDAY,
        ];
        $v2 = self::dot3($v, $v);
        if ($v2 >= 1.0) return $xx;
        $b1 = sqrt(1.0 - $v2);
        $f1 = self::dot3($u, $v) / $ru;
        $f2 = 1.0 + $f1 / (1.0 + $b1);
        for ($i = 0; $i < 3; $i++) {
            $xx[$i] = ($b1 * $xx[$i] + $f2 * $ru * $v[$i]) / (1.0 + $f1);
        }
        return $xx;
    }

    /**
     * Relativistic light deflection by the Sun, ported from Swiss
     * Ephemeris swi_deflect_light(). Speeds are deliberately left unchanged:
     * this PHP layer derives displayed longitude speed by finite differences
     * of the final apparent longitude, so the position correction is enough.
     */
    public static function deflectLight(array $xx, array $earthBary, array $sunBary, float $lightTimeDays): array
    {
        $u = [$xx[0] ?? 0.0, $xx[1] ?? 0.0, $xx[2] ?? 0.0];
        $e = [
            ($earthBary[0] ?? 0.0) - ($sunBary[0] ?? 0.0),
            ($earthBary[1] ?? 0.0) - ($sunBary[1] ?? 0.0),
            ($earthBary[2] ?? 0.0) - ($sunBary[2] ?? 0.0),
        ];
        $sunLight = [
            ($sunBary[0] ?? 0.0) - $lightTimeDays * ($sunBary[3] ?? 0.0),
            ($sunBary[1] ?? 0.0) - $lightTimeDays * ($sunBary[4] ?? 0.0),
            ($sunBary[2] ?? 0.0) - $lightTimeDays * ($sunBary[5] ?? 0.0),
        ];
        $q = [
            ($xx[0] ?? 0.0) + ($earthBary[0] ?? 0.0) - $sunLight[0],
            ($xx[1] ?? 0.0) + ($earthBary[1] ?? 0.0) - $sunLight[1],
            ($xx[2] ?? 0.0) + ($earthBary[2] ?? 0.0) - $sunLight[2],
        ];

        $ru = self::vecNorm3($u);
        $re = self::vecNorm3($e);
        $rq = self::vecNorm3($q);
        if ($ru <= 0.0 || $re <= 0.0 || $rq <= 0.0) {
            return $xx;
        }

        for ($i = 0; $i < 3; $i++) {
            $u[$i] /= $ru;
            $e[$i] /= $re;
            $q[$i] /= $rq;
        }

        $uq = self::dot3($u, $q);
        $ue = max(-1.0, min(1.0, self::dot3($u, $e)));
        $qe = self::dot3($q, $e);
        $sina = sqrt(max(0.0, 1.0 - $ue * $ue));
        $sinSunRadius = self::SUN_RADIUS_RAD / $re;
        $meff = ($sinSunRadius > 0.0 && $sina < $sinSunRadius)
            ? self::solarEffectiveMass($sina / $sinSunRadius)
            : 1.0;

        $g1 = 2.0 * self::HELGRAVCONST * $meff
            / (self::CLIGHT_M_S * self::CLIGHT_M_S)
            / self::AUNIT_M
            / $re;
        $g2 = 1.0 + $qe;
        if (abs($g2) < 1e-15) {
            return $xx;
        }

        for ($i = 0; $i < 3; $i++) {
            $xx[$i] = $ru * ($u[$i] + ($g1 / $g2) * ($uq * $e[$i] - $ue * $q[$i]));
        }
        return $xx;
    }

    private static function solarEffectiveMass(float $r): float
    {
        if ($r <= 0.0) {
            return 0.0;
        }
        if ($r >= 1.0) {
            return 1.0;
        }
        static $eff = [
            [1.000, 1.000000], [0.990, 0.999979], [0.980, 0.999940], [0.970, 0.999881],
            [0.960, 0.999811], [0.950, 0.999724], [0.940, 0.999622], [0.930, 0.999497],
            [0.920, 0.999354], [0.910, 0.999192], [0.900, 0.999000], [0.890, 0.998786],
            [0.880, 0.998535], [0.870, 0.998242], [0.860, 0.997919], [0.850, 0.997571],
            [0.840, 0.997198], [0.830, 0.996792], [0.820, 0.996316], [0.810, 0.995791],
            [0.800, 0.995226], [0.790, 0.994625], [0.780, 0.993991], [0.770, 0.993326],
            [0.760, 0.992598], [0.750, 0.991770], [0.740, 0.990873], [0.730, 0.989919],
            [0.720, 0.988912], [0.710, 0.987856], [0.700, 0.986755], [0.690, 0.985610],
            [0.680, 0.984398], [0.670, 0.982986], [0.660, 0.981437], [0.650, 0.979779],
            [0.640, 0.978024], [0.630, 0.976182], [0.620, 0.974256], [0.610, 0.972253],
            [0.600, 0.970174], [0.590, 0.968024], [0.580, 0.965594], [0.570, 0.962797],
            [0.560, 0.959758], [0.550, 0.956515], [0.540, 0.953088], [0.530, 0.949495],
            [0.520, 0.945741], [0.510, 0.941838], [0.500, 0.937790], [0.490, 0.933563],
            [0.480, 0.928668], [0.470, 0.923288], [0.460, 0.917527], [0.450, 0.911432],
            [0.440, 0.905035], [0.430, 0.898353], [0.420, 0.891022], [0.410, 0.882940],
            [0.400, 0.874312], [0.390, 0.865206], [0.380, 0.855423], [0.370, 0.844619],
            [0.360, 0.833074], [0.350, 0.820876], [0.340, 0.808031], [0.330, 0.793962],
            [0.320, 0.778931], [0.310, 0.763021], [0.300, 0.745815], [0.290, 0.727557],
            [0.280, 0.708234], [0.270, 0.687583], [0.260, 0.665741], [0.250, 0.642597],
            [0.240, 0.618252], [0.230, 0.592586], [0.220, 0.565747], [0.210, 0.537697],
            [0.200, 0.508554], [0.190, 0.478420], [0.180, 0.447322], [0.170, 0.415454],
            [0.160, 0.382892], [0.150, 0.349955], [0.140, 0.316691], [0.130, 0.283565],
            [0.120, 0.250431], [0.110, 0.218327], [0.100, 0.186794], [0.090, 0.156287],
            [0.080, 0.128421], [0.070, 0.102237], [0.060, 0.077393], [0.050, 0.054833],
            [0.040, 0.036361], [0.030, 0.020953], [0.020, 0.009645], [0.010, 0.002767],
            [0.000, 0.000000],
        ];
        $n = count($eff);
        for ($i = 1; $i < $n; $i++) {
            if ($eff[$i][0] <= $r) {
                $r0 = $eff[$i - 1][0];
                $m0 = $eff[$i - 1][1];
                $r1 = $eff[$i][0];
                $m1 = $eff[$i][1];
                $f = ($r - $r0) / ($r1 - $r0);
                return $m0 + $f * ($m1 - $m0);
            }
        }
        return 0.0;
    }


    /** GCRS/ICRS frame bias to dynamical J2000. Swiss applies this for DE403+ .se1 files. */
    public static function frameBiasGcrsToJ2000(array $v): array
    {
        $rb = [
            [0.99999999999999412, 0.00000007078368695, -0.00000008056214212],
            [-0.00000007078368961, 0.99999999999999700, -0.00000003306427981],
            [0.00000008056213978, 0.00000003306428553, 0.99999999999999634],
        ];
        $x = $v[0]; $y = $v[1]; $z = $v[2];
        $out = [
            $x*$rb[0][0] + $y*$rb[1][0] + $z*$rb[2][0],
            $x*$rb[0][1] + $y*$rb[1][1] + $z*$rb[2][1],
            $x*$rb[0][2] + $y*$rb[1][2] + $z*$rb[2][2],
            $v[3] ?? 0.0, $v[4] ?? 0.0, $v[5] ?? 0.0,
        ];
        if (count($v) >= 6) {
            $vx = $v[3]; $vy = $v[4]; $vz = $v[5];
            $out[3] = $vx*$rb[0][0] + $vy*$rb[1][0] + $vz*$rb[2][0];
            $out[4] = $vx*$rb[0][1] + $vy*$rb[1][1] + $vz*$rb[2][1];
            $out[5] = $vx*$rb[0][2] + $vy*$rb[1][2] + $vz*$rb[2][2];
        }
        return $out;
    }

    public static function echeb(float $x, array $coef, int $offset, int $ncf): float
    {
        $x2 = 2.0 * $x;
        $br = 0.0; $brp2 = 0.0; $brpp = 0.0;
        for ($j = $ncf - 1; $j >= 0; $j--) {
            $brp2 = $brpp;
            $brpp = $br;
            $br = $x2 * $brpp - $brp2 + ($coef[$offset + $j] ?? 0.0);
        }
        return ($br - $brp2) * 0.5;
    }

    public static function edcheb(float $x, array $coef, int $offset, int $ncf): float
    {
        $x2 = 2.0 * $x;
        $bf = 0.0; $bj = 0.0; $xjp2 = 0.0; $xjpl = 0.0; $bjp2 = 0.0; $bjpl = 0.0;
        for ($j = $ncf - 1; $j >= 1; $j--) {
            $dj = (float)($j + $j);
            $xj = ($coef[$offset + $j] ?? 0.0) * $dj + $xjp2;
            $bj = $x2 * $bjpl - $bjp2 + $xj;
            $bf = $bjp2;
            $bjp2 = $bjpl;
            $bjpl = $bj;
            $xjp2 = $xjpl;
            $xjpl = $xj;
        }
        return ($bj - $bf) * 0.5;
    }
}

final class SwePlanData
{
    public int $ibdy = 0;
    public int $iflg = 0;
    public int $ncoe = 0;
    public int $lndx0 = 0;
    public int $nndx = 0;
    public float $tfstart = 0.0;
    public float $tfend = 0.0;
    public float $dseg = 0.0;
    public float $telem = 0.0;
    public float $prot = 0.0;
    public float $qrot = 0.0;
    public float $dprot = 0.0;
    public float $dqrot = 0.0;
    public float $rmax = 0.0;
    public float $peri = 0.0;
    public float $dperi = 0.0;
    /** @var float[] */ public array $refep = [];
    /** @var float[] */ public array $segp = [];
    public float $tseg0 = NAN;
    public float $tseg1 = NAN;
    public int $neval = 0;
}

final class SweSe1File
{
    public const TEST_ENDIAN = 0x00616263;
    public string $path;
    /** @var resource */ public $fh;
    public string $endian = 'little';
    public int $fversion = 0;
    public int $denum = 0;
    public float $tfstart = 0.0;
    public float $tfend = 0.0;
    public int $npl = 0;
    /** @var int[] */ public array $ipl = [];
    /** @var array<int,SwePlanData> */ public array $plans = [];
    public bool $isSingleAsteroid = false;

    public function __construct(string $path)
    {
        $this->path = $path;
        if (!is_readable($path)) {
            throw new SweSe1Error("Nelze otevrit .se1 soubor: $path");
        }
        $fh = fopen($path, 'rb');
        if (!$fh) {
            throw new SweSe1Error("Nelze otevrit .se1 soubor: $path");
        }
        $this->fh = $fh;
        $this->readConst();
    }

    public function close(): void
    {
        if (is_resource($this->fh)) fclose($this->fh);
    }

    private function readLineRequired(): string
    {
        $line = fgets($this->fh);
        if ($line === false) throw new SweSe1Error("Poskozeny .se1 soubor: {$this->path}");
        return rtrim($line, "\r\n ");
    }

    private function readBytes(int $n): string
    {
        $b = fread($this->fh, $n);
        if ($b === false || strlen($b) !== $n) throw new SweSe1Error("Neocekavany konec .se1 souboru: {$this->path}");
        return $b;
    }

    private function seek(int $pos): void
    {
        if (fseek($this->fh, $pos, SEEK_SET) !== 0) throw new SweSe1Error("Nelze seek v .se1: {$this->path}");
    }

    private function readUInt(int $size, ?int $pos = null): int
    {
        if ($pos !== null) $this->seek($pos);
        $b = $this->readBytes($size);
        return $this->uintFromBytes($b, 0, $size);
    }

    private function uintFromBytes(string $data, int $offset, int $size): int
    {
        if ($offset < 0 || $size < 1 || $offset + $size > strlen($data)) {
            throw new SweSe1Error("Neocekavany konec .se1 bufferu: {$this->path}");
        }

        $v = 0;
        if ($this->endian === 'little') {
            for ($i = $size - 1; $i >= 0; $i--) $v = ($v << 8) + ord($data[$offset + $i]);
        } else {
            for ($i = 0; $i < $size; $i++) $v = ($v << 8) + ord($data[$offset + $i]);
        }
        return $v;
    }

    private function readInt32(?int $pos = null): int
    {
        $u = $this->readUInt(4, $pos);
        return ($u >= 0x80000000) ? $u - 0x100000000 : $u;
    }

    private function readDouble(?int $pos = null): float
    {
        if ($pos !== null) $this->seek($pos);
        $b = $this->readBytes(8);
        $arr = unpack($this->endian === 'little' ? 'e' : 'E', $b);
        return (float)$arr[1];
    }

    /** @return float[] */
    private function readDoubles(int $count): array
    {
        $out = [];
        for ($i = 0; $i < $count; $i++) $out[] = $this->readDouble();
        return $out;
    }

    private function readConst(): void
    {
        $line1 = $this->readLineRequired();
        if (!preg_match('/(\d+)/', $line1, $m)) throw new SweSe1Error("Chybi verze .se1: {$this->path}");
        $this->fversion = (int)$m[1];
        $fileLine = strtolower($this->readLineRequired());
        $base = strtolower(basename($this->path));
        $this->isSingleAsteroid = preg_match('/^(?:se\d{5}s?|s\d{6}s?)\.se1$/', $base) === 1;
        if (trim($fileLine) !== $base) {
            throw new SweSe1Error("Jmeno .se1 nesedi: soubor $base, uvnitr $fileLine");
        }
        $this->readLineRequired(); // copyright
        if ($this->isSingleAsteroid) {
            // Swiss read_const() reads one text line with orbital elements before
            // the binary header in numbered asteroid files (SEI_FILE_ANY_AST).
            $this->readLineRequired();
        }

        $testBytes = $this->readBytes(4);
        $le = unpack('V', $testBytes)[1];
        $be = unpack('N', $testBytes)[1];
        if ($le === self::TEST_ENDIAN) $this->endian = 'little';
        elseif ($be === self::TEST_ENDIAN) $this->endian = 'big';
        else throw new SweSe1Error("Endian test selhal v .se1: {$this->path}");

        $fileLen = $this->readInt32();
        clearstatcache(true, $this->path);
        $realLen = filesize($this->path);
        if ($realLen !== false && $fileLen !== (int)$realLen) {
            throw new SweSe1Error("Delka .se1 nesedi: hlavicka $fileLen, real $realLen, {$this->path}");
        }
        $this->denum = $this->readInt32();
        $this->tfstart = $this->readDouble();
        $this->tfend = $this->readDouble();
        $nplan = $this->readUInt(2);
        $nbytesIpl = 2;
        if ($nplan > 256) {
            $nbytesIpl = 4;
            $nplan %= 256;
        }
        if ($nplan < 1 || $nplan > 50) throw new SweSe1Error("Spatny pocet teles v .se1: $nplan");
        $this->npl = $nplan;
        for ($i = 0; $i < $nplan; $i++) $this->ipl[] = $this->readUInt($nbytesIpl);
        if ($this->isSingleAsteroid) {
            // Old single-asteroid files contain a 30-byte asteroid name field here.
            // The current web calculations only need coordinates; keeping the file
            // pointer aligned is what matters.
            $this->readBytes(30);
        }

        // CRC kontrolu zatim preskakujeme, ale pozici cteme stejne jako C read_const().
        $crcPos = ftell($this->fh);
        $this->readUInt(4);
        $this->readDoubles(5); // general constants, unused here

        foreach ($this->ipl as $ipli) {
            $p = new SwePlanData();
            $p->ibdy = $ipli;
            $p->lndx0 = $this->readInt32();
            $p->iflg = $this->readUInt(1);
            $p->ncoe = $this->readUInt(1);
            $lng = $this->readInt32();
            $p->rmax = $lng / 1000.0;
            $d = $this->readDoubles(10);
            [$p->tfstart, $p->tfend, $p->dseg, $p->telem, $p->prot, $p->dprot, $p->qrot, $p->dqrot, $p->peri, $p->dperi] = $d;
            $p->nndx = (int)(($p->tfend - $p->tfstart + 0.1) / $p->dseg);
            if (($p->iflg & SweSe1::SEI_FLG_ELLIPSE) !== 0) {
                $p->refep = $this->readDoubles(2 * $p->ncoe);
            }
            $this->plans[$ipli] = $p;
        }
    }

    public function getPlan(int $ipli): SwePlanData
    {
        if (!isset($this->plans[$ipli])) {
            throw new SweSe1Error("Teleso $ipli neni v souboru " . basename($this->path));
        }
        return $this->plans[$ipli];
    }

    public function ensureSegment(SwePlanData $p, float $tjd, int $ipli): void
    {
        if ($p->segp && $tjd >= $p->tseg0 && $tjd <= $p->tseg1) return;
        $iseg = (int)(($tjd - $p->tfstart) / $p->dseg);
        $p->tseg0 = $p->tfstart + $iseg * $p->dseg;
        $p->tseg1 = $p->tseg0 + $p->dseg;
        $indexPos = $p->lndx0 + $iseg * 3;
        $coeffPos = $this->readUInt(3, $indexPos);
        $p->segp = array_fill(0, $p->ncoe * 3, 0.0);

        clearstatcache(true, $this->path);
        $fileSize = filesize($this->path);
        $maxChunk = is_int($fileSize) && $fileSize > $coeffPos
            ? min(65536, $fileSize - $coeffPos)
            : 65536;
        $this->seek($coeffPos);
        $segmentData = $this->readBytes($maxChunk);
        $offset = 0;
        $readBufferedUInt = function (int $size) use ($segmentData, &$offset): int {
            $value = $this->uintFromBytes($segmentData, $offset, $size);
            $offset += $size;
            return $value;
        };

        for ($icoord = 0; $icoord < 3; $icoord++) {
            $idbl = $icoord * $p->ncoe;
            $c0 = $readBufferedUInt(1);
            $c1 = $readBufferedUInt(1);
            $nsize = [];
            if (($c0 & 128) !== 0) {
                $c2 = $readBufferedUInt(1);
                $c3 = $readBufferedUInt(1);
                $nsize = [intdiv($c1,16), $c1 % 16, intdiv($c2,16), $c2 % 16, intdiv($c3,16), $c3 % 16];
            } else {
                $nsize = [intdiv($c0,16), $c0 % 16, intdiv($c1,16), $c1 % 16];
            }
            $nsizes = count($nsize);
            $nco = array_sum($nsize);
            if ($nco > $p->ncoe) throw new SweSe1Error("V .se1 je $nco koeficientu, maximum {$p->ncoe}");
            for ($i = 0; $i < $nsizes; $i++) {
                if ($nsize[$i] === 0) continue;
                if ($i < 4) {
                    $bytes = 4 - $i;
                    for ($m = 0; $m < $nsize[$i]; $m++, $idbl++) {
                        $u = $readBufferedUInt($bytes);
                        // C: (longs[m]+1)/2 resp. longs[m]/2 with INTEGER division.
                        if (($u & 1) !== 0) $p->segp[$idbl] = -(intdiv($u + 1, 2) / 1.0e9 * $p->rmax / 2.0);
                        else $p->segp[$idbl] = intdiv($u, 2) / 1.0e9 * $p->rmax / 2.0;
                    }
                } elseif ($i === 4) {
                    $k = intdiv($nsize[$i] + 1, 2);
                    $jcount = 0;
                    for ($m = 0; $m < $k && $jcount < $nsize[$i]; $m++) {
                        $val = $readBufferedUInt(1);
                        for ($n = 0, $o = 16; $n < 2 && $jcount < $nsize[$i]; $n++, $jcount++, $idbl++, $val %= $o, $o = intdiv($o, 16)) {
                            // C: ((longs[m]+o)/o/2) with INTEGER division, so the
                            // lower nibble must not leak into the value.
                            if (($val & $o) !== 0) $p->segp[$idbl] = -(intdiv(intdiv($val + $o, $o), 2) * $p->rmax / 2.0 / 1.0e9);
                            else $p->segp[$idbl] = intdiv(intdiv($val, $o), 2) * $p->rmax / 2.0 / 1.0e9;
                        }
                    }
                } elseif ($i === 5) {
                    $k = intdiv($nsize[$i] + 3, 4);
                    $jcount = 0;
                    for ($m = 0; $m < $k && $jcount < $nsize[$i]; $m++) {
                        $val = $readBufferedUInt(1);
                        for ($n = 0, $o = 64; $n < 4 && $jcount < $nsize[$i]; $n++, $jcount++, $idbl++, $val %= $o, $o = intdiv($o, 4)) {
                            if (($val & $o) !== 0) $p->segp[$idbl] = -(intdiv(intdiv($val + $o, $o), 2) * $p->rmax / 2.0 / 1.0e9);
                            else $p->segp[$idbl] = intdiv(intdiv($val, $o), 2) * $p->rmax / 2.0 / 1.0e9;
                        }
                    }
                }
            }
        }
        if (($p->iflg & SweSe1::SEI_FLG_ROTATE) !== 0) {
            SweSe1::rotBack($p, $ipli);
        } else {
            $p->neval = $p->ncoe;
        }
    }
}

final class SweSe1
{
    public const SE_SUN = 0;
    public const SE_MOON = 1;
    public const SE_MERCURY = 2;
    public const SE_VENUS = 3;
    public const SE_MARS = 4;
    public const SE_JUPITER = 5;
    public const SE_SATURN = 6;
    public const SE_URANUS = 7;
    public const SE_NEPTUNE = 8;
    public const SE_PLUTO = 9;
    public const SE_MEAN_NODE = 10;
    public const SE_TRUE_NODE = 11;
    public const SE_CHIRON = 12;
    public const SE_PHOLUS = 13;
    public const SE_CERES = 14;
    public const SE_PALLAS = 15;
    public const SE_JUNO = 16;
    public const SE_VESTA = 17;
    public const SE_MEAN_APOG = 1012;
    public const SE_OSCU_APOG = 1013;
    public const SE_EARTH = 1014;
    public const SE_FICT_OFFSET = 40;
    public const SE_FICT_MAX = 999;
    public const SE_CUPIDO = 40;
    public const SE_HADES = 41;
    public const SE_ZEUS = 42;
    public const SE_KRONOS = 43;
    public const SE_APOLLON = 44;
    public const SE_ADMETOS = 45;
    public const SE_VULCANUS = 46;
    public const SE_POSEIDON = 47;
    public const SE_ISIS_TRANSPLUTO = 48;
    public const SE_NIBIRU = 49;
    public const SE_HARRINGTON = 50;
    public const SE_LEVERRIER = 51;
    public const SE_ADAMS = 52;
    public const SE_LOWELL = 53;
    public const SE_PICKERING = 54;
    public const SE_VULCAN = 55;
    public const SE_SELENA = 56;
    public const SE_WHITE_MOON = 56;
    public const SE_PROSERPINA = 57;
    public const SE_WALDEMATH = 58;
    public const SE_AST_OFFSET = 10000;

    private const EARTH_MU_AU3_PER_DAY2 = 8.887692725266105e-10;
    private const KGAUSS = 0.01720209895;
    private const KGAUSS_GEO = 0.0000298122353216;
    private const SUN_EARTH_MRAT = 332946.050895;

    public const SEI_EMB = 0;
    public const SEI_EARTH = 0;
    public const SEI_SUN = 0;
    public const SEI_MOON = 1;
    public const SEI_MERCURY = 2;
    public const SEI_VENUS = 3;
    public const SEI_MARS = 4;
    public const SEI_JUPITER = 5;
    public const SEI_SATURN = 6;
    public const SEI_URANUS = 7;
    public const SEI_NEPTUNE = 8;
    public const SEI_PLUTO = 9;
    public const SEI_SUNBARY = 10;

    public const SEI_FLG_HELIO = 1;
    public const SEI_FLG_ROTATE = 2;
    public const SEI_FLG_ELLIPSE = 4;
    public const SEI_FLG_EMBHEL = 8;
    public const EARTH_MOON_MRAT = 81.30055985272827;

    /** @var array<int,string> */
    public static array $names = [
        self::SE_SUN => 'Sun', self::SE_MOON => 'Moon', self::SE_MERCURY => 'Mercury', self::SE_VENUS => 'Venus', self::SE_MARS => 'Mars',
        self::SE_JUPITER => 'Jupiter', self::SE_SATURN => 'Saturn', self::SE_URANUS => 'Uranus', self::SE_NEPTUNE => 'Neptune', self::SE_PLUTO => 'Pluto',
        self::SE_MEAN_NODE => 'mean Node', self::SE_TRUE_NODE => 'true Node',
        self::SE_MEAN_APOG => 'mean Apogee', self::SE_OSCU_APOG => 'osc. Apogee', self::SE_EARTH => 'Earth',
        self::SE_CHIRON => 'Chiron', self::SE_PHOLUS => 'Pholus', self::SE_CERES => 'Ceres',
        self::SE_PALLAS => 'Pallas', self::SE_JUNO => 'Juno', self::SE_VESTA => 'Vesta',
        self::SE_CUPIDO => 'Cupido', self::SE_HADES => 'Hades', self::SE_ZEUS => 'Zeus',
        self::SE_KRONOS => 'Kronos', self::SE_APOLLON => 'Apollon', self::SE_ADMETOS => 'Admetos',
        self::SE_VULCANUS => 'Vulcanus', self::SE_POSEIDON => 'Poseidon',
        self::SE_ISIS_TRANSPLUTO => 'Isis-Transpluto', self::SE_NIBIRU => 'Nibiru',
        self::SE_HARRINGTON => 'Harrington', self::SE_LEVERRIER => 'Leverrier',
        self::SE_ADAMS => 'Adams', self::SE_LOWELL => 'Lowell', self::SE_PICKERING => 'Pickering',
        self::SE_VULCAN => 'Vulcan', self::SE_SELENA => 'Selena/White Moon',
        self::SE_PROSERPINA => 'Proserpina',
        self::SE_WALDEMATH => 'Waldemath',
    ];

    /** @var array<string,int> */
    public static array $bodyMap = [
        '0'=>0,'1'=>1,'2'=>2,'3'=>3,'4'=>4,'5'=>5,'6'=>6,'7'=>7,'8'=>8,'9'=>9,
        'm'=>10,'t'=>11,
        'A'=>self::SE_MEAN_APOG,'a'=>self::SE_MEAN_APOG,
        'B'=>self::SE_OSCU_APOG,'b'=>self::SE_OSCU_APOG,
        'C'=>self::SE_EARTH,'c'=>self::SE_EARTH,
        'D'=>self::SE_CHIRON,'d'=>self::SE_CHIRON,
        'E'=>self::SE_PHOLUS,'e'=>self::SE_PHOLUS,
        'F'=>self::SE_CERES,'f'=>self::SE_CERES,
        'G'=>self::SE_PALLAS,'g'=>self::SE_PALLAS,
        'H'=>self::SE_JUNO,'h'=>self::SE_JUNO,
        'I'=>self::SE_VESTA,'i'=>self::SE_VESTA,
        'J'=>self::SE_CUPIDO,
        'K'=>self::SE_HADES,
        'L'=>self::SE_ZEUS,
        'M'=>self::SE_KRONOS,
        'N'=>self::SE_APOLLON,
        'O'=>self::SE_ADMETOS,
        'P'=>self::SE_VULCANUS,
        'Q'=>self::SE_POSEIDON,
        'R'=>self::SE_ISIS_TRANSPLUTO,
        'S'=>self::SE_NIBIRU,
        'T'=>self::SE_HARRINGTON,
        'U'=>self::SE_LEVERRIER,
        'V'=>self::SE_ADAMS,
        'W'=>self::SE_LOWELL,
        'X'=>self::SE_PICKERING,
        'Y'=>self::SE_VULCAN,
        'Z'=>self::SE_SELENA,
        'w'=>self::SE_WALDEMATH,
    ];

    private string $epheDir;
    /** @var array<string,SweSe1File> */ private array $files = [];
    /** @var array<string,int> */ private array $fileLastUsed = [];
    private int $fileUseCounter = 0;
    private int $maxOpenFiles = 5;

    public function __construct(string $epheDir, int $maxOpenFiles = 5)
    {
        $this->epheDir = rtrim(str_replace('\\', '/', $epheDir), '/');
        $this->maxOpenFiles = max(1, $maxOpenFiles);
    }

    public function close(): void
    {
        foreach ($this->files as $f) $f->close();
        $this->files = [];
        $this->fileLastUsed = [];
    }

    public function fileName(float $tjd, int $ipli): string
    {
        if ($ipli > self::SE_AST_OFFSET) {
            $mpc = $ipli - self::SE_AST_OFFSET;
            $subdir = 'ast' . intdiv($mpc, 1000);
            if ($mpc > 99999) {
                $long = sprintf('s%06d.se1', $mpc);
                $short = sprintf('s%06ds.se1', $mpc);
            } else {
                $long = sprintf('se%05d.se1', $mpc);
                $short = sprintf('se%05ds.se1', $mpc);
            }
            $candidates = [
                $subdir . '/' . $long,
                $subdir . '/' . $short,
                $long,
                $short,
            ];
            foreach ($candidates as $candidate) {
                if (is_file($this->epheDir . '/' . $candidate)) {
                    return $candidate;
                }
            }
            return $candidates[0];
        }
        if ($ipli === self::SEI_MOON) $prefix = 'semo';
        elseif ($ipli >= self::SE_CHIRON && $ipli <= self::SE_VESTA) $prefix = 'seas';
        elseif (in_array($ipli, [self::SEI_EMB,self::SEI_MERCURY,self::SEI_VENUS,self::SEI_MARS,self::SEI_JUPITER,self::SEI_SATURN,self::SEI_URANUS,self::SEI_NEPTUNE,self::SEI_PLUTO,self::SEI_SUNBARY], true)) $prefix = 'sepl';
        else $prefix = 'sepl';
        [$year] = SweMath::revjul($tjd, $tjd >= 2305447.5);
        $icty = intdiv($year, 100);
        if ($year < 0 && $year % 100 !== 0) $icty--;
        while ($icty % 6 !== 0) $icty--;
        $sign = $icty < 0 ? 'm' : '_';
        return sprintf('%s%s%02d.se1', $prefix, $sign, abs($icty));
    }

    private function openFile(float $tjd, int $ipli): SweSe1File
    {
        $fn = $this->fileName($tjd, $ipli);
        if (!isset($this->files[$fn])) {
            $path = $this->epheDir . '/' . $fn;
            $this->files[$fn] = new SweSe1File($path);
            $this->fileLastUsed[$fn] = ++$this->fileUseCounter;
            $this->pruneOpenFiles($fn);
        }
        $f = $this->files[$fn];
        $this->fileLastUsed[$fn] = ++$this->fileUseCounter;
        if ($tjd < $f->tfstart || $tjd > $f->tfend) {
            throw new SweSe1Error("JD $tjd je mimo rozsah $fn ({$f->tfstart}..{$f->tfend})");
        }
        return $f;
    }

    private function pruneOpenFiles(string $keepFile): void
    {
        while (count($this->files) > $this->maxOpenFiles) {
            $oldestName = null;
            $oldestUse = PHP_INT_MAX;
            foreach ($this->fileLastUsed as $name => $lastUsed) {
                if ($name === $keepFile) {
                    continue;
                }
                if ($lastUsed < $oldestUse) {
                    $oldestName = $name;
                    $oldestUse = $lastUsed;
                }
            }
            if ($oldestName === null) {
                return;
            }
            $this->files[$oldestName]->close();
            unset($this->files[$oldestName], $this->fileLastUsed[$oldestName]);
        }
    }

    private function deltaTSeconds(float $jdUt): float
    {
        $probeEt = $jdUt + SweMath::deltaTSeconds($jdUt) / 86400.0;
        $moonFile = $this->openFile($probeEt, self::SEI_MOON);
        return SweMath::deltaTSeconds($jdUt, $moonFile->denum);
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    public function raw(int $ipli, float $tjdEt): array
    {
        $f = $this->openFile($tjdEt, $ipli);
        $p = $f->getPlan($ipli);
        $f->ensureSegment($p, $tjdEt, $ipli);
        $u = (($tjdEt - $p->tseg0) / $p->dseg) * 2.0 - 1.0;
        $n = max(1, $p->neval ?: $p->ncoe);
        $x = [];
        for ($i = 0; $i < 3; $i++) {
            $off = $i * $p->ncoe;
            $x[$i] = SweMath::echeb($u, $p->segp, $off, $n);
            $x[$i + 3] = SweMath::edcheb($u, $p->segp, $off, $n) / $p->dseg * 2.0;
        }
        if ($ipli === self::SEI_SUNBARY && (($p->iflg & self::SEI_FLG_EMBHEL) !== 0)) {
            $emb = $this->raw(self::SEI_EMB, $tjdEt);
            for ($i = 0; $i < 6; $i++) $x[$i] = $emb[$i] - $x[$i];
        }
        return [$x[0],$x[1],$x[2],$x[3],$x[4],$x[5]];
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function earthBary(float $tjdEt): array
    {
        $emb = $this->raw(self::SEI_EMB, $tjdEt);
        $moon = $this->raw(self::SEI_MOON, $tjdEt);
        for ($i = 0; $i < 6; $i++) $emb[$i] -= $moon[$i] / (self::EARTH_MOON_MRAT + 1.0);
        return $emb;
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    public function earthBaryState(float $tjdEt): array
    {
        return $this->earthBary($tjdEt);
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    public function sunBaryState(float $tjdEt): array
    {
        return $this->raw(self::SEI_SUNBARY, $tjdEt);
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function baryBody(int $body, float $tjdEt): array
    {
        if ($body === self::SE_SUN) return $this->raw(self::SEI_SUNBARY, $tjdEt);
        if ($body === self::SE_MOON) return $this->raw(self::SEI_MOON, $tjdEt); // geocentric, special-cased by calcVector()
        $ipli = $body;
        $x = $this->raw($ipli, $tjdEt);
        $f = $this->openFile($tjdEt, $ipli);
        $p = $f->getPlan($ipli);
        if ($body > self::SE_AST_OFFSET) {
            // Swiss sweph.c treats numbered asteroid files as heliocentric and
            // converts them to barycentric by adding the barycentric Sun.
            $sunb = $this->raw(self::SEI_SUNBARY, $tjdEt);
            for ($i = 0; $i < 6; $i++) $x[$i] += $sunb[$i];
        } elseif (($p->iflg & self::SEI_FLG_HELIO) !== 0) {
            $sunb = $this->raw(self::SEI_SUNBARY, $tjdEt);
            for ($i = 0; $i < 6; $i++) $x[$i] += $sunb[$i];
        } elseif ($body >= self::SE_CHIRON && $body <= self::SE_VESTA) {
            // Swiss reference sweph.c: hlavni asteroidy v SWIEPH souborech jsou
            // heliocentricke a pro geocentricky vypocet se musi prevest na barycentricke
            // prictenim barycentrickeho Slunce.
            $sunb = $this->raw(self::SEI_SUNBARY, $tjdEt);
            for ($i = 0; $i < 6; $i++) $x[$i] += $sunb[$i];
        }
        return $x;
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function geocentricVector(int $body, float $tjdEt): array
    {
        if ($body === self::SE_MOON) return $this->raw(self::SEI_MOON, $tjdEt);
        $earth = $this->earthBary($tjdEt);
        $b = $this->baryBody($body, $tjdEt);
        $g = [];
        for ($i = 0; $i < 6; $i++) $g[$i] = $b[$i] - $earth[$i];
        return [$g[0],$g[1],$g[2],$g[3],$g[4],$g[5]];
    }

    /**
     * Geocentric vector with light-time and optional annual aberration.
     * Vector remains on J2000 equator; precession/nutation are applied later.
     * @return array{0:float,1:float,2:float,3:float,4:float,5:float}
     */
    private function apparentGeocentricVector(int $body, float $jdEt, bool $lightTime = true, bool $aberration = true): array
    {
        $earth = $this->earthBary($jdEt);
        $lightTimeDays = 0.0;
        if (!$lightTime) {
            $geo = $this->geocentricVector($body, $jdEt);
        } elseif ($body === self::SE_MOON) {
            // Swiss Ephemeris style lunar light-time:
            // Moon(t-dt) + Earth(t-dt) - Earth(t). The small Earth displacement
            // during lunar light-time changes apparent lunar longitude by several arc seconds.
            $moon0 = $this->raw(self::SEI_MOON, $jdEt);
            $dt = SweMath::vecNorm3($moon0) / SweMath::CLIGHT_AUDAY;
            $lightTimeDays = $dt;
            $moon2 = $this->raw(self::SEI_MOON, $jdEt - $dt);
            $earth2 = $this->earthBary($jdEt - $dt);
            $geo = [];
            for ($i = 0; $i < 6; $i++) {
                $geo[$i] = $moon2[$i] + $earth2[$i] - $earth[$i];
            }
        } else {
            $dt = 0.0;
            $geo = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0];
            for ($iter = 0; $iter < 3; $iter++) {
                $b = $this->baryBody($body, $jdEt - $dt);
                for ($i = 0; $i < 6; $i++) $geo[$i] = $b[$i] - $earth[$i];
                $dt = SweMath::vecNorm3($geo) / SweMath::CLIGHT_AUDAY;
            }
            $lightTimeDays = $dt;
        }
        // Swiss C: app_pos_etc_sun() and app_pos_etc_moon() apply NO light
        // deflection; only app_pos_etc_plan() (planets, asteroids) does.
        if ($lightTime && $body !== self::SE_SUN && $body !== self::SE_MOON) {
            $sunBary = $this->raw(self::SEI_SUNBARY, $jdEt);
            $geo = SweMath::deflectLight($geo, $earth, $sunBary, $lightTimeDays);
        }
        if ($aberration) {
            $geo = SweMath::aberrLight($geo, $earth);
        }
        return [$geo[0],$geo[1],$geo[2],$geo[3] ?? 0.0,$geo[4] ?? 0.0,$geo[5] ?? 0.0];
    }

    /** @return array{lon:float,lat:float,dist:float} */
    private function vectorToEclipticOfDate(array $geoJ2000, float $jdEt, bool $nutation = true): array
    {
        $geoJ2000 = SweMath::frameBiasGcrsToJ2000($geoJ2000);
        $v = SweMath::precessJ2000ToDate($geoJ2000, $jdEt);
        if ($nutation) {
            $nu = SweMath::nutationShort($jdEt);
            $v = SweMath::applyNutation($v, $jdEt);
            return SweMath::equToEclWithEps($v, $nu['epsTrue']);
        }
        return SweMath::equToEclWithEps($v, SweMath::meanObliquityDeg($jdEt) * SweMath::DEG2RAD);
    }

    /** @return array{lon:float,lat:float,dist:float} */
    private function j2000EquToEclipticOfDate(array $geoJ2000, float $jdEt, bool $nutation = true): array
    {
        $v = SweMath::precessJ2000ToDate($geoJ2000, $jdEt);
        if ($nutation) {
            $nu = SweMath::nutationShort($jdEt);
            $v = SweMath::applyNutation($v, $jdEt);
            return SweMath::equToEclWithEps($v, $nu['epsTrue']);
        }
        return SweMath::equToEclWithEps($v, SweMath::meanObliquityDeg($jdEt) * SweMath::DEG2RAD);
    }

    /** @return array<int,string> */
    private function builtInFictitiousElementLines(): array
    {
        return [
            0 => 'J1900,J1900,163.7409,40.99837,0.00460,171.4333,129.8325,1.0833,Cupido',
            1 => 'J1900,J1900,27.6496,50.66744,0.00245,148.1796,161.3339,1.0500,Hades',
            2 => 'J1900,J1900,165.1232,59.21436,0.00120,299.0440,0.0000,0.0000,Zeus',
            3 => 'J1900,J1900,169.0193,64.81690,0.00305,208.8801,0.0000,0.0000,Kronos',
            4 => 'J1900,J1900,138.0533,70.29949,0.00000,0.0000,0.0000,0.0000,Apollon',
            5 => 'J1900,J1900,351.3350,73.62765,0.00000,0.0000,0.0000,0.0000,Admetos',
            6 => 'J1900,J1900,55.8983,77.25568,0.00000,0.0000,0.0000,0.0000,Vulcanus',
            7 => 'J1900,J1900,165.5163,83.66907,0.00000,0.0000,0.0000,0.0000,Poseidon',
            8 => '2368547.66,2431456.5,0.0,77.775,0.3,0.7,0,0,Isis-Transpluto',
            9 => '1856113.380954,1856113.380954,0.0,234.8921,0.981092,103.966,-44.567,158.708,Nibiru',
            10 => '2374696.5,J2000,0.0,101.2,0.411,208.5,275.4,32.4,Harrington',
            11 => '2395662.5,2395662.5,34.05,36.15,0.10761,284.75,0,0,Leverrier',
            12 => '2395662.5,2395662.5,24.28,37.25,0.12062,299.11,0,0,Adams',
            13 => '2425977.5,2425977.5,281,43.0,0.202,204.9,0,0,Lowell',
            14 => '2425977.5,2425977.5,48.95,55.1,0.31,280.1,100,15,Pickering',
            18 => '2414290.95827875,2414290.95827875,70.3407215 + 109023.2634989 * T,0.0068400705250028,0.1587,8.14049594 + 2393.47417444 * T,136.24878256 - 1131.71719709 * T,2.5,Waldemath,geo',
        ];
    }

    private function fictitiousElementIndex(int $body): ?int
    {
        if ($body >= self::SE_FICT_OFFSET && $body <= self::SE_FICT_MAX) {
            return $body - self::SE_FICT_OFFSET;
        }
        return null;
    }

    /** @return array{epoch:float,term_epoch:float,equinox:float,mano:string,sema:string,ecce:string,parg:string,node:string,incl:string,name:string,geo:bool,index:int} */
    private function fictitiousElements(int $body, float $jdEt): array
    {
        $targetIndex = $this->fictitiousElementIndex($body);
        if ($targetIndex === null) {
            throw new SweSe1Error('seorbel.txt: neznamy fiktivni bod');
        }

        $fallback = $this->builtInFictitiousElementLines();
        $line = $fallback[$targetIndex] ?? null;
        $path = $this->epheDir . '/seorbel.txt';
        if (is_readable($path)) {
            $idx = -1;
            $fh = fopen($path, 'rb');
            if ($fh !== false) {
                while (($raw = fgets($fh)) !== false) {
                    $raw = trim(preg_replace('/#.*/', '', $raw));
                    if ($raw === '') {
                        continue;
                    }
                    $idx++;
                    if ($idx === $targetIndex) {
                        $line = $raw;
                        break;
                    }
                }
                fclose($fh);
            }
        }
        if ($line === null) {
            throw new SweSe1Error('seorbel.txt: chybi orbitalni prvky pro fiktivni bod');
        }
        $parts = array_map('trim', explode(',', $line));
        if (count($parts) < 9) {
            throw new SweSe1Error('seorbel.txt: fiktivni bod nema platne orbitalni prvky');
        }
        $epoch = $this->parseEpoch($parts[0], $jdEt);
        $termEpoch = $epoch;
        if ($this->elementTermHasTime($parts[2])) {
            // Swiss read_elements_file(): when mean anomaly contains T terms,
            // epoch is reset to the calculation date so no daily motion is added twice.
            $epoch = $jdEt;
        }
        return [
            'epoch' => $epoch,
            'term_epoch' => $termEpoch,
            'equinox' => $this->parseEpoch($parts[1], $jdEt),
            'mano' => $parts[2],
            'sema' => $parts[3],
            'ecce' => $parts[4],
            'parg' => $parts[5],
            'node' => $parts[6],
            'incl' => $parts[7],
            'name' => $parts[8],
            'geo' => isset($parts[9]) && stripos($parts[9], 'geo') !== false,
            'index' => $targetIndex,
        ];
    }

    private function parseEpoch(string $value, float $jdEt): float
    {
        $v = strtolower(trim($value));
        if ($v === 'j2000') return 2451545.0;
        if ($v === 'b1950') return 2433282.42345905;
        if ($v === 'j1900') return 2415020.0;
        if ($v === 'jdate') return $jdEt;
        return (float)$value;
    }

    private function elementTermHasTime(string $expr): bool
    {
        return preg_match('/(^|[^A-Za-z])T[0-4]?([^A-Za-z0-9_]|$)/i', $expr) === 1;
    }

    private function evalElementTerm(string $expr, float $tDays): float
    {
        $t = $tDays / 36525.0;
        $expr = str_replace(["\t", ' '], '', trim($expr));
        if ($expr === '') {
            return 0.0;
        }
        if ($expr[0] !== '+' && $expr[0] !== '-') {
            $expr = '+' . $expr;
        }
        preg_match_all('/([+-])([^+-]+)/', $expr, $matches, PREG_SET_ORDER);
        $sum = 0.0;
        foreach ($matches as $m) {
            $sign = $m[1] === '-' ? -1.0 : 1.0;
            $factor = 1.0;
            foreach (explode('*', $m[2]) as $part) {
                $part = trim($part);
                if ($part === '') {
                    continue;
                }
                if (preg_match('/^T([0-4])?$/i', $part, $tm)) {
                    $pow = isset($tm[1]) && $tm[1] !== '' ? (int)$tm[1] : 1;
                    $factor *= $pow === 0 ? 1.0 : ($t ** $pow);
                } else {
                    $factor *= (float)$part;
                }
            }
            $sum += $sign * $factor;
        }
        return $sum;
    }

    private function solveKepler(float $m, float $ecc): float
    {
        $e = $m;
        for ($i = 0; $i < 20; $i++) {
            $delta = ($e - $ecc * sin($e) - $m) / max(1e-15, 1.0 - $ecc * cos($e));
            $e -= $delta;
            if (abs($delta) < 1e-14) {
                break;
            }
        }
        return $e;
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function fictitiousBaryJ2000State(int $body, float $jdEt): array
    {
        $el = $this->fictitiousElements($body, $jdEt);
        $epoch = $el['epoch'];
        $equinox = $el['equinox'];
        $termDays = $jdEt - $el['term_epoch'];
        $manoDeg = $this->evalElementTerm($el['mano'], $termDays);
        $sema = $this->evalElementTerm($el['sema'], $termDays);
        $ecce = $this->evalElementTerm($el['ecce'], $termDays);
        $parg = SweMath::norm360($this->evalElementTerm($el['parg'], $termDays)) * SweMath::DEG2RAD;
        $node = SweMath::norm360($this->evalElementTerm($el['node'], $termDays)) * SweMath::DEG2RAD;
        $incl = SweMath::norm360($this->evalElementTerm($el['incl'], $termDays)) * SweMath::DEG2RAD;
        if ($sema <= 0.0 || $ecce < 0.0 || $ecce >= 1.0) {
            throw new SweSe1Error($el['name'] . ': neplatne orbitalni prvky');
        }
        $dmotDeg = 0.9856076686 / $sema / sqrt($sema);
        if ($el['geo']) {
            $dmotDeg /= sqrt(self::SUN_EARTH_MRAT);
        }
        $motionDays = $jdEt - $epoch;
        $mano = SweMath::norm360($manoDeg + $motionDays * $dmotDeg) * SweMath::DEG2RAD;

        $E = $this->solveKepler($this->mod2pi($mano), $ecce);
        $cosE = cos($E);
        $sinE = sin($E);
        $fac = sqrt(max(0.0, (1.0 - $ecce) * (1.0 + $ecce)));
        $rho = max(1e-15, 1.0 - $ecce * $cosE);
        $x0 = $sema * ($cosE - $ecce);
        $y0 = $sema * $fac * $sinE;
        $k = ($el['geo'] ? self::KGAUSS_GEO : self::KGAUSS) / sqrt($sema);
        $vx0 = -$k * $sinE / $rho;
        $vy0 = $k * $fac * $cosE / $rho;

        $cosNode = cos($node); $sinNode = sin($node);
        $cosIncl = cos($incl); $sinIncl = sin($incl);
        $cosParg = cos($parg); $sinParg = sin($parg);
        $pqr = [
            $cosParg * $cosNode - $sinParg * $cosIncl * $sinNode,
            -$sinParg * $cosNode - $cosParg * $cosIncl * $sinNode,
            $sinIncl * $sinNode,
            $cosParg * $sinNode + $sinParg * $cosIncl * $cosNode,
            -$sinParg * $sinNode + $cosParg * $cosIncl * $cosNode,
            -$sinIncl * $cosNode,
            $sinParg * $sinIncl,
            $cosParg * $sinIncl,
            $cosIncl,
        ];
        $ecl = [
            $pqr[0] * $x0 + $pqr[1] * $y0,
            $pqr[3] * $x0 + $pqr[4] * $y0,
            $pqr[6] * $x0 + $pqr[7] * $y0,
            $pqr[0] * $vx0 + $pqr[1] * $vy0,
            $pqr[3] * $vx0 + $pqr[4] * $vy0,
            $pqr[6] * $vx0 + $pqr[7] * $vy0,
        ];

        $eps = SweMath::meanObliquityDeg($equinox) * SweMath::DEG2RAD;
        $ce = cos($eps); $se = sin($eps);
        $eq = [
            $ecl[0],
            $ce * $ecl[1] - $se * $ecl[2],
            $se * $ecl[1] + $ce * $ecl[2],
            $ecl[3],
            $ce * $ecl[4] - $se * $ecl[5],
            $se * $ecl[4] + $ce * $ecl[5],
        ];
        $pos = SweMath::precessDateToJ2000([$eq[0], $eq[1], $eq[2], 0.0, 0.0, 0.0], $equinox);
        $vel = SweMath::precessDateToJ2000([$eq[3], $eq[4], $eq[5], 0.0, 0.0, 0.0], $equinox);
        $state = [$pos[0], $pos[1], $pos[2], $vel[0], $vel[1], $vel[2]];
        if ($el['geo']) {
            $earth = $this->earthBary($jdEt);
            for ($i = 0; $i < 6; $i++) {
                $state[$i] += $earth[$i];
            }
        } else {
            $sun = $this->sunBaryState($jdEt);
            for ($i = 0; $i < 6; $i++) {
                $state[$i] += $sun[$i];
            }
        }
        return $state;
    }

    /** @return array{lon:float,lat:float,dist:float} */
    private function calcFictitiousAtEt(int $body, float $jdEt, bool $truePos, bool $noAberr, bool $noNutation): array
    {
        $state = $this->fictitiousBaryJ2000State($body, $jdEt);
        $earth = $this->earthBary($jdEt);
        $geo = [];
        if ($truePos) {
            for ($i = 0; $i < 6; $i++) {
                $geo[$i] = $state[$i] - $earth[$i];
            }
        } else {
            $dist = SweMath::vecNorm3([$state[0] - $earth[0], $state[1] - $earth[1], $state[2] - $earth[2]]);
            $dt = $dist / SweMath::CLIGHT_AUDAY;
            for ($i = 0; $i < 3; $i++) {
                $geo[$i] = $state[$i] - $dt * $state[$i + 3] - $earth[$i];
                $geo[$i + 3] = $state[$i + 3] - $earth[$i + 3];
            }
            $sunBary = $this->raw(self::SEI_SUNBARY, $jdEt);
            $geo = SweMath::deflectLight($geo, $earth, $sunBary, $dt);
            if (!$noAberr) {
                $geo = SweMath::aberrLight($geo, $earth);
            }
        }
        return $this->j2000EquToEclipticOfDate($geo, $jdEt, !$noNutation);
    }

    /** @return array{lon:float,lat:float,dist:float,slon:float,sdist:float,source:string} */
    private function calcFictitious(int $body, float $jdUt, bool $sidereal, bool $truePos, bool $noAberr, bool $noNutation): array
    {
        $jdEt = $jdUt + $this->deltaTSeconds($jdUt) / 86400.0;
        $calc = function (float $jdEt2) use ($body, $sidereal, $truePos, $noAberr, $noNutation): array {
            $ecl = $this->calcFictitiousAtEt($body, $jdEt2, $truePos, $noAberr, $noNutation);
            if ($sidereal) {
                $ecl['lon'] = SweMath::norm360($ecl['lon'] - SweMath::ayanamshaLahiri($jdEt2));
            }
            return $ecl;
        };
        $e = $calc($jdEt);
        $step = 0.001;
        $m1 = $calc($jdEt - $step);
        $p1 = $calc($jdEt + $step);
        $m2 = $calc($jdEt - 2.0 * $step);
        $p2 = $calc($jdEt + 2.0 * $step);
        $slon = (
            -SweMath::norm180($p2['lon'] - $e['lon'])
            + 8.0 * SweMath::norm180($p1['lon'] - $e['lon'])
            - 8.0 * SweMath::norm180($m1['lon'] - $e['lon'])
            + SweMath::norm180($m2['lon'] - $e['lon'])
        ) / (12.0 * $step);
        $sdist = (
            -($p2['dist'] - $e['dist'])
            + 8.0 * ($p1['dist'] - $e['dist'])
            - 8.0 * ($m1['dist'] - $e['dist'])
            + ($m2['dist'] - $e['dist'])
        ) / (12.0 * $step);
        $name = strtolower((string)(self::$names[$body] ?? 'fictitious'));
        $name = trim((string)preg_replace('/[^a-z0-9]+/', '-', $name), '-');
        if ($name === '') {
            $name = 'fictitious';
        }
        $source = $truePos ? 'seorbel-' . $name . '-geometric' : 'seorbel-' . $name . '-apparent';
        if ($noAberr) $source .= '-noaberr';
        if ($noNutation) $source .= '-nonut';
        return ['lon' => $e['lon'], 'lat' => $e['lat'], 'dist' => $e['dist'], 'slon' => $slon, 'sdist' => $sdist, 'source' => $source];
    }

    /**
     * Calculate astrology-oriented ecliptic longitude. Default is apparent
     * geocentric longitude of date. Set $truePos=true for geometric position.
     * @return array{lon:float,lat:float,dist:float,slon:float,sdist:float,source:string}
     */
    public function calcUt(float $jdUt, int $body, bool $sidereal = false, bool $truePos = false, bool $noAberr = false, bool $noNutation = false): array
    {
        if ($this->fictitiousElementIndex($body) !== null) {
            return $this->calcFictitious($body, $jdUt, $sidereal, $truePos, $noAberr, $noNutation);
        }
        if ($body === self::SE_MEAN_APOG || $body === self::SE_OSCU_APOG) {
            $pos = $this->calcApogee($jdUt, $body, $sidereal, $noNutation);
            $src = ($body === self::SE_OSCU_APOG ? 'se1-osculating-apogee' : 'formula-mean-apogee');
            if (!$noNutation) {
                $src .= '-nut';
            }
            return ['lon'=>$pos[0], 'lat'=>$pos[1], 'dist'=>$pos[2], 'slon'=>$pos[3], 'sdist'=>0.0, 'source'=>$src];
        }
        if ($body === self::SE_EARTH) {
            $calc = function (float $ju) use ($sidereal, $truePos, $noAberr, $noNutation): array {
                $sun = $this->calcUt($ju, self::SE_SUN, $sidereal, $truePos, $noAberr, $noNutation);
                return [
                    'lon' => SweMath::norm360($sun['lon'] + 180.0),
                    'lat' => -$sun['lat'],
                    'dist' => $sun['dist'],
                ];
            };
            $e = $calc($jdUt);
            $step = 0.05;
            $m = $calc($jdUt - $step);
            $p = $calc($jdUt + $step);
            return [
                'lon' => $e['lon'],
                'lat' => $e['lat'],
                'dist' => $e['dist'],
                'slon' => SweMath::norm180($p['lon'] - $m['lon']) / (2.0 * $step),
                'sdist' => ($p['dist'] - $m['dist']) / (2.0 * $step),
                'source' => 'derived-earth-from-sun',
            ];
        }
        if ($body === self::SE_MEAN_NODE || $body === self::SE_TRUE_NODE) {
            $pos = $this->calcNode($jdUt, $body, $sidereal, $noNutation);
            $src = ($body === self::SE_TRUE_NODE ? 'se1-tangent-true-node' : 'formula-mean-node');
            if (!$noNutation) $src .= '-nut';
            return ['lon'=>$pos[0], 'lat'=>$pos[1], 'dist'=>$pos[2], 'slon'=>$pos[3], 'sdist'=>0.0, 'source'=>$src];
        }
        $dt = $this->deltaTSeconds($jdUt) / 86400.0;
        $jdEt = $jdUt + $dt;
        $calc = function(float $jdEt2) use ($body, $sidereal, $truePos, $noAberr, $noNutation): array {
            $geo = $this->apparentGeocentricVector($body, $jdEt2, !$truePos, !$truePos && !$noAberr);
            $ecl = $this->vectorToEclipticOfDate($geo, $jdEt2, !$noNutation);
            if ($sidereal) $ecl['lon'] = SweMath::norm360($ecl['lon'] - SweMath::ayanamshaLahiri($jdEt2));
            return $ecl;
        };
        $e = $calc($jdEt);
        // Five-point numeric derivative keeps apparent speed stable around station points.
        $step = 0.001;
        $m1 = $calc($jdEt - $step);
        $p1 = $calc($jdEt + $step);
        $m2 = $calc($jdEt - 2.0 * $step);
        $p2 = $calc($jdEt + 2.0 * $step);
        $slon = (
            -SweMath::norm180($p2['lon'] - $e['lon'])
            + 8.0 * SweMath::norm180($p1['lon'] - $e['lon'])
            - 8.0 * SweMath::norm180($m1['lon'] - $e['lon'])
            + SweMath::norm180($m2['lon'] - $e['lon'])
        ) / (12.0 * $step);
        $sdist = (
            -($p2['dist'] - $e['dist'])
            + 8.0 * ($p1['dist'] - $e['dist'])
            - 8.0 * ($m1['dist'] - $e['dist'])
            + ($m2['dist'] - $e['dist'])
        ) / (12.0 * $step);
        $source = $truePos ? 'se1-geometric-true' : 'se1-apparent-light-defl-aberr-nut2000b';
        if ($noAberr) $source .= '-noaberr';
        if ($noNutation) $source .= '-nonut';
        return [
            'lon'=>$e['lon'], 'lat'=>$e['lat'], 'dist'=>$e['dist'],
            'slon'=>$slon,
            'sdist'=>$sdist,
            'source'=>$source,
        ];
    }

    /**
     * Linear interpolation in the Swiss DE431-fit correction tables for the
     * mean lunar node/apsis (corr_mean_node()/corr_mean_apog() in swemmoon.c).
     * 100-Gregorian-year steps from 1 Jan -13100 greg.; zero outside DE431.
     * @param float[] $tab
     */
    private static function corrTableDeg(array $tab, float $jdEt): float
    {
        if ($jdEt < -3027215.5 || $jdEt > 7930192.5) {
            return 0.0;
        }
        $dJ = $jdEt - (-3063616.5);
        $i = (int)floor($dJ / 36524.25);
        if ($i < 0 || $i + 1 >= count($tab)) {
            return 0.0;
        }
        $dfrac = ($dJ - $i * 36524.25) / 36524.25;
        return $tab[$i] + $dfrac * ($tab[$i + 1] - $tab[$i]);
    }

    /** Correction of the mean lunar node in degrees (mean_node_corr[], zero for years 0..3000). */
    private static function corrMeanNodeDeg(float $jdEt): float
    {
        static $tab = [
            -2.56, -2.473, -2.392347, -2.316425, -2.239639, -2.167764, -2.095100, -2.024810, -1.957622, -1.890097,
            -1.826389, -1.763335, -1.701047, -1.643016, -1.584186, -1.527309, -1.473352, -1.418917, -1.367736, -1.317202,
            -1.267269, -1.221121, -1.174218, -1.128862, -1.086214, -1.042998, -1.002491, -0.962635, -0.923176, -0.887191,
            -0.850403, -0.814929, -0.782117, -0.748462, -0.717241, -0.686598, -0.656013, -0.628726, -0.600460, -0.573219,
            -0.548634, -0.522931, -0.499285, -0.476273, -0.452978, -0.432663, -0.411386, -0.390788, -0.372825, -0.353681,
            -0.336230, -0.319520, -0.302343, -0.287794, -0.272262, -0.257166, -0.244534, -0.230635, -0.218126, -0.206365,
            -0.194000, -0.183876, -0.172782, -0.161877, -0.153254, -0.143371, -0.134501, -0.126552, -0.117932, -0.111199,
            -0.103716, -0.096160, -0.090718, -0.084046, -0.078007, -0.072959, -0.067235, -0.062990, -0.058102, -0.053070,
            -0.049786, -0.045381, -0.041317, -0.038165, -0.034501, -0.031871, -0.028844, -0.025701, -0.024018, -0.021427,
            -0.018881, -0.017291, -0.015186, -0.013755, -0.012098, -0.010261, -0.009688, -0.008218, -0.006670, -0.005979,
            -0.004756, -0.003991, -0.002996, -0.001974, -0.001975, -0.001213, -0.000377, -0.000356, 5.779e-05, 0.000378,
            0.000710, 0.001092, 0.000767, 0.000985, 0.001443, 0.001069, 0.001141, 0.001321, 0.001462, 0.001695,
            0.001319, 0.001567, 0.001873, 0.001376, 0.001336, 0.001347, 0.001330, 0.001256, 0.000813, 0.000946,
            0.001079, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, -0.000364, -0.000452, -0.001091, -0.001159, -0.001136, -0.001798, -0.002249, -0.002622, -0.002990,
            -0.003555, -0.004425, -0.004758, -0.005134, -0.006065, -0.006839, -0.007474, -0.008283, -0.009411, -0.010786,
            -0.011810, -0.012989, -0.014825, -0.016426, -0.017922, -0.019774, -0.021881, -0.024194, -0.026190, -0.028440,
            -0.031285, -0.033817, -0.036318, -0.039212, -0.042456, -0.045799, -0.048994, -0.052710, -0.056948, -0.061017,
            -0.065181, -0.069843, -0.074922, -0.079976, -0.085052, -0.090755, -0.096840, -0.102797, -0.108939, -0.115568,
            -0.122636, -0.129593, -0.136683, -0.144641, -0.152825, -0.161044, -0.169758, -0.178916, -0.188712, -0.198401,
            -0.208312, -0.219395, -0.230407, -0.241577, -0.253508, -0.265640, -0.278556, -0.291330, -0.304353, -0.318815,
            -0.332882, -0.347316, -0.362895, -0.378421, -0.395061, -0.411748, -0.428666, -0.447477, -0.465636, -0.484277,
            -0.504600, -0.524405, -0.545533, -0.567020, -0.588404, -0.612099, -0.634965, -0.658262, -0.683866, -0.708526,
            -0.734719, -0.761800, -0.788562, -0.818092, -0.846885, -0.876177, -0.908385, -0.939371, -0.972027, -1.006149,
            -1.039634, -1.076135, -1.112156, -1.148490, -1.188312, -1.226761, -1.266821, -1.309156, -1.350583, -1.395223,
            -1.440028, -1.485047, -1.534104, -1.582023, -1.631506, -1.684031, -1.735687, -1.790421, -1.846039, -1.901951,
            -1.961872, -2.021179, -2.081987, -2.146259, -2.210031, -2.276609, -2.344904, -2.413795, -2.486559, -2.559564,
            -2.634215, -2.712692, -2.791289, -2.872533, -2.956217, -3.040965, -3.129234, -3.218545, -3.309805, -3.404827,
            -3.5008, -3.601, -3.7, -3.8,
        ];
        return self::corrTableDeg($tab, $jdEt);
    }

    /** Correction of the mean lunar apsis in degrees (mean_apsis_corr[], zero for years 0..3000). */
    private static function corrMeanApogDeg(float $jdEt): float
    {
        static $tab = [
            7.525, 7.290, 7.057295, 6.830813, 6.611723, 6.396775, 6.189569, 5.985968, 5.788342, 5.597304,
            5.410167, 5.229946, 5.053389, 4.882187, 4.716494, 4.553532, 4.396734, 4.243718, 4.094282, 3.950865,
            3.810366, 3.674978, 3.543284, 3.414270, 3.290526, 3.168775, 3.050904, 2.937541, 2.826189, 2.719822,
            2.616193, 2.515431, 2.419193, 2.323782, 2.232545, 2.143635, 2.056803, 1.974913, 1.893874, 1.816201,
            1.741957, 1.668083, 1.598335, 1.529645, 1.463016, 1.399693, 1.336905, 1.278097, 1.220965, 1.165092,
            1.113071, 1.060858, 1.011007, 0.963701, 0.916523, 0.872887, 0.829596, 0.788486, 0.750017, 0.711177,
            0.675589, 0.640303, 0.605303, 0.573490, 0.541113, 0.511482, 0.483159, 0.455210, 0.430305, 0.404643,
            0.380782, 0.358524, 0.335405, 0.315244, 0.295131, 0.275766, 0.259223, 0.241586, 0.225890, 0.210404,
            0.194775, 0.181573, 0.167246, 0.154514, 0.143435, 0.131131, 0.121648, 0.111835, 0.102474, 0.094284,
            0.085204, 0.078240, 0.070697, 0.063696, 0.058894, 0.052390, 0.047632, 0.043129, 0.037823, 0.034143,
            0.029188, 0.025648, 0.021972, 0.018348, 0.017127, 0.013989, 0.011967, 0.011003, 0.007865, 0.007033,
            0.005574, 0.004060, 0.003699, 0.002465, 0.002889, 0.002144, 0.001018, 0.001757, -9.67e-05, -0.000734,
            -0.000392, -0.001546, -0.000863, -0.001266, -0.000933, -0.000503, -0.001304, 0.000238, -0.000507, -0.000897,
            0.000647, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.000514, 0.000683, 0.002228, 0.001974, 0.003485, 0.004280, 0.005409, 0.007468, 0.007938,
            0.011012, 0.012525, 0.013757, 0.016757, 0.017932, 0.020780, 0.023416, 0.026386, 0.030428, 0.033512,
            0.038789, 0.043126, 0.047778, 0.054175, 0.058891, 0.065878, 0.072345, 0.079668, 0.088238, 0.095307,
            0.104873, 0.113533, 0.122336, 0.133205, 0.142922, 0.154871, 0.166488, 0.179234, 0.193928, 0.207262,
            0.223089, 0.238736, 0.254907, 0.273232, 0.291085, 0.311046, 0.331025, 0.351955, 0.374422, 0.396341,
            0.420772, 0.444867, 0.469984, 0.497448, 0.524717, 0.554752, 0.584581, 0.616272, 0.649744, 0.682947,
            0.719405, 0.755834, 0.793780, 0.833875, 0.873893, 0.917340, 0.960429, 1.005471, 1.052384, 1.099317,
            1.149508, 1.200130, 1.253038, 1.307672, 1.363480, 1.422592, 1.481900, 1.544111, 1.607982, 1.672954,
            1.741025, 1.809727, 1.882038, 1.955243, 2.029956, 2.108428, 2.186805, 2.268697, 2.352071, 2.437370,
            2.525903, 2.615415, 2.709082, 2.804198, 2.901704, 3.002606, 3.104412, 3.210406, 3.317733, 3.428386,
            3.541634, 3.656634, 3.775988, 3.896306, 4.020480, 4.146814, 4.275356, 4.408257, 4.542282, 4.681174,
            4.822524, 4.966424, 5.114948, 5.264973, 5.419906, 5.577056, 5.737688, 5.902347, 6.069138, 6.241065,
            6.415155, 6.593317, 6.774853, 6.959322, 7.148845, 7.340334, 7.537156, 7.737358, 7.940882, 8.149932,
            8.361576, 8.579150, 8.799591, 9.024378, 9.254584, 9.487362, 9.726535, 9.968784, 10.216089, 10.467716,
            10.725293, 10.986, 11.25, 11.52,
        ];
        return self::corrTableDeg($tab, $jdEt);
    }

    /** @return array{0:float,1:float,2:float,3:float} */
    private function calcNode(float $jdUt, int $body, bool $sidereal, bool $noNutation = false): array
    {
        if ($body === self::SE_TRUE_NODE) {
            return $this->calcTrueNodeFromMoonOrbit($jdUt, $sidereal, $noNutation);
        }
        $calc = function(float $ju) use ($sidereal, $noNutation): float {
            $jdEt = $ju + $this->deltaTSeconds($ju) / 86400.0;
            $el = SweMath::meanLunarElementsArcsec($jdEt);
            // Swiss C swi_mean_node(): (SWELP - NF - dcor), dcor = DE431 fit.
            $omega = SweMath::norm360(($el['L'] - $el['F']) / 3600.0 - self::corrMeanNodeDeg($jdEt));
            if (!$noNutation) {
                $nu = SweMath::nutationShort($jdEt);
                $omega = SweMath::norm360($omega + $nu['dpsi'] * SweMath::RAD2DEG);
            }
            if ($sidereal) $omega = SweMath::norm360($omega - SweMath::ayanamshaLahiri($jdEt));
            return $omega;
        };
        $lon = $calc($jdUt);
        $step = 0.01;
        $speed = SweMath::norm180($calc($jdUt + $step) - $calc($jdUt - $step)) / (2.0 * $step);
        // Swiss C swi_mean_node(): pol[2] = MOON_MEAN_DIST / AUNIT.
        return [$lon, 0.0, 384400000.0 / SweMath::AUNIT_M, $speed];
    }

    /** @return array{0:float,1:float,2:float,3:float} */
    private function calcApogee(float $jdUt, int $body, bool $sidereal, bool $noNutation = false): array
    {
        if ($body === self::SE_OSCU_APOG) {
            return $this->calcOsculatingApogee($jdUt, $sidereal, $noNutation);
        }
        $calc = function (float $ju) use ($sidereal, $noNutation): array {
            $jdEt = $ju + $this->deltaTSeconds($ju) / 86400.0;
            $el = SweMath::meanLunarElementsArcsec($jdEt);
            // Swiss C swi_mean_apog(): apogee = perigee + 180deg; both apogee
            // and node carry the DE431 fit corrections (zero for years 0..3000).
            $apogeeLon = SweMath::norm360(($el['L'] - $el['l']) / 3600.0 + 180.0 - self::corrMeanApogDeg($jdEt));
            $node = SweMath::norm360(($el['L'] - $el['F']) / 3600.0 - self::corrMeanNodeDeg($jdEt));
            // Argument of latitude of the apogee relative to the corrected node.
            $u = SweMath::norm360($apogeeLon - $node);
            $inclDeg = 5.1453964;
            $incl = $inclDeg * SweMath::DEG2RAD;
            $uRad = $u * SweMath::DEG2RAD;
            $x = cos($uRad);
            $y = sin($uRad);
            $z = 0.0;
            // Projekce apsidy z drahove roviny na ekliptiku (Swiss mean apogee postup).
            $y1 = $y * cos($incl) - $z * sin($incl);
            $z1 = $y * sin($incl) + $z * cos($incl);
            $lonRel = atan2($y1, $x) * SweMath::RAD2DEG;
            $lat = atan2($z1, sqrt($x * $x + $y1 * $y1)) * SweMath::RAD2DEG;
            $lon = SweMath::norm360($lonRel + $node);

            $lon = SweMath::norm360($lon);
            if (!$noNutation) {
                $nu = SweMath::nutationShort($jdEt);
                $lon = SweMath::norm360($lon + $nu['dpsi'] * SweMath::RAD2DEG);
            }
            if ($sidereal) {
                $lon = SweMath::norm360($lon - SweMath::ayanamshaLahiri($jdEt));
            }
            // Swiss C swi_mean_apog(): MOON_MEAN_DIST * (1 + MOON_MEAN_ECC) / AUNIT.
            $dist = 384400000.0 * (1.0 + 0.054900489) / SweMath::AUNIT_M;
            return [$lon, $lat, $dist];
        };

        [$lon, $lat, $dist] = $calc($jdUt);
        $step = 0.001;
        $lonP = $calc($jdUt + $step)[0];
        $lonM = $calc($jdUt - $step)[0];
        $speed = SweMath::norm180($lonP - $lonM) / (2.0 * $step);
        return [$lon, $lat, $dist, $speed];
    }

    /**
     * Swiss-style osculating lunar node. Swiss Ephemeris uses the instantaneous
     * lunar tangent line projected to the ecliptic: node = r - z/vz * v, not the
     * angular-momentum intersection used in the earlier draft.
     * @return array{0:float,1:float,2:float,3:float}
     */
    private function calcTrueNodeFromMoonOrbit(float $jdUt, bool $sidereal, bool $noNutation = false): array
    {
        // Tangent-line node direction, as in Swiss C lunar_osc_elem():
        // node = (r - z/vz * v) * sgn(vz), in ecliptic of date coordinates.
        $lonFromState = static function (array $state): float {
            $vz = $state[5];
            if (abs($vz) < 1e-15) $vz = $vz < 0 ? -1e-15 : 1e-15;
            $fac = $state[2] / $vz;
            $sgn = $vz < 0 ? -1.0 : 1.0;
            $nx = ($state[0] - $fac * $state[3]) * $sgn;
            $ny = ($state[1] - $fac * $state[4]) * $sgn;
            return SweMath::norm360(atan2($ny, $nx) * SweMath::RAD2DEG);
        };
        $calc = function (float $ju) use ($lonFromState, $sidereal, $noNutation): float {
            $lon = $lonFromState($this->moonStateForNodeApogee($ju, $noNutation));
            if ($sidereal) {
                $jdEt = $ju + $this->deltaTSeconds($ju) / 86400.0;
                $lon = SweMath::norm360($lon - SweMath::ayanamshaLahiri($jdEt));
            }
            return $lon;
        };
        $state0 = $this->moonStateForNodeApogee($jdUt, $noNutation);
        $lon = $lonFromState($state0);
        if ($sidereal) {
            $jdEt = $jdUt + $this->deltaTSeconds($jdUt) / 86400.0;
            $lon = SweMath::norm360($lon - SweMath::ayanamshaLahiri($jdEt));
        }
        $step = 0.0001;
        $speed = SweMath::norm180($calc($jdUt + $step) - $calc($jdUt - $step)) / (2.0 * $step);
        return [$lon, 0.0, $this->osculatingNodeDistance($state0), $speed];
    }

    /**
     * Node distance derived from the osculating ellipse, Swiss C lunar_osc_elem():
     * true anomaly of the node, then r = sema * (1 - ecce * cos E).
     * @param array{0:float,1:float,2:float,3:float,4:float,5:float} $state
     */
    private function osculatingNodeDistance(array $state): float
    {
        $gmsm = self::EARTH_MU_AU3_PER_DAY2 * (1.0 + 1.0 / self::EARTH_MOON_MRAT);
        $vz = $state[5];
        if (abs($vz) < 1e-15) $vz = $vz < 0 ? -1e-15 : 1e-15;
        $fac = $state[2] / $vz;
        $sgn = $vz < 0 ? -1.0 : 1.0;
        $node = [
            ($state[0] - $fac * $state[3]) * $sgn,
            ($state[1] - $fac * $state[4]) * $sgn,
            ($state[2] - $fac * $state[5]) * $sgn,
        ];
        $rxy = sqrt($node[0] * $node[0] + $node[1] * $node[1]);
        if ($rxy < 1e-20) $rxy = 1e-20;
        $cosnode = $node[0] / $rxy;
        $sinnode = $node[1] / $rxy;
        $xnorm = $this->cross3([$state[0], $state[1], $state[2]], [$state[3], $state[4], $state[5]]);
        $rxy2 = $xnorm[0] * $xnorm[0] + $xnorm[1] * $xnorm[1];
        $c2 = $rxy2 + $xnorm[2] * $xnorm[2];
        $rxyz = sqrt($c2);
        if ($rxyz < 1e-20) $rxyz = 1e-20;
        $sinincl = sqrt($rxy2) / $rxyz;
        if ($sinincl < 1e-12) $sinincl = 1e-12;
        $cosu = $state[0] * $cosnode + $state[1] * $sinnode;
        $sinu = $state[2] / $sinincl;
        $uu = atan2($sinu, $cosu);
        $rlen = sqrt($state[0] * $state[0] + $state[1] * $state[1] + $state[2] * $state[2]);
        $v2 = $state[3] * $state[3] + $state[4] * $state[4] + $state[5] * $state[5];
        $den = 2.0 / max($rlen, 1e-20) - $v2 / max($gmsm, 1e-30);
        if (abs($den) < 1e-20) $den = ($den < 0.0) ? -1e-20 : 1e-20;
        $sema = 1.0 / $den;
        $ecceArg = 1.0 - ($c2 / max($gmsm, 1e-30)) / max($sema, 1e-20);
        $ecce = sqrt(max(1e-12, $ecceArg));
        $cosE = (1.0 - $rlen / max($sema, 1e-20)) / $ecce;
        $sinE = ($state[0] * $state[3] + $state[1] * $state[4] + $state[2] * $state[5])
            / max($ecce * sqrt(max($sema * $gmsm, 1e-30)), 1e-20);
        $ny = 2.0 * atan(sqrt((1.0 + $ecce) / max(1.0 - $ecce, 1e-12)) * $sinE / max(1.0 + $cosE, 1e-20));
        $nyNode = $this->mod2pi($ny - $uu);
        $cosEn = cos(2.0 * atan(tan($nyNode / 2.0) / sqrt((1.0 + $ecce) / max(1.0 - $ecce, 1e-12))));
        return $sema * (1.0 - $ecce * $cosEn);
    }

    /** @return array{0:float,1:float,2:float,3:float} */
    private function calcOsculatingApogee(float $jdUt, bool $sidereal, bool $noNutation = false): array
    {
        // Swiss C uses NODE_CALC_INTV for SWIEPH/JPL osculating node/apogee.
        $speedIntv = 0.0001;
        $times = [$jdUt - $speedIntv, $jdUt + $speedIntv, $jdUt];
        $xpos = [];
        $xxNode = [];
        $xxApogee = [];
        $gmsm = self::EARTH_MU_AU3_PER_DAY2 * (1.0 + 1.0 / self::EARTH_MOON_MRAT);

        foreach ($times as $idx => $ju) {
            $state = $this->moonStateForNodeApogee($ju, $noNutation);
            $xpos[$idx] = $state;

            $vz = $state[5];
            if (abs($vz) < 1e-15) {
                $vz = ($vz < 0.0) ? -1e-15 : 1e-15;
            }
            $fac = $state[2] / $vz;
            $sgn = ($vz < 0.0) ? -1.0 : 1.0;
            $node = [
                ($state[0] - $fac * $state[3]) * $sgn,
                ($state[1] - $fac * $state[4]) * $sgn,
                ($state[2] - $fac * $state[5]) * $sgn,
            ];

            $rxy = sqrt($node[0] * $node[0] + $node[1] * $node[1]);
            if ($rxy < 1e-20) {
                $rxy = 1e-20;
            }
            $cosnode = $node[0] / $rxy;
            $sinnode = $node[1] / $rxy;

            $xnorm = $this->cross3([$state[0], $state[1], $state[2]], [$state[3], $state[4], $state[5]]);
            $rxy2 = $xnorm[0] * $xnorm[0] + $xnorm[1] * $xnorm[1];
            $c2 = $rxy2 + $xnorm[2] * $xnorm[2];
            $rxyz = sqrt($c2);
            if ($rxyz < 1e-20) {
                $rxyz = 1e-20;
            }
            $sinincl = sqrt($rxy2) / $rxyz;
            if ($sinincl < 1e-12) {
                $sinincl = 1e-12;
            }
            $cosincl = sqrt(max(0.0, 1.0 - $sinincl * $sinincl));

            $cosu = $state[0] * $cosnode + $state[1] * $sinnode;
            $sinu = $state[2] / $sinincl;
            $uu = atan2($sinu, $cosu);

            $rlen = sqrt($state[0] * $state[0] + $state[1] * $state[1] + $state[2] * $state[2]);
            $v2 = $state[3] * $state[3] + $state[4] * $state[4] + $state[5] * $state[5];
            $den = 2.0 / max($rlen, 1e-20) - $v2 / max($gmsm, 1e-30);
            if (abs($den) < 1e-20) {
                $den = ($den < 0.0) ? -1e-20 : 1e-20;
            }
            $sema = 1.0 / $den;
            $ecceArg = 1.0 - ($c2 / max($gmsm, 1e-30)) / max($sema, 1e-20);
            $ecce = sqrt(max(1e-12, $ecceArg));

            $cosE = (1.0 - $rlen / max($sema, 1e-20)) / $ecce;
            $sinE = (($state[0] * $state[3] + $state[1] * $state[4] + $state[2] * $state[5]) / max($ecce * sqrt(max($sema * $gmsm, 1e-30)), 1e-20));
            $ny = 2.0 * atan(sqrt((1.0 + $ecce) / max(1.0 - $ecce, 1e-12)) * $sinE / max(1.0 + $cosE, 1e-20));

            $lonArg = $this->mod2pi($uu - $ny + M_PI);
            $distAp = $sema * (1.0 + $ecce);
            $x = $distAp * cos($lonArg);
            $y = $distAp * sin($lonArg);
            $z = 0.0;
            $y1 = $y * $cosincl - $z * $sinincl;
            $z1 = $y * $sinincl + $z * $cosincl;
            $lon1 = atan2($y1, $x) + atan2($sinnode, $cosnode);
            $lat1 = atan2($z1, sqrt($x * $x + $y1 * $y1));
            $xxApogee[$idx] = [
                $distAp * cos($lat1) * cos($lon1),
                $distAp * cos($lat1) * sin($lon1),
                $distAp * sin($lat1),
            ];

            $nyNode = $this->mod2pi($ny - $uu);
            $cosEn = cos(2.0 * atan(tan($nyNode / 2.0) / sqrt((1.0 + $ecce) / max(1.0 - $ecce, 1e-12))));
            $r0 = $sema * (1.0 - $ecce * $cosEn);
            $r1 = sqrt($node[0] * $node[0] + $node[1] * $node[1] + $node[2] * $node[2]);
            if ($r1 < 1e-20) {
                $r1 = 1e-20;
            }
            $scale = $r0 / $r1;
            $xxNode[$idx] = [$node[0] * $scale, $node[1] * $scale, $node[2] * $scale];
        }

        $center = $xxApogee[2];
        $prev = $xxApogee[0];
        $next = $xxApogee[1];

        $centerState = [
            $center[0],
            $center[1],
            $center[2],
            ($next[0] - $prev[0]) / (2.0 * $speedIntv),
            ($next[1] - $prev[1]) / (2.0 * $speedIntv),
            ($next[2] - $prev[2]) / (2.0 * $speedIntv),
        ];
        $polar = $this->cartesianToPolarSpeed($centerState);
        $lon = $polar[0];
        $lat = $polar[1];
        $speed = $polar[3];

        $jdEt = $jdUt + $this->deltaTSeconds($jdUt) / 86400.0;
        if ($sidereal) {
            $ayan = SweMath::ayanamshaLahiri($jdEt);
            $lon = SweMath::norm360($lon - $ayan);
        }

        // Swiss C returns the osculating apogee distance (sema * (1 + ecce)).
        return [$lon, $lat, $polar[2], $speed];
    }

    /** @return array{0:float,1:float,2:float} */
    private function cross3(array $a, array $b): array
    {
        return [
            ($a[1] ?? 0.0) * ($b[2] ?? 0.0) - ($a[2] ?? 0.0) * ($b[1] ?? 0.0),
            ($a[2] ?? 0.0) * ($b[0] ?? 0.0) - ($a[0] ?? 0.0) * ($b[2] ?? 0.0),
            ($a[0] ?? 0.0) * ($b[1] ?? 0.0) - ($a[1] ?? 0.0) * ($b[0] ?? 0.0),
        ];
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function moonStateForNodeApogee(float $jdUt, bool $noNutation = false): array
    {
        $jdEt = $jdUt + $this->deltaTSeconds($jdUt) / 86400.0;
        $moon = $this->raw(self::SEI_MOON, $jdEt);
        $dt = SweMath::vecNorm3($moon) / SweMath::CLIGHT_AUDAY;
        $moon = $this->raw(self::SEI_MOON, $jdEt - $dt);
        $moon = SweMath::frameBiasGcrsToJ2000($moon);

        $posDate = SweMath::precessJ2000ToDate([$moon[0], $moon[1], $moon[2], 0.0, 0.0, 0.0], $jdEt);
        $velDate = SweMath::precessJ2000ToDate([$moon[3], $moon[4], $moon[5], 0.0, 0.0, 0.0], $jdEt);
        $state = [$posDate[0], $posDate[1], $posDate[2], $velDate[0], $velDate[1], $velDate[2]];
        if (!$noNutation) {
            $nu = SweMath::nutationShort($jdEt);
            $state = SweMath::applyNutation($state, $jdEt);
            $eps = $nu['epsTrue'];
        } else {
            $eps = SweMath::meanObliquityDeg($jdEt) * SweMath::DEG2RAD;
        }
        $ce = cos($eps);
        $se = sin($eps);

        $x = $state[0];
        $y = $ce * $state[1] + $se * $state[2];
        $z = -$se * $state[1] + $ce * $state[2];
        $vx = $state[3];
        $vy = $ce * $state[4] + $se * $state[5];
        $vz = -$se * $state[4] + $ce * $state[5];

        return [$x, $y, $z, $vx, $vy, $vz];
    }

    /** @return array{0:float,1:float,2:float,3:float,4:float,5:float} */
    private function cartesianToPolarSpeed(array $x): array
    {
        $rxy2 = $x[0] * $x[0] + $x[1] * $x[1];
        $dist = sqrt($rxy2 + $x[2] * $x[2]);
        if ($dist <= 0.0) {
            return [0.0, 0.0, 0.0, 0.0, 0.0, sqrt(($x[3] ?? 0.0) ** 2 + ($x[4] ?? 0.0) ** 2 + ($x[5] ?? 0.0) ** 2)];
        }

        $rxy = sqrt(max($rxy2, 1e-30));
        $lon = SweMath::norm360(atan2($x[1], $x[0]) * SweMath::RAD2DEG);
        $lat = atan2($x[2], $rxy) * SweMath::RAD2DEG;
        $cosLon = $x[0] / $rxy;
        $sinLon = $x[1] / $rxy;
        $cosLat = $rxy / $dist;
        $sinLat = $x[2] / $dist;
        $vxRot = ($x[3] ?? 0.0) * $cosLon + ($x[4] ?? 0.0) * $sinLon;
        $vyRot = -($x[3] ?? 0.0) * $sinLon + ($x[4] ?? 0.0) * $cosLon;
        $lonSpeed = ($vyRot / $rxy) * SweMath::RAD2DEG;
        $latSpeed = ((-$sinLat * $vxRot + $cosLat * ($x[5] ?? 0.0)) / $dist) * SweMath::RAD2DEG;
        $distSpeed = $cosLat * $vxRot + $sinLat * ($x[5] ?? 0.0);
        return [$lon, $lat, $dist, $lonSpeed, $latSpeed, $distSpeed];
    }

    private function mod2pi(float $x): float
    {
        $r = fmod($x, SweMath::TWOPI);
        if ($r < 0.0) {
            $r += SweMath::TWOPI;
        }
        return $r;
    }

    public static function rotBack(SwePlanData $p, int $ipli): void
    {
        $nco = $p->ncoe;
        $t = $p->tseg0 + $p->dseg / 2.0;
        $tdiff = ($t - $p->telem) / 365250.0;
        if ($ipli === self::SEI_MOON) {
            $dn = $p->prot + $tdiff * $p->dprot;
            $dn -= (int)($dn / SweMath::TWOPI) * SweMath::TWOPI;
            $qav = ($p->qrot + $tdiff * $p->dqrot) * cos($dn);
            $pav = ($p->qrot + $tdiff * $p->dqrot) * sin($dn);
        } else {
            $qav = $p->qrot + $tdiff * $p->dqrot;
            $pav = $p->prot + $tdiff * $p->dprot;
        }
        $x = [];
        for ($i = 0; $i < $nco; $i++) $x[$i] = [$p->segp[$i], $p->segp[$nco + $i], $p->segp[2*$nco + $i]];
        if (($p->iflg & self::SEI_FLG_ELLIPSE) !== 0) {
            $omtild = $p->peri + $tdiff * $p->dperi;
            $omtild -= (int)($omtild / SweMath::TWOPI) * SweMath::TWOPI;
            $com = cos($omtild); $som = sin($omtild);
            for ($i = 0; $i < $nco; $i++) {
                $refx = $p->refep[$i] ?? 0.0;
                $refy = $p->refep[$nco + $i] ?? 0.0;
                $x[$i][0] = $p->segp[$i] + $com * $refx - $som * $refy;
                $x[$i][1] = $p->segp[$nco + $i] + $com * $refy + $som * $refx;
            }
        }
        $cosih2 = 1.0 / (1.0 + $qav*$qav + $pav*$pav);
        $uiz = [2.0*$pav*$cosih2, -2.0*$qav*$cosih2, (1.0 - $qav*$qav - $pav*$pav)*$cosih2];
        $uix = [(1.0 + $qav*$qav - $pav*$pav)*$cosih2, 2.0*$qav*$pav*$cosih2, -2.0*$pav*$cosih2];
        $uiy = [2.0*$qav*$pav*$cosih2, (1.0 - $qav*$qav + $pav*$pav)*$cosih2, 2.0*$qav*$cosih2];
        // Swiss C rot_back() keeps neval as the INDEX of the last significant
        // coefficient and passes it to swi_echeb() as the term count, so the
        // last significant term is effectively dropped. Reproduce that 1:1.
        $p->neval = 0;
        for ($i = 0; $i < $nco; $i++) {
            $xrot = $x[$i][0]*$uix[0] + $x[$i][1]*$uiy[0] + $x[$i][2]*$uiz[0];
            $yrot = $x[$i][0]*$uix[1] + $x[$i][1]*$uiy[1] + $x[$i][2]*$uiz[1];
            $zrot = $x[$i][0]*$uix[2] + $x[$i][1]*$uiy[2] + $x[$i][2]*$uiz[2];
            if (abs($xrot) + abs($yrot) + abs($zrot) >= 1e-14) $p->neval = $i;
            if ($ipli === self::SEI_MOON) {
                $yy = SweMath::CEPS2000 * $yrot - SweMath::SEPS2000 * $zrot;
                $zz = SweMath::SEPS2000 * $yrot + SweMath::CEPS2000 * $zrot;
                $yrot = $yy; $zrot = $zz;
            }
            $p->segp[$i] = $xrot;
            $p->segp[$nco + $i] = $yrot;
            $p->segp[2*$nco + $i] = $zrot;
        }
    }
}

final class SweTestSe1Cli
{
    public static function run(array $argv): int
    {
        try {
            $opts = self::parseArgs(array_slice($argv, 1));
            if ($opts['help']) { echo self::help(); return 0; }
            $jd = $opts['jd'];
            $swe = new SweSe1($opts['edir']);
            for ($row = 0; $row < $opts['n']; $row++) {
                if ($opts['n'] > 1) printf("jd %.8f\n", $jd);
                foreach ($opts['bodies'] as $body) {
                    $r = $swe->calcUt($jd, $body, $opts['sidereal']);
                    echo self::formatLine($body, $r, $opts['format'], $jd) . PHP_EOL;
                }
                $jd += $opts['step'];
            }
            $swe->close();
            return 0;
        } catch (Throwable $e) {
            echo "CHYBA: " . $e->getMessage() . PHP_EOL;
            return 1;
        }
    }

    /** @return array<string,mixed> */
    public static function parseArgs(array $args): array
    {
        $date = [2000,1,1]; $ut = 0.0; $jd = null; $bodiesText = '0123456789mtABDEFGHI'; $format = 'PLBRS'; $n = 1; $step = 1.0; $sid = false;
        $edir = __DIR__ . '/../ephe';
        foreach ([__DIR__ . '/php-sweph-master/sweph/ephe', __DIR__ . '/sweph/ephe', __DIR__ . '/ephe', __DIR__ . '/../ephe'] as $edirCandidate) {
            if (is_dir($edirCandidate)) {
                $edir = $edirCandidate;
                break;
            }
        }
        $help = false;
        for ($i = 0; $i < count($args); $i++) {
            $a = $args[$i];
            if ($a === '-h' || $a === '--help') { $help = true; continue; }
            if (swetest_starts_with($a, '-edir')) { $edir = strlen($a) > 5 ? substr($a,5) : ($args[++$i] ?? $edir); continue; }
            if (swetest_starts_with($a, '-bj')) { $jd = (float)substr($a,3); continue; }
            if (swetest_starts_with($a, '-b')) { $date = self::parseDate(substr($a,2)); continue; }
            if (swetest_starts_with($a, '-utc')) { $ut = self::parseTime(substr($a,4)); continue; }
            if (swetest_starts_with($a, '-ut')) { $ut = self::parseTime(substr($a,3)); continue; }
            if (swetest_starts_with($a, '-t')) { $ut = self::parseTime(substr($a,2)); continue; }
            if (swetest_starts_with($a, '-p')) { $bodiesText = substr($a,2); continue; }
            if (swetest_starts_with($a, '-f')) { $format = substr($a,2) ?: $format; continue; }
            if (swetest_starts_with($a, '-n')) { $n = max(1, (int)substr($a,2)); continue; }
            if (swetest_starts_with($a, '-s')) { $step = self::parseStep(substr($a,2)); continue; }
            if (swetest_starts_with($a, '-sid')) { $sid = true; continue; }
        }
        if ($jd === null) $jd = SweMath::julday($date[0], $date[1], $date[2], $ut, true);
        $bodies = [];
        foreach (preg_split('//u', $bodiesText, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
            if (isset(SweSe1::$bodyMap[$ch])) $bodies[] = SweSe1::$bodyMap[$ch];
        }
        if (!$bodies) $bodies = [SweSe1::SE_SUN];
        return compact('jd','bodies','format','n','step') + ['sidereal'=>$sid, 'edir'=>$edir, 'help'=>$help];
    }

    /** @return array{0:int,1:int,2:int} */
    private static function parseDate(string $s): array
    {
        $p = preg_split('/[\.\/\-]/', trim($s));
        if (!$p || count($p) < 3) throw new InvalidArgumentException("Spatne datum -b$s");
        return [(int)$p[2], (int)$p[1], (int)$p[0]];
    }

    private static function parseTime(string $s): float
    {
        if ($s === '') return 0.0;
        $p = array_map('floatval', explode(':', $s));
        return ($p[0] ?? 0.0) + ($p[1] ?? 0.0)/60.0 + ($p[2] ?? 0.0)/3600.0;
    }

    private static function parseStep(string $s): float
    {
        if ($s === '') return 1.0;
        if (preg_match('/^([+-]?\d+(?:\.\d+)?)(mo|y|d|h|m)?$/i', $s, $m)) {
            $v = (float)$m[1]; $u = strtolower($m[2] ?? 'd');
            switch ($u) {
                case 'm': return $v / 1440.0;
                case 'h': return $v / 24.0;
                case 'y': return $v * 365.25;
                case 'mo': return $v * 30.4375;
                default: return $v;
            }
        }
        return (float)$s;
    }

    /** @param array{lon:float,lat:float,dist:float,slon:float,sdist:float,source:string} $r */
    public static function formatLine(int $body, array $r, string $fmt, float $jd): string
    {
        $parts = [];
        foreach (str_split($fmt) as $ch) {
            switch ($ch) {
                case 'P': $parts[] = str_pad(SweSe1::$names[$body] ?? (string)$body, 12); break;
                case 'L': $parts[] = sprintf('%12.8f', $r['lon']); break;
                case 'B': $parts[] = sprintf('%12.8f', $r['lat']); break;
                case 'R': $parts[] = sprintf('%14.9f', $r['dist']); break;
                case 'S': $parts[] = sprintf('%12.8f', $r['slon']); break;
                case 'Z': $parts[] = self::zodiac($r['lon']); break;
                case 'l': $parts[] = sprintf('lon=%0.8f', $r['lon']); break;
                case 'b': $parts[] = sprintf('lat=%0.8f', $r['lat']); break;
                case 'r': $parts[] = sprintf('dist=%0.9f', $r['dist']); break;
                case 's': $parts[] = sprintf('speed=%0.8f', $r['slon']); break;
                case 'j': $parts[] = sprintf('jd=%0.8f', $jd); break;
            }
        }
        return implode(' ', $parts);
    }

    private static function zodiac(float $lon): string
    {
        $sg = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
        $lon = SweMath::norm360($lon);
        $i = (int)floor($lon / 30.0);
        $d = $lon - $i*30.0;
        $deg = (int)floor($d);
        $min = (int)floor(($d - $deg) * 60.0);
        $sec = (int)round(((($d - $deg) * 60.0) - $min) * 60.0);
        if ($sec >= 60) { $sec -= 60; $min++; }
        if ($min >= 60) { $min -= 60; $deg++; }
        return sprintf('%02d%s%02d\'%02d"', $deg, $sg[$i], $min, $sec);
    }

    public static function help(): string
    {
        return "swetest_pure_se1_v9.php - cisty PHP port s realnym ctenim .se1\n"
            . "Pouziti:\n"
            . "  php swetest_pure_se1_v9.php -edir./sweph/ephe -b25.4.2026 -ut18:30 -p0123456789mt -fPZls\n\n"
            . "Volby: -bDD.MM.YYYY -bjJD -utHH:MM -p0123456789mt -fPLBRSZlbrsj -nN -s1d/2h/15m/1mo -sid1 -edirPATH\n"
            . "Bez EXE/DLL/extension/FFI. Stav v12: .se1 core + apparent longitude vcetne light-time, deflekce, aberace, Vondrak 2011 precesi, IAU 2000B nutace a oskulujici true Node; zatmeni/rise-set nejsou soucasti astro-longitude buildu.\n";
    }
}

/**
 * swetest_astro_longitude_v9.php
 *
 * Astrology-focused pure PHP frontend over swetest_pure_se1_v8.php.
 * No EXE, DLL, PHP extension or FFI. It reads Swiss Ephemeris .se1 files
 * through the pure PHP SweSe1 reader and prints the ecliptic longitude in a
 * form useful for astrology.
 *
 * Priority: apparent ecliptic longitude, zodiac position, daily speed, retrograde flag.
 * v9: Swiss-style lunar light-time and tangent true Node; stronger astrology longitude focus.
 */

final class SweAstroLongitudeCli
{
    /** Swiss body chars compatible with the pure port. */
    private const DEFAULT_BODIES = '0123456789mtABDEFGHI';

    /** @var array<string,string> */
    private static array $czNames = [
        'Sun' => 'Slunce',
        'Moon' => 'Mesic',
        'Mercury' => 'Merkur',
        'Venus' => 'Venuse',
        'Mars' => 'Mars',
        'Jupiter' => 'Jupiter',
        'Saturn' => 'Saturn',
        'Uranus' => 'Uran',
        'Neptune' => 'Neptun',
        'Pluto' => 'Pluto',
        'mean Node' => 'Sev. uzel mean',
        'true Node' => 'Sev. uzel true',
        'mean Apogee' => 'Lilith mean',
        'osc. Apogee' => 'Lilith true',
        'Earth' => 'Zeme',
        'Chiron' => 'Chiron',
        'Pholus' => 'Pholus',
        'Ceres' => 'Ceres',
        'Pallas' => 'Pallas',
        'Juno' => 'Juno',
        'Vesta' => 'Vesta',
    ];

    /** @var string[] */
    private static array $signsCz = [
        'Beran', 'Byk', 'Blizenci', 'Rak', 'Lev', 'Panna',
        'Vahy', 'Stir', 'Strelec', 'Kozoroh', 'Vodnar', 'Ryby',
    ];

    /** @var string[] */
    private static array $signsShort = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

    public static function run(array $argv): int
    {
        try {
            $opts = self::parseArgs(array_slice($argv, 1));
            if ($opts['help']) {
                echo self::help();
                return 0;
            }
            $swe = new SweSe1($opts['edir']);
            $jd = $opts['jd'];
            for ($row = 0; $row < $opts['n']; $row++) {
                if ($opts['n'] > 1) {
                    echo 'JD ' . sprintf('%.8f', $jd) . PHP_EOL;
                }
                foreach ($opts['bodies'] as $body) {
                    $r = $swe->calcUt($jd, $body, $opts['sidereal'], $opts['truePos'], $opts['noAberr'], $opts['noNutation']);
                    if ($opts['showParts']) {
                        $r['parts'] = self::componentDiffs($swe, $jd, $body, $opts);
                    }
                    $line = $opts['json']
                        ? self::formatJson($body, $r, $jd, $opts)
                        : self::formatAstroLine($body, $r, $jd, $opts);
                    echo $line . PHP_EOL;
                }
                $jd += $opts['step'];
            }
            $swe->close();
            return 0;
        } catch (Throwable $e) {
            echo 'CHYBA: ' . $e->getMessage() . PHP_EOL;
            return 1;
        }
    }

    /** @return array<string,mixed> */
    public static function parseArgs(array $args): array
    {
        $edir = __DIR__ . '/../ephe';
        foreach ([__DIR__ . '/php-sweph-master/sweph/ephe', __DIR__ . '/sweph/ephe', __DIR__ . '/ephe', __DIR__ . '/../ephe'] as $edirCandidate) {
            if (is_dir($edirCandidate)) {
                $edir = $edirCandidate;
                break;
            }
        }

        $date = [2000, 1, 1];
        $ut = 0.0;
        $jd = null;
        $bodiesText = self::DEFAULT_BODIES;
        $sidereal = false;
        $n = 1;
        $step = 1.0;
        $json = false;
        $cz = false;
        $decimal = false;
        $truePos = false;
        $noAberr = false;
        $noNutation = false;
        $showSource = false;
        $showParts = false;
        $showDeltaT = false;
        $help = false;

        for ($i = 0; $i < count($args); $i++) {
            $a = trim((string)$args[$i]);
            if ($a === '' ) continue;
            if ($a === '-h' || $a === '--help') { $help = true; continue; }
            if ($a === '-json' || $a === '--json') { $json = true; continue; }
            if ($a === '-cz' || $a === '--cz') { $cz = true; continue; }
            if ($a === '-dec' || $a === '--decimal') { $decimal = true; continue; }
            if ($a === '-true' || $a === '-geom' || $a === '--geometric') { $truePos = true; continue; }
            if ($a === '-noaberr') { $noAberr = true; continue; }
            if ($a === '-nonut' || $a === '-mean') { $noNutation = true; continue; }
            if ($a === '-src' || $a === '--source') { $showSource = true; continue; }
            if ($a === '-parts' || $a === '-diff' || $a === '--parts') { $showParts = true; continue; }
            if ($a === '-dt' || $a === '-deltat' || $a === '--deltat') { $showDeltaT = true; continue; }
            if ($a === '-trop' || $a === '-sid0') { $sidereal = false; continue; }
            if (swetest_starts_with($a, '-sid')) { $sidereal = true; continue; }
            if (swetest_starts_with($a, '-edir')) { $edir = strlen($a) > 5 ? substr($a, 5) : ($args[++$i] ?? $edir); continue; }
            if (swetest_starts_with($a, '-bj')) { $jd = (float)substr($a, 3); continue; }
            if (swetest_starts_with($a, '-b')) { $date = self::parseDate(substr($a, 2)); continue; }
            // Important: -utc must be before -ut.
            if (swetest_starts_with($a, '-utc')) { $ut = self::parseTime(substr($a, 4)); continue; }
            if (swetest_starts_with($a, '-ut')) { $ut = self::parseTime(substr($a, 3)); continue; }
            if (swetest_starts_with($a, '-t')) { $ut = self::parseTime(substr($a, 2)); continue; }
            if (swetest_starts_with($a, '-p')) { $bodiesText = substr($a, 2); continue; }
            if (swetest_starts_with($a, '-n')) { $n = max(1, (int)substr($a, 2)); continue; }
            if (swetest_starts_with($a, '-s')) { $step = self::parseStep(substr($a, 2)); continue; }
        }

        if ($jd === null) {
            $jd = SweMath::julday($date[0], $date[1], $date[2], $ut, true);
        }

        $bodies = [];
        foreach (preg_split('//u', $bodiesText, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
            if (isset(SweSe1::$bodyMap[$ch])) $bodies[] = SweSe1::$bodyMap[$ch];
        }
        if (!$bodies) $bodies = [SweSe1::SE_SUN];

        return compact('edir', 'jd', 'bodies', 'sidereal', 'n', 'step', 'json', 'cz', 'decimal', 'truePos', 'noAberr', 'noNutation', 'showSource', 'showParts', 'showDeltaT', 'help');
    }

    /** @return array{0:int,1:int,2:int} */
    private static function parseDate(string $s): array
    {
        $s = trim($s);
        $p = preg_split('/[\.\/\-]/', $s);
        if (!$p || count($p) < 3) throw new InvalidArgumentException("Spatne datum -b$s");
        return [(int)$p[2], (int)$p[1], (int)$p[0]];
    }

    private static function parseTime(string $s): float
    {
        $s = trim($s);
        if ($s === '') return 0.0;
        $p = array_map('floatval', explode(':', $s));
        return ($p[0] ?? 0.0) + ($p[1] ?? 0.0) / 60.0 + ($p[2] ?? 0.0) / 3600.0;
    }

    private static function parseStep(string $s): float
    {
        if ($s === '') return 1.0;
        if (preg_match('/^([+-]?\d+(?:\.\d+)?)(mo|y|d|h|m)?$/i', $s, $m)) {
            $v = (float)$m[1];
            $u = strtolower($m[2] ?? 'd');
            switch ($u) {
                case 'm': return $v / 1440.0;
                case 'h': return $v / 24.0;
                case 'y': return $v * 365.25;
                case 'mo': return $v * 30.4375;
                default: return $v;
            }
        }
        return (float)$s;
    }


    /** @return array<string,float> */
    private static function componentDiffs(SweSe1 $swe, float $jd, int $body, array $opts): array
    {
        if ($body === SweSe1::SE_MEAN_NODE || $body === SweSe1::SE_TRUE_NODE) {
            return ['total_arcsec'=>0.0, 'aberr_arcsec'=>0.0, 'nut_arcsec'=>0.0];
        }
        $current = $swe->calcUt($jd, $body, $opts['sidereal'], $opts['truePos'], $opts['noAberr'], $opts['noNutation']);
        $geomMean = $swe->calcUt($jd, $body, $opts['sidereal'], true, true, true);
        $noAberr = $swe->calcUt($jd, $body, $opts['sidereal'], false, true, $opts['noNutation']);
        $noNut = $swe->calcUt($jd, $body, $opts['sidereal'], $opts['truePos'], $opts['noAberr'], true);
        return [
            'total_arcsec' => SweMath::norm180($current['lon'] - $geomMean['lon']) * 3600.0,
            'aberr_arcsec' => SweMath::norm180($current['lon'] - $noAberr['lon']) * 3600.0,
            'nut_arcsec' => SweMath::norm180($current['lon'] - $noNut['lon']) * 3600.0,
        ];
    }

    /** @param array{lon:float,lat:float,dist:float,slon:float,sdist:float,source:string} $r */
    private static function formatAstroLine(int $body, array $r, float $jd, array $opts): string
    {
        $name = SweSe1::$names[$body] ?? (string)$body;
        if ($opts['cz']) $name = self::$czNames[$name] ?? $name;
        $z = self::zodiacParts($r['lon']);
        $retro = $r['slon'] < 0 ? ' R' : '';
        $mode = $opts['sidereal'] ? 'sidereal-Lahiri' : 'tropical';
        $mode .= $opts['truePos'] ? '/geometric' : '/apparent';
        $pos = sprintf('%02d%s%02d\'%05.2f"', $z['deg'], self::$signsShort[$z['signIndex']], $z['min'], $z['sec']);
        if ($opts['cz']) {
            $pos = sprintf('%02d %s %02d\'%05.2f"', $z['deg'], self::$signsCz[$z['signIndex']], $z['min'], $z['sec']);
        }
        $out = str_pad($name, 16) . ' ' . $pos;
        if ($opts['decimal']) $out .= '  lon=' . sprintf('%.10f', $r['lon']);
        $out .= '  speed=' . sprintf('%+.8f', $r['slon']) . ' deg/day' . $retro;
        $out .= '  ' . $mode;
        if (!empty($opts['showSource'])) $out .= '  src=' . ($r['source'] ?? '');
        if (!empty($opts['showDeltaT'])) $out .= '  dT=' . sprintf('%.3fs', SweMath::deltaTSeconds($jd));
        if (!empty($r['parts'])) {
            $p = $r['parts'];
            $out .= '  corr=' . sprintf('%+.3f\"', $p['total_arcsec']);
            $out .= '  aberr=' . sprintf('%+.3f\"', $p['aberr_arcsec']);
            $out .= '  nut=' . sprintf('%+.3f\"', $p['nut_arcsec']);
        }
        return $out;
    }

    /** @param array{lon:float,lat:float,dist:float,slon:float,sdist:float,source:string} $r */
    private static function formatJson(int $body, array $r, float $jd, array $opts): string
    {
        $z = self::zodiacParts($r['lon']);
        $arr = [
            'body' => SweSe1::$names[$body] ?? (string)$body,
            'jd_ut' => round($jd, 8),
            'mode' => ($opts['sidereal'] ? 'sidereal_lahiri' : 'tropical') . ($opts['truePos'] ? '_geometric' : '_apparent'),
            'longitude_deg' => $r['lon'],
            'zodiac_sign' => self::$signsShort[$z['signIndex']],
            'sign_index' => $z['signIndex'],
            'degree_in_sign' => $z['deg'],
            'minute' => $z['min'],
            'second' => $z['sec'],
            'position' => sprintf('%02d%s%02d\'%05.2f"', $z['deg'], self::$signsShort[$z['signIndex']], $z['min'], $z['sec']),
            'speed_deg_per_day' => $r['slon'],
            'retrograde' => $r['slon'] < 0,
            'source' => $r['source'] ?? 'se1',
            'delta_t_seconds' => SweMath::deltaTSeconds($jd),
            'correction_parts_arcsec' => $r['parts'] ?? null,
            'nutation' => !$opts['noNutation'],
            'light_deflection' => !$opts['truePos'],
            'aberration' => !$opts['noAberr'] && !$opts['truePos'],
        ];
        return json_encode($arr, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /** @return array{signIndex:int,deg:int,min:int,sec:float} */
    private static function zodiacParts(float $lon): array
    {
        $lon = SweMath::norm360($lon);
        $signIndex = (int)floor($lon / 30.0);
        $x = ($lon - $signIndex * 30.0) * 3600.0;
        $deg = (int)floor($x / 3600.0);
        $x -= $deg * 3600.0;
        $min = (int)floor($x / 60.0);
        $sec = $x - $min * 60.0;
        // Round to 0.01", carrying over if needed.
        $sec = round($sec, 2);
        if ($sec >= 60.0) { $sec -= 60.0; $min++; }
        if ($min >= 60) { $min -= 60; $deg++; }
        if ($deg >= 30) { $deg -= 30; $signIndex = ($signIndex + 1) % 12; }
        return ['signIndex'=>$signIndex, 'deg'=>$deg, 'min'=>$min, 'sec'=>$sec];
    }

    private static function help(): string
    {
        return "swetest_astro_longitude_v9.php - astrologicky vystup ekliptikalni delky\n"
            . "Ciste PHP: bez EXE, DLL, PHP extension a FFI. Pouziva .se1 pres swetest_pure_se1_v8.php.\n\n"
            . "Pouziti:\n"
            . "  php swetest_astro_longitude_v9.php -edir./sweph/ephe -b25.4.2026 -ut18:30 -p0123456789mt -cz -dec\n"
            . "  php swetest_astro_longitude_v9.php -edir./sweph/ephe -b25.4.2026 -ut18:30 -p0123456789mt -sid1 -cz\n"
            . "  php swetest_astro_longitude_v9.php -edir./sweph/ephe -bj2460796.2708333 -p0m -json\n\n"
            . "Volby:\n"
            . "  -bDD.MM.YYYY     datum\n"
            . "  -utHH:MM[:SS]    cas UT\n"
            . "  -bjJD            julianske datum UT\n"
            . "  -p...            telesa: 0 Sun, 1 Moon, ... 9 Pluto, m mean Node, t true Node\n"
            . "  -sid1            sidereal/Lahiri; bez toho tropical\n"
            . "  -cz              ceske nazvy a znameni\n"
            . "  -dec             pridat longitude v desetinnych stupnich\n"
            . "  -json            jeden JSON radek na teleso\n"
            . "  -true/-geom      geometricka delka bez light-time/aberace\n"
            . "  -noaberr         apparent, ale bez rocni aberace; solarni deflekce zustava jako ve Swiss C\n"
            . "  -nonut/-mean     mean equinox/ecliptic, bez nutace\n"
            . "  -src             ukazat zdrojovy rezim vypoctu\n"
            . "  -dt/-deltat      ukazat Delta T v sekundach\n"
            . "  -parts/-diff     ukazat korekci proti geometricke delce + aberr/nut slozku\n"
            . "  -nN -s1d/2h/15m  vice kroku\n";
    }
}

/**
 * -----------------------------------------------------------------------------
 * PHP knihovni vrstva pro astrologicke pouziti.
 *
 * Soubor muzes:
 *   1) otevrit primo v prohlizeci jako stary swetest.php
 *   2) vlozit pres require_once a volat swetest_calc()/swetest_text()/swetest_json()
 *
 * Ciste PHP: bez EXE, DLL, PHP extension a FFI.
 * -----------------------------------------------------------------------------
 */


if (!function_exists('swetest_default_ephe_dir')) {
    function swetest_default_ephe_dir(): string
    {
        $candidates = [
            __DIR__ . '/ephe',       // fallback: ephe primo vedle swetest.php
            __DIR__ . '/../ephe',    // doporuceno: /private/swiss/swetest.php + /private/ephe
            __DIR__ . '/sweph/ephe',
            __DIR__ . '/../sweph/ephe',
        ];
        foreach ($candidates as $dir) {
            if (is_dir($dir)) return str_replace('\\', '/', realpath($dir) ?: $dir);
        }
        // Fallback: neexistuje, ale chyba pak jasne rekne, co chybi.
        return str_replace('\\', '/', $candidates[1]);
    }
}

if (!function_exists('swetest_normalize_ephe_dir')) {
    function swetest_normalize_ephe_dir(?string $edir): string
    {
        $edir = trim((string)$edir);
        if ($edir === '') return swetest_default_ephe_dir();
        $edir = str_replace('\\', '/', $edir);

        // Windows absolutni cesta: C:/...
        if (preg_match('/^[a-zA-Z]:\//', $edir) || swetest_starts_with($edir, '/')) {
            return rtrim($edir, '/');
        }

        // Relativni cesta se bere relativne k tomuto souboru.
        $full = __DIR__ . '/' . $edir;
        return rtrim(str_replace('\\', '/', realpath($full) ?: $full), '/');
    }
}

if (!function_exists('swetest_split_args')) {
    /**
     * Split a swetest-like query string into argv-style tokens.
     *
     * @return string[]
     */
    function swetest_split_args(string $input): array
    {
        $args = [];
        $token = '';
        $quote = null;
        $escape = false;
        $len = strlen($input);
        for ($i = 0; $i < $len; $i++) {
            $ch = $input[$i];
            if ($escape) {
                $token .= $ch;
                $escape = false;
                continue;
            }
            if ($ch === '\\' && $quote !== null) {
                $escape = true;
                continue;
            }
            if ($quote !== null) {
                if ($ch === $quote) {
                    $quote = null;
                } else {
                    $token .= $ch;
                }
                continue;
            }
            if ($ch === '"' || $ch === "'") {
                $quote = $ch;
                continue;
            }
            if (ctype_space($ch)) {
                if ($token !== '') {
                    $args[] = $token;
                    $token = '';
                }
                continue;
            }
            $token .= $ch;
        }
        if ($escape) {
            $token .= '\\';
        }
        if ($token !== '') {
            $args[] = $token;
        }
        return $args;
    }
}

if (!function_exists('swetest_is_arg_list')) {
    function swetest_is_arg_list(array $input): bool
    {
        if ($input === []) {
            return true;
        }
        $expected = 0;
        foreach ($input as $key => $value) {
            if ($key !== $expected || !is_scalar($value)) {
                return false;
            }
            $expected++;
        }
        return isset($input[0]) && is_string($input[0]) && swetest_starts_with((string)$input[0], '-');
    }
}

if (!function_exists('swetest_repair_cli_args')) {
    /**
     * PowerShell can split native-looking tokens like -b5.2.1998 into
     * "-b5" and ".2.1998". Repair that form for direct CLI use.
     *
     * @param string[] $args
     * @return string[]
     */
    function swetest_repair_cli_args(array $args): array
    {
        $out = [];
        $count = count($args);
        for ($i = 0; $i < $count; $i++) {
            $arg = (string)$args[$i];
            if (
                preg_match('/^-b\d{1,2}$/', $arg) === 1
                && isset($args[$i + 1])
                && preg_match('/^\.\d{1,2}\.\d{2,4}$/', (string)$args[$i + 1]) === 1
            ) {
                $out[] = $arg . (string)$args[$i + 1];
                $i++;
                continue;
            }
            $out[] = $arg;
        }
        return $out;
    }
}

if (!function_exists('swetest_build_args')) {
    /**
     * @param array<string,mixed>|string $input
     * @return string[] argumenty bez nazvu programu
     */
    function swetest_build_args($input = [], ?string $edir = null): array
    {
        if (is_string($input)) {
            $args = swetest_split_args($input);
        } else {
            if (swetest_is_arg_list($input)) {
                $args = swetest_repair_cli_args(array_map('strval', $input));
            } elseif (isset($input['q'])) {
                $args = swetest_split_args((string)$input['q']);
            } else {
                $args = [];
                if (isset($input['jd'])) {
                    $args[] = '-bj' . (string)$input['jd'];
                } else {
                    $date = $input['date'] ?? $input['b'] ?? null;
                    if ($date !== null) $args[] = '-b' . (string)$date;
                    $ut = $input['ut'] ?? $input['time_ut'] ?? null;
                    if ($ut !== null) $args[] = '-ut' . (string)$ut;
                }
                if (isset($input['bodies'])) $args[] = '-p' . (string)$input['bodies'];
                if (!empty($input['sidereal'])) $args[] = '-sid1';
                if (!empty($input['cz'])) $args[] = '-cz';
                if (!empty($input['decimal'])) $args[] = '-dec';
                if (!empty($input['json'])) $args[] = '-json';
                if (!empty($input['source'])) $args[] = '-src';
                if (!empty($input['deltat'])) $args[] = '-dt';
                if (!empty($input['geometric']) || !empty($input['true'])) $args[] = '-true';
                if (!empty($input['noaberr'])) $args[] = '-noaberr';
                if (!empty($input['nonut'])) $args[] = '-nonut';
                if (isset($input['n'])) $args[] = '-n' . (string)$input['n'];
                if (isset($input['step'])) $args[] = '-s' . (string)$input['step'];
            }
            if ($edir === null && isset($input['edir'])) $edir = (string)$input['edir'];
        }

        // Kdyz uzivatel nedal -edir do q/argumentu, vlozime rozumny default.
        $hasEdir = false;
        foreach ($args as $a) {
            if (swetest_starts_with((string)$a, '-edir')) { $hasEdir = true; break; }
        }
        if (!$hasEdir) array_unshift($args, '-edir' . swetest_normalize_ephe_dir($edir));
        return $args;
    }
}

if (!function_exists('swetest_zodiac_parts')) {
    /** @return array{sign_index:int,sign:string,sign_cz:string,degree:int,minute:int,second:float,position:string,position_cz:string} */
    function swetest_zodiac_parts(float $lon): array
    {
        $signs = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
        $signsCz = ['Beran','Byk','Blizenci','Rak','Lev','Panna','Vahy','Stir','Strelec','Kozoroh','Vodnar','Ryby'];
        $lon = SweMath::norm360($lon);
        $si = (int)floor($lon / 30.0);
        $x = ($lon - $si * 30.0) * 3600.0;
        $deg = (int)floor($x / 3600.0);
        $x -= $deg * 3600.0;
        $min = (int)floor($x / 60.0);
        $sec = round($x - $min * 60.0, 2);
        if ($sec >= 60.0) { $sec -= 60.0; $min++; }
        if ($min >= 60) { $min -= 60; $deg++; }
        if ($deg >= 30) { $deg -= 30; $si = ($si + 1) % 12; }
        return [
            'sign_index' => $si,
            'sign' => $signs[$si],
            'sign_cz' => $signsCz[$si],
            'degree' => $deg,
            'minute' => $min,
            'second' => $sec,
            'position' => sprintf('%02d%s%02d\'%05.2f"', $deg, $signs[$si], $min, $sec),
            'position_cz' => sprintf('%02d %s %02d\'%05.2f"', $deg, $signsCz[$si], $min, $sec),
        ];
    }
}

if (!function_exists('swetest_body_name_cz')) {
    function swetest_body_name_cz(string $name): string
    {
        static $map = [
            'Sun' => 'Slunce', 'Moon' => 'Mesic', 'Mercury' => 'Merkur', 'Venus' => 'Venuse',
            'Mars' => 'Mars', 'Jupiter' => 'Jupiter', 'Saturn' => 'Saturn', 'Uranus' => 'Uran',
            'Neptune' => 'Neptun', 'Pluto' => 'Pluto', 'mean Node' => 'Sev. uzel mean', 'true Node' => 'Sev. uzel true',
            'mean Apogee' => 'Lilith mean', 'osc. Apogee' => 'Lilith true', 'Earth' => 'Zeme',
            'Chiron' => 'Chiron', 'Pholus' => 'Pholus', 'Ceres' => 'Ceres', 'Pallas' => 'Pallas', 'Juno' => 'Juno', 'Vesta' => 'Vesta',
            'Cupido' => 'Cupido', 'Hades' => 'Hades', 'Zeus' => 'Zeus', 'Kronos' => 'Kronos',
            'Apollon' => 'Apollon', 'Admetos' => 'Admetos', 'Vulcanus' => 'Vulcanus', 'Vulkanus' => 'Vulcanus',
            'Poseidon' => 'Poseidon',
            'Waldemath' => 'Waldemath',
        ];
        return $map[$name] ?? $name;
    }
}

if (!function_exists('swetest_calc')) {
    /**
     * Vrati pole vypoctenych pozic.
     *
     * Priklad:
     * $pozice = swetest_calc([
     *   'date' => '24.1.1963',
     *   'ut' => '02:06',
     *   'bodies' => '0123456789mt',
     *   'cz' => true,
     *   'decimal' => true,
     * ]);
     *
     * @param array<string,mixed>|string $input Bud pole parametru, nebo swetest query typu "-b24.1.1963 -ut02:06 -p01m -cz -dec".
     * @return array<int,array<string,mixed>>
     */
    function swetest_calc($input = [], ?string $edir = null): array
    {
        $args = swetest_build_args($input, $edir);
        $opts = SweAstroLongitudeCli::parseArgs($args);
        $swe = new SweSe1($opts['edir']);
        $rows = [];
        $jd = (float)$opts['jd'];
        for ($row = 0; $row < (int)$opts['n']; $row++) {
            foreach ($opts['bodies'] as $body) {
                $r = $swe->calcUt($jd, (int)$body, (bool)$opts['sidereal'], (bool)$opts['truePos'], (bool)$opts['noAberr'], (bool)$opts['noNutation']);
                $name = SweSe1::$names[$body] ?? (string)$body;
                $z = swetest_zodiac_parts((float)$r['lon']);
                $rows[] = [
                    'body_id' => (int)$body,
                    'body' => $name,
                    'body_cz' => swetest_body_name_cz($name),
                    'jd_ut' => $jd,
                    'mode' => ($opts['sidereal'] ? 'sidereal_lahiri' : 'tropical') . ($opts['truePos'] ? '_geometric' : '_apparent'),
                    'longitude_deg' => (float)$r['lon'],
                    'latitude_deg' => (float)$r['lat'],
                    'distance_au' => (float)$r['dist'],
                    'speed_deg_per_day' => (float)$r['slon'],
                    'retrograde' => ((float)$r['slon']) < 0.0,
                    'source' => $r['source'] ?? 'se1',
                    'delta_t_seconds' => SweMath::deltaTSeconds($jd),
                    'light_deflection' => !$opts['truePos'],
                    'aberration' => !$opts['noAberr'] && !$opts['truePos'],
                    'nutation' => !$opts['noNutation'],
                ] + $z;
            }
            $jd += (float)$opts['step'];
        }
        $swe->close();
        return $rows;
    }
}

if (!function_exists('swetest_text')) {
    /**
     * Vrati textovy vystup vhodny do <pre> nebo pro CLI.
     * @param array<string,mixed>|string $input
     */
    function swetest_text($input = [], ?string $edir = null): string
    {
        $rows = swetest_calc($input, $edir);
        $lines = [];
        foreach ($rows as $r) {
            $name = $r['body_cz'] ?? $r['body'];
            $retro = !empty($r['retrograde']) ? ' R' : '';
            $lines[] = str_pad((string)$name, 16)
                . ' ' . $r['position_cz']
                . '  lon=' . sprintf('%.10f', (float)$r['longitude_deg'])
                . '  lat=' . sprintf('%+.10f', (float)$r['latitude_deg'])
                . '  speed=' . sprintf('%+.8f', (float)$r['speed_deg_per_day']) . ' deg/day' . $retro
                . (isset($r['house']) ? '  house=' . sprintf('%.3f', (float)$r['house']) : '')
                . '  ' . (string)$r['mode'];
        }
        return implode(PHP_EOL, $lines);
    }
}

if (!function_exists('swetest_json')) {
    /**
     * @param array<string,mixed>|string $input
     */
    function swetest_json($input = [], ?string $edir = null): string
    {
        return json_encode(swetest_calc($input, $edir), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }
}


if (!function_exists('swetest_chart')) {
    function swetest_load_extra(): bool
    {
        $extraPath = __DIR__ . DIRECTORY_SEPARATOR . 'swetest_sweph_extra.php';
        if (!is_file($extraPath)) {
            return false;
        }
        require_once $extraPath;
        return true;
    }

    /**
     * @param array<string,mixed>|string $input
     */
    function swetest_input_has_houses($input): bool
    {
        if (is_string($input)) {
            return strpos($input, '-house') !== false;
        }
        if (!is_array($input)) {
            return false;
        }
        return isset($input['house']) || (isset($input['longitude']) && isset($input['latitude']));
    }

    /**
     * Vrati planety + volitelne domy. Kdyz je zadano -house, doplni ke kazde planete cislo domu.
     *
     * @param array<string,mixed>|string $input
     * @return array{positions:array<int,array<string,mixed>>,houses:?array<string,mixed>}
     */
    function swetest_chart($input = [], ?string $edir = null): array
    {
        $positions = swetest_calc($input, $edir);
        $houses = null;
        if (swetest_input_has_houses($input)) {
            try {
                if ((!function_exists('swetest_houses') || !class_exists('SweHouses')) && !swetest_load_extra()) {
                    throw new RuntimeException('Chybi volitelny modul swetest_sweph_extra.php pro domy.');
                }
                $houses = swetest_houses($input, $edir);
                foreach ($positions as &$p) {
                    $hp = SweHouses::housePosition(
                        (float)$p['longitude_deg'],
                        (float)$p['latitude_deg'],
                        (float)$houses['armc'],
                        (float)$houses['geo_latitude'],
                        (float)$houses['eps'],
                        $houses['cusps'],
                        (string)$houses['house_system']
                    );
                    $p['house'] = $hp;
                    $p['house_number'] = (int)floor($hp);
                    if ($p['house_number'] < 1) $p['house_number'] = 12;
                    if ($p['house_number'] > 12) $p['house_number'] = 12;
                }
                unset($p);
            } catch (Throwable $e) {
                $houses = null;
            }
        }
        return ['positions' => $positions, 'houses' => $houses];
    }
}

if (!function_exists('swetest_chart_text')) {
    /**
     * @param array<string,mixed>|string $input
     */
    function swetest_chart_text($input = [], ?string $edir = null): string
    {
        $chart = swetest_chart($input, $edir);
        $lines = [];
        foreach ($chart['positions'] as $r) {
            $name = $r['body_cz'] ?? $r['body'];
            $retro = !empty($r['retrograde']) ? ' R' : '';
            $house = isset($r['house']) ? '  house=' . sprintf('%.3f', (float)$r['house']) : '';
            $lines[] = str_pad((string)$name, 16)
                . ' ' . $r['position_cz']
                . '  lon=' . sprintf('%.10f', (float)$r['longitude_deg'])
                . '  lat=' . sprintf('%+.10f', (float)$r['latitude_deg'])
                . '  speed=' . sprintf('%+.8f', (float)$r['speed_deg_per_day']) . ' deg/day' . $retro
                . $house
                . '  ' . (string)$r['mode'];
        }
        if ($chart['houses'] !== null) {
            $lines[] = '';
            if (!function_exists('swetest_houses_text')) {
                swetest_load_extra();
            }
            if (function_exists('swetest_houses_text')) {
                $lines[] = swetest_houses_text($input, $edir);
            }
        }
        return implode(PHP_EOL, $lines);
    }
}

if (!function_exists('swetest_chart_json')) {
    /**
     * @param array<string,mixed>|string $input
     */
    function swetest_chart_json($input = [], ?string $edir = null): string
    {
        return json_encode(swetest_chart($input, $edir), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }
}

if (!function_exists('swetest_full_chart')) {
    /**
     * Kompatibilni API pouzivane aplikaci: vraci planety + domy.
     * @param array<string,mixed>|string $input
     * @return array{positions:array<int,array<string,mixed>>,houses:?array<string,mixed>}
     */
    function swetest_full_chart($input = [], ?string $edir = null): array
    {
        return swetest_chart($input, $edir);
    }
}

// Prime spusteni pres CLI nebo Apache. Pri require_once se nic automaticky nevypise.
$__swetest_direct = false;
if (PHP_SAPI === 'cli') {
    $__swetest_direct = isset($argv) && realpath((string)($argv[0] ?? '')) === realpath(__FILE__);
} else {
    $__script = $_SERVER['SCRIPT_FILENAME'] ?? '';
    $__swetest_direct = $__script !== '' && realpath($__script) === realpath(__FILE__);
}

if ($__swetest_direct) {
    if (PHP_SAPI !== 'cli') {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Forbidden' . PHP_EOL;
        return;
    }

    try {
        echo swetest_chart_text(array_slice($argv, 1)) . PHP_EOL;
    } catch (Throwable $e) {
        echo 'CHYBA: ' . $e->getMessage() . PHP_EOL;
    }
}

