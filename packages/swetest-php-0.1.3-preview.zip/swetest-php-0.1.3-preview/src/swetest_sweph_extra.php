<?php
/**
 * swetest_sweph_extra.php
 *
 * Volitelny pure-PHP modul s pomocnymi funkcemi ve stylu Swiss Ephemeris API.
 * Kompatibilni s PHP 7.4. Bez EXE/DLL/extension/FFI.
 *
 * Pouziti:
 *   require_once __DIR__ . '/swetest.php';              // volitelne, hlavni astro port
 *   require_once __DIR__ . '/swetest_sweph_extra.php';  // tyto helpery
 *
 * Poznamka:
 * - Funkce jsou definovane jen pokud jeste neexistuji, aby nekolidovaly s pripadnou nativni extension.
 * - Datumove prevody jsou deterministicke a pouzitelne.
 * - Delta T a equation of time jsou pure-PHP aproximace; pokud je nacten hlavni swetest.php,
 *   pouzije se jeho SweMath::deltaTSeconds(), aby byla konzistence s vypocty horoskopu.
 */

// Preferuj jednotny backend ze swetest.php, pokud je dostupny.
if (!function_exists('swetest_full_chart')) {
    $swetestMain = __DIR__ . '/swetest.php';
    if (is_file($swetestMain)) {
        require_once $swetestMain;
    }
}

if (!defined('SE_OK'))  define('SE_OK', 0);
if (!defined('SE_ERR')) define('SE_ERR', -1);
if (!defined('SE_GREG_CAL')) define('SE_GREG_CAL', 1);
if (!defined('SE_JUL_CAL'))  define('SE_JUL_CAL', 0);
if (!defined('SEFLG_SWIEPH')) define('SEFLG_SWIEPH', 2);
if (!defined('SEFLG_JPLEPH')) define('SEFLG_JPLEPH', 1);
if (!defined('SEFLG_MOSEPH')) define('SEFLG_MOSEPH', 4);
if (!defined('SEFLG_TRUEPOS')) define('SEFLG_TRUEPOS', 16);
if (!defined('SEFLG_J2000')) define('SEFLG_J2000', 32);
if (!defined('SEFLG_NONUT')) define('SEFLG_NONUT', 64);
if (!defined('SEFLG_SPEED3')) define('SEFLG_SPEED3', 128);
if (!defined('SEFLG_SPEED')) define('SEFLG_SPEED', 256);
if (!defined('SEFLG_NOABERR')) define('SEFLG_NOABERR', 1024);
if (!defined('SEFLG_EQUATORIAL')) define('SEFLG_EQUATORIAL', 2048);
if (!defined('SEFLG_XYZ')) define('SEFLG_XYZ', 4096);
if (!defined('SEFLG_RADIANS')) define('SEFLG_RADIANS', 8192);
if (!defined('SEFLG_SIDEREAL')) define('SEFLG_SIDEREAL', 65536);
if (!defined('SE_DELTAT_AUTOMATIC')) define('SE_DELTAT_AUTOMATIC', -1.0e100);
if (!defined('SE_TIDAL_AUTOMATIC')) define('SE_TIDAL_AUTOMATIC', 999999.0);
if (!defined('SE_ECL_NUT')) define('SE_ECL_NUT', -1);
if (!defined('SE_SUN')) define('SE_SUN', 0);
if (!defined('SE_MOON')) define('SE_MOON', 1);
if (!defined('SE_MERCURY')) define('SE_MERCURY', 2);
if (!defined('SE_VENUS')) define('SE_VENUS', 3);
if (!defined('SE_MARS')) define('SE_MARS', 4);
if (!defined('SE_JUPITER')) define('SE_JUPITER', 5);
if (!defined('SE_SATURN')) define('SE_SATURN', 6);
if (!defined('SE_URANUS')) define('SE_URANUS', 7);
if (!defined('SE_NEPTUNE')) define('SE_NEPTUNE', 8);
if (!defined('SE_PLUTO')) define('SE_PLUTO', 9);
if (!defined('SE_MEAN_NODE')) define('SE_MEAN_NODE', 10);
if (!defined('SE_TRUE_NODE')) define('SE_TRUE_NODE', 11);
if (!defined('SE_MEAN_APOG')) define('SE_MEAN_APOG', 12);
if (!defined('SE_OSCU_APOG')) define('SE_OSCU_APOG', 13);
if (!defined('SE_EARTH')) define('SE_EARTH', 14);
if (!defined('SE_CHIRON')) define('SE_CHIRON', 15);
if (!defined('SE_PHOLUS')) define('SE_PHOLUS', 16);
if (!defined('SE_CERES')) define('SE_CERES', 17);
if (!defined('SE_PALLAS')) define('SE_PALLAS', 18);
if (!defined('SE_JUNO')) define('SE_JUNO', 19);
if (!defined('SE_VESTA')) define('SE_VESTA', 20);
if (!defined('SE_SELENA')) define('SE_SELENA', 56);
if (!defined('SE_WHITE_MOON')) define('SE_WHITE_MOON', 56);
if (!defined('SE_WALDEMATH')) define('SE_WALDEMATH', 58);
if (!defined('SE_AST_OFFSET')) define('SE_AST_OFFSET', 10000);

$GLOBALS['SWETEST_EXTRA_EPHE_PATH'] = isset($GLOBALS['SWETEST_EXTRA_EPHE_PATH']) ? $GLOBALS['SWETEST_EXTRA_EPHE_PATH'] : '';
$GLOBALS['SWETEST_EXTRA_JPL_FILE'] = isset($GLOBALS['SWETEST_EXTRA_JPL_FILE']) ? $GLOBALS['SWETEST_EXTRA_JPL_FILE'] : '';
$GLOBALS['SWETEST_EXTRA_TID_ACC'] = isset($GLOBALS['SWETEST_EXTRA_TID_ACC']) ? $GLOBALS['SWETEST_EXTRA_TID_ACC'] : -25.858;
$GLOBALS['SWETEST_EXTRA_TID_ACC_AUTOMATIC'] = isset($GLOBALS['SWETEST_EXTRA_TID_ACC_AUTOMATIC']) ? $GLOBALS['SWETEST_EXTRA_TID_ACC_AUTOMATIC'] : true;
$GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] = isset($GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF']) ? $GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] : null;
$GLOBALS['SWETEST_EXTRA_DT_TABLE'] = isset($GLOBALS['SWETEST_EXTRA_DT_TABLE']) ? $GLOBALS['SWETEST_EXTRA_DT_TABLE'] : null;
$GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'] = isset($GLOBALS['SWETEST_EXTRA_LEAP_SECONDS']) ? $GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'] : null;
$GLOBALS['SWETEST_EXTRA_SID_MODE'] = isset($GLOBALS['SWETEST_EXTRA_SID_MODE']) ? $GLOBALS['SWETEST_EXTRA_SID_MODE'] : 1;
$GLOBALS['SWETEST_EXTRA_SID_T0'] = isset($GLOBALS['SWETEST_EXTRA_SID_T0']) ? $GLOBALS['SWETEST_EXTRA_SID_T0'] : 0.0;
$GLOBALS['SWETEST_EXTRA_SID_AYAN_T0'] = isset($GLOBALS['SWETEST_EXTRA_SID_AYAN_T0']) ? $GLOBALS['SWETEST_EXTRA_SID_AYAN_T0'] : 0.0;

if (!function_exists('swe_extra_norm360')) {
    function swe_extra_norm360($x) {
        $r = fmod((float)$x, 360.0);
        if ($r < 0.0) $r += 360.0;
        if ($r >= 360.0) $r -= 360.0;
        return $r;
    }
}

if (!function_exists('swe_extra_norm180')) {
    function swe_extra_norm180($x) {
        $r = swe_extra_norm360($x);
        if ($r > 180.0) $r -= 360.0;
        return $r;
    }
}

if (!function_exists('swe_extra_julday_core')) {
    function swe_extra_julday_core($year, $month, $day, $hour, $gregflag) {
        $y = (int)$year;
        $m = (int)$month;
        $d = (int)$day;
        $h = (float)$hour;
        if ($m <= 2) { $y -= 1; $m += 12; }
        $a = floor($y / 100.0);
        $b = ((int)$gregflag) ? 2 - $a + floor($a / 4.0) : 0;
        return floor(365.25 * ($y + 4716)) + floor(30.6001 * ($m + 1)) + $d + $b - 1524.5 + $h / 24.0;
    }
}

if (!function_exists('swe_extra_revjul_core')) {
    function swe_extra_revjul_core($tjd, $gregflag) {
        $jd = (float)$tjd + 0.5;
        $z = floor($jd);
        $f = $jd - $z;
        if ((int)$gregflag) {
            $alpha = floor(($z - 1867216.25) / 36524.25);
            $a = $z + 1 + $alpha - floor($alpha / 4.0);
        } else {
            $a = $z;
        }
        $b = $a + 1524;
        $c = floor(($b - 122.1) / 365.25);
        $d = floor(365.25 * $c);
        $e = floor(($b - $d) / 30.6001);
        $dayFloat = $b - $d - floor(30.6001 * $e) + $f;
        $day = (int)floor($dayFloat);
        $hour = ($dayFloat - $day) * 24.0;
        $month = ($e < 14) ? (int)($e - 1) : (int)($e - 13);
        $year = ($month > 2) ? (int)($c - 4716) : (int)($c - 4715);
        return array($year, $month, $day, $hour);
    }
}


if (!function_exists('swe_extra_ephe_path')) {
    function swe_extra_ephe_path() {
        $base = isset($GLOBALS['SWETEST_EXTRA_EPHE_PATH']) ? (string)$GLOBALS['SWETEST_EXTRA_EPHE_PATH'] : '';
        if ($base === '' && function_exists('swetest_default_ephe_dir')) {
            $base = swetest_default_ephe_dir();
        }
        return rtrim(str_replace('\\', '/', $base), '/');
    }
}

if (!function_exists('swe_extra_decimal_year_from_jd')) {
    function swe_extra_decimal_year_from_jd($tjd) {
        $y = $m = $d = 0; $h = 0.0;
        swe_revjul((float)$tjd, SE_GREG_CAL, $y, $m, $d, $h);
        $jd0 = swe_julday($y, 1, 1, 0.0, SE_GREG_CAL);
        $jd1 = swe_julday($y + 1, 1, 1, 0.0, SE_GREG_CAL);
        if ($jd1 == $jd0) return (float)$y;
        return (float)$y + (((float)$tjd - $jd0) / ($jd1 - $jd0));
    }
}

if (!function_exists('swetest_lahiri_ayanamsha')) {
    /**
     * Precise optional Lahiri table for sidereal calculations.
     * The large table files are loaded only when this function is called.
     *
     * @return float|null
     */
    function swetest_lahiri_ayanamsha($tjd_et) {
        static $tab = null;
        if (!is_array($tab)) {
            $tab = array();
            foreach (array('ayan_lahiri_daily_1900_2101.php', 'ayan_lahiri_weekly.php') as $tableFile) {
                $tablePath = __DIR__ . DIRECTORY_SEPARATOR . $tableFile;
                if (!is_file($tablePath)) {
                    continue;
                }
                $table = include $tablePath;
                if (is_array($table)) {
                    foreach ($table as $row) {
                        if (!is_array($row) || count($row) < 2 || !is_numeric($row[0]) || !is_numeric($row[1])) {
                            continue;
                        }
                        $tab[] = array((float)$row[0], (float)$row[1]);
                    }
                }
                if (count($tab) >= 2) {
                    break;
                }
            }
            if (count($tab) < 2) {
                $yearlyPath = __DIR__ . DIRECTORY_SEPARATOR . 'ayan_lahiri_yearly.php';
                if (is_file($yearlyPath)) {
                    $yearly = include $yearlyPath;
                    if (is_array($yearly)) {
                        ksort($yearly, SORT_NUMERIC);
                        foreach ($yearly as $year => $ayan) {
                            if (!is_numeric($year) || !is_numeric($ayan)) {
                                continue;
                            }
                            $yy = (int)$year;
                            if ($yy < 1500 || $yy > 2500) {
                                continue;
                            }
                            $tab[] = array(swe_extra_julday_core($yy, 1, 1, 0.0, SE_GREG_CAL), (float)$ayan);
                        }
                    }
                }
            }
        }
        if (count($tab) < 2) {
            return null;
        }
        $n = count($tab);
        $x = (float)$tjd_et;
        if ($x <= $tab[0][0]) {
            $rate = ($tab[1][1] - $tab[0][1]) / ($tab[1][0] - $tab[0][0]);
            return $tab[0][1] + ($x - $tab[0][0]) * $rate;
        }
        if ($x >= $tab[$n - 1][0]) {
            $rate = ($tab[$n - 1][1] - $tab[$n - 2][1]) / ($tab[$n - 1][0] - $tab[$n - 2][0]);
            return $tab[$n - 1][1] + ($x - $tab[$n - 1][0]) * $rate;
        }
        $lo = 0;
        $hi = $n - 1;
        while ($hi - $lo > 1) {
            $mid = intdiv($lo + $hi, 2);
            if ($x <= $tab[$mid][0]) {
                $hi = $mid;
            } else {
                $lo = $mid;
            }
        }
        $f = ($x - $tab[$lo][0]) / ($tab[$hi][0] - $tab[$lo][0]);
        return $tab[$lo][1] + ($tab[$hi][1] - $tab[$lo][1]) * $f;
    }
}

if (!function_exists('swe_extra_load_deltat_file')) {
    function swe_extra_load_deltat_file($path = null) {
        if ($GLOBALS['SWETEST_EXTRA_DT_TABLE'] !== null && $path === null) {
            return $GLOBALS['SWETEST_EXTRA_DT_TABLE'];
        }
        $base = ($path === null) ? swe_extra_ephe_path() : rtrim(str_replace('\\', '/', (string)$path), '/');
        $table = array();
        if ($base !== '') {
            $file = $base . '/swe_deltat.txt';
            if (is_file($file) && is_readable($file)) {
                $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (is_array($lines)) {
                    foreach ($lines as $line) {
                        $line = trim(preg_replace('/#.*/', '', $line));
                        if ($line === '') continue;
                        $parts = preg_split('/[\s,;]+/', $line);
                        if (count($parts) >= 2 && is_numeric($parts[0]) && is_numeric($parts[1])) {
                            $table[] = array((float)$parts[0], (float)$parts[1]);
                        }
                    }
                }
            }
        }
        usort($table, function($a, $b) { if ($a[0] == $b[0]) return 0; return ($a[0] < $b[0]) ? -1 : 1; });
        if ($path === null) $GLOBALS['SWETEST_EXTRA_DT_TABLE'] = $table;
        return $table;
    }
}

if (!function_exists('swe_extra_deltat_file_seconds')) {
    function swe_extra_deltat_file_seconds($tjd) {
        $table = swe_extra_load_deltat_file();
        $n = count($table);
        if ($n == 0) return null;
        $y = swe_extra_decimal_year_from_jd($tjd);
        if ($y < $table[0][0] || $y > $table[$n - 1][0]) return null;
        for ($i = 0; $i < $n - 1; $i++) {
            if ($y >= $table[$i][0] && $y <= $table[$i + 1][0]) {
                $dy = $table[$i + 1][0] - $table[$i][0];
                if ($dy == 0.0) return $table[$i][1];
                $f = ($y - $table[$i][0]) / $dy;
                return $table[$i][1] + ($table[$i + 1][1] - $table[$i][1]) * $f;
            }
        }
        return $table[$n - 1][1];
    }
}

if (!function_exists('swe_extra_builtin_leap_second_days')) {
    function swe_extra_builtin_leap_second_days() {
        return array(
            '1972-06-30','1972-12-31','1973-12-31','1974-12-31','1975-12-31','1976-12-31',
            '1977-12-31','1978-12-31','1979-12-31','1981-06-30','1982-06-30','1983-06-30',
            '1985-06-30','1987-12-31','1989-12-31','1990-12-31','1992-06-30','1993-06-30',
            '1994-06-30','1995-12-31','1997-06-30','1998-12-31','2005-12-31','2008-12-31',
            '2012-06-30','2015-06-30','2016-12-31'
        );
    }
}

if (!function_exists('swe_extra_load_leapsec')) {
    function swe_extra_load_leapsec($path = null) {
        if ($GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'] !== null && $path === null) {
            return $GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'];
        }
        $days = array();
        foreach (swe_extra_builtin_leap_second_days() as $d) $days[$d] = true;
        $base = ($path === null) ? swe_extra_ephe_path() : rtrim(str_replace('\\', '/', (string)$path), '/');
        if ($base !== '') {
            $file = $base . '/seleapsec.txt';
            if (is_file($file) && is_readable($file)) {
                $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (is_array($lines)) {
                    foreach ($lines as $line) {
                        $line = trim(preg_replace('/#.*/', '', $line));
                        if ($line === '') continue;
                        $parts = preg_split('/[\s,;]+/', $line);
                        $y = $m = $d = null;
                        if (count($parts) >= 3 && is_numeric($parts[0]) && is_numeric($parts[1]) && is_numeric($parts[2])) {
                            $y = (int)$parts[0]; $m = (int)$parts[1]; $d = (int)$parts[2];
                        } elseif (count($parts) >= 1 && preg_match('/^(\d{4})(\d{2})(\d{2})$/', $parts[0], $mm)) {
                            $y = (int)$mm[1]; $m = (int)$mm[2]; $d = (int)$mm[3];
                        }
                        if ($y !== null && $m >= 1 && $m <= 12 && $d >= 1 && $d <= 31) {
                            $days[sprintf('%04d-%02d-%02d', $y, $m, $d)] = true;
                        }
                    }
                }
            }
        }
        $out = array_keys($days);
        sort($out);
        if ($path === null) $GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'] = $out;
        return $out;
    }
}

if (!function_exists('swe_extra_is_leap_second_day')) {
    function swe_extra_is_leap_second_day($y, $m, $d) {
        $key = sprintf('%04d-%02d-%02d', (int)$y, (int)$m, (int)$d);
        return in_array($key, swe_extra_load_leapsec(), true);
    }
}

/* -------------------------------------------------------------------------
 * 18.7 Helper functions
 * ------------------------------------------------------------------------- */

if (!function_exists('swe_csnorm')) {
    function swe_csnorm($p) {
        $deg360 = 129600000; // 360 * 3600 * 100
        $r = (int)$p % $deg360;
        if ($r < 0) $r += $deg360;
        return $r;
    }
}

if (!function_exists('swe_difcsn')) {
    function swe_difcsn($p1, $p2) {
        return swe_csnorm((int)$p1 - (int)$p2);
    }
}

if (!function_exists('swe_difdegn')) {
    function swe_difdegn($p1, $p2) {
        return swe_extra_norm360((float)$p1 - (float)$p2);
    }
}

if (!function_exists('swe_difcs2n')) {
    function swe_difcs2n($p1, $p2) {
        $deg180 = 64800000;  // 180 * 3600 * 100
        $deg360 = 129600000;
        $r = swe_difcsn($p1, $p2);
        if ($r > $deg180) $r -= $deg360;
        return $r;
    }
}

if (!function_exists('swe_difdeg2n')) {
    function swe_difdeg2n($p1, $p2) {
        return swe_extra_norm180((float)$p1 - (float)$p2);
    }
}

if (!function_exists('swe_csroundsec')) {
    function swe_csroundsec($x) {
        $x = (int)$x;
        $sign = ($x < 0) ? -1 : 1;
        $ax = abs($x);
        $sec = 100;
        $sign30 = 30 * 3600 * 100;
        $rounded = (int)(floor($ax / $sec + 0.5) * $sec);
        // Swiss-style ochrana: 29°59'59.5" neprevalit na 30°00'00".
        $remBefore = $ax % $sign30;
        $remAfter = $rounded % $sign30;
        if ($remBefore >= $sign30 - $sec && $remAfter == 0) {
            $rounded = $sign30 - $sec + (int)(floor($ax / $sign30) * $sign30);
        }
        return $sign * $rounded;
    }
}

if (!function_exists('swe_d2l')) {
    function swe_d2l($x) {
        $x = (float)$x;
        return ($x >= 0.0) ? (int)floor($x + 0.5) : (int)ceil($x - 0.5);
    }
}

if (!function_exists('swe_day_of_week')) {
    function swe_day_of_week($jd) {
        // Monday = 0 ... Sunday = 6. JD 2451544.5 = 2000-01-01 Saturday => 5.
        $d = (int)floor((float)$jd + 0.5) % 7;
        if ($d < 0) $d += 7;
        return $d;
    }
}

if (!function_exists('swe_cs2timestr')) {
    function swe_cs2timestr($t, $sep = ':', $suppressZero = false, &$a = null) {
        $t = (int)$t;
        $sign = '';
        if ($t < 0) { $sign = '-'; $t = -$t; }
        $totalSec = swe_d2l($t / 100.0);
        $h = (int)floor($totalSec / 3600);
        $m = (int)floor(($totalSec % 3600) / 60);
        $s = (int)($totalSec % 60);
        $sep = ($sep === 0 || $sep === '0') ? '' : (string)$sep;
        if ($suppressZero && $h == 0) {
            $out = sprintf('%s%02d%s%02d', $sign, $m, $sep, $s);
        } else {
            $out = sprintf('%s%02d%s%02d%s%02d', $sign, $h, $sep, $m, $sep, $s);
        }
        $a = $out;
        return $out;
    }
}

if (!function_exists('swe_cs2lonlatstr')) {
    function swe_cs2lonlatstr($t, $pchar = '+', $mchar = '-', &$s = null) {
        $t = swe_csroundsec((int)$t);
        $char = ($t < 0) ? $mchar : $pchar;
        $at = abs($t);
        $totalSec = (int)floor($at / 100);
        $deg = (int)floor($totalSec / 3600);
        $min = (int)floor(($totalSec % 3600) / 60);
        $sec = (int)($totalSec % 60);
        $out = sprintf('%d%s%02d\'%02d"', $deg, $char, $min, $sec);
        $s = $out;
        return $out;
    }
}

if (!function_exists('swe_cs2degstr')) {
    function swe_cs2degstr($t, &$a = null) {
        $t = swe_csroundsec((int)$t);
        $sign = ($t < 0) ? '-' : '';
        $at = abs($t);
        $totalSec = (int)floor($at / 100);
        $deg = (int)floor($totalSec / 3600);
        $min = (int)floor(($totalSec % 3600) / 60);
        $sec = (int)($totalSec % 60);
        $out = sprintf('%s%d°%02d\'%02d"', $sign, $deg, $min, $sec);
        $a = $out;
        return $out;
    }
}

/* -------------------------------------------------------------------------
 * 18.3 Date and time conversion
 * ------------------------------------------------------------------------- */

if (!function_exists('swe_deltat_ex')) {
    function swe_deltat_ex($tjd, $ephe_flag = SEFLG_SWIEPH, &$serr = null) {
        $serr = '';
        if ($GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] !== null) {
            return (float)$GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'];
        }
        if (((int)$ephe_flag) === SEFLG_SWIEPH && swe_extra_ephe_path() === '') {
            $serr = 'warning: ephemeris path has not been set; Delta T uses internal fallback table/model';
        }
        if (((int)$ephe_flag) === SEFLG_JPLEPH && (string)$GLOBALS['SWETEST_EXTRA_JPL_FILE'] === '') {
            $serr = 'warning: JPL file has not been set; Delta T uses internal fallback table/model';
        }
        $dtFile = swe_extra_deltat_file_seconds((float)$tjd);
        if ($dtFile !== null) {
            return ((float)$dtFile) / 86400.0;
        }
        if (class_exists('SweMath') && method_exists('SweMath', 'deltaTSeconds')) {
            return SweMath::deltaTSeconds((float)$tjd) / 86400.0;
        }
        $yr = swe_extra_revjul_core((float)$tjd, 1);
        $y = $yr[0] + ($yr[1] - 0.5) / 12.0;
        if ($y < 948) {
            $u = ($y - 2000) / 100.0;
            $dt = 2177 + 497 * $u + 44.1 * $u * $u;
        } elseif ($y < 1600) {
            $u = ($y - 2000) / 100.0;
            $dt = 102 + 102 * $u + 25.3 * $u * $u;
        } elseif ($y < 2005) {
            $t = $y - 2000;
            $dt = 63.86 + 0.3345*$t - 0.060374*$t*$t + 0.0017275*$t*$t*$t + 0.000651814*$t*$t*$t*$t + 0.00002373599*$t*$t*$t*$t*$t;
        } elseif ($y < 2050) {
            $t = $y - 2000;
            $dt = 62.92 + 0.32217*$t + 0.005589*$t*$t;
        } else {
            $u = ($y - 1820) / 100.0;
            $dt = -20 + 32 * $u * $u;
        }
        return $dt / 86400.0;
    }
}

if (!function_exists('swe_deltat')) {
    function swe_deltat($tjd) {
        $serr = '';
        return swe_deltat_ex($tjd, SEFLG_SWIEPH, $serr);
    }
}

if (!function_exists('swe_julday')) {
    function swe_julday($year, $month, $day, $hour, $gregflag = SE_GREG_CAL) {
        if (class_exists('SweMath') && method_exists('SweMath', 'julday')) {
            return SweMath::julday((int)$year, (int)$month, (int)$day, (float)$hour, ((int)$gregflag) != 0);
        }
        return swe_extra_julday_core($year, $month, $day, $hour, $gregflag);
    }
}

if (!function_exists('swe_revjul')) {
    function swe_revjul($tjd, $gregflag = SE_GREG_CAL, &$year = null, &$month = null, &$day = null, &$hour = null) {
        if (class_exists('SweMath') && method_exists('SweMath', 'revjul')) {
            $r = SweMath::revjul((float)$tjd, ((int)$gregflag) != 0);
        } else {
            $r = swe_extra_revjul_core($tjd, $gregflag);
        }
        $year = $r[0]; $month = $r[1]; $day = $r[2]; $hour = $r[3];
        return $r;
    }
}

if (!function_exists('swe_date_conversion')) {
    function swe_date_conversion($y, $m, $d, $hour, $c, &$tjd) {
        $gregflag = (strtolower((string)$c) === 'j') ? SE_JUL_CAL : SE_GREG_CAL;
        if ((int)$m < 1 || (int)$m > 12 || (int)$d < 1 || (int)$d > 31 || (float)$hour < 0.0 || (float)$hour >= 24.0) {
            $tjd = 0.0;
            return SE_ERR;
        }
        $jd = swe_julday((int)$y, (int)$m, (int)$d, (float)$hour, $gregflag);
        $yy = $mm = $dd = 0; $hh = 0.0;
        swe_revjul($jd, $gregflag, $yy, $mm, $dd, $hh);
        if ((int)$yy !== (int)$y || (int)$mm !== (int)$m || (int)$dd !== (int)$d) {
            $tjd = 0.0;
            return SE_ERR;
        }
        $tjd = $jd;
        return SE_OK;
    }
}

if (!function_exists('swe_utc_timezone')) {
    function swe_utc_timezone($iyear, $imonth, $iday, $ihour, $imin, $dsec, $d_timezone,
                              &$iyear_out, &$imonth_out, &$iday_out, &$ihour_out, &$imin_out, &$dsec_out) {
        $hour = (int)$ihour + ((int)$imin) / 60.0 + ((float)$dsec) / 3600.0;
        // Swiss convention: local -> UTC pouzij +timezone, tj. odecist offset.
        $jd = swe_julday((int)$iyear, (int)$imonth, (int)$iday, $hour - (float)$d_timezone, SE_GREG_CAL);
        $h = 0.0;
        swe_revjul($jd, SE_GREG_CAL, $iyear_out, $imonth_out, $iday_out, $h);
        $ihour_out = (int)floor($h);
        $mf = ($h - $ihour_out) * 60.0;
        $imin_out = (int)floor($mf);
        $dsec_out = ($mf - $imin_out) * 60.0;
        if ($dsec_out >= 59.99999) { $dsec_out = 0.0; $imin_out++; }
        if ($imin_out >= 60) { $imin_out = 0; $ihour_out++; }
    }
}

if (!function_exists('swe_utc_time_zone')) {
    function swe_utc_time_zone($iyear, $imonth, $iday, $ihour, $imin, $dsec, $d_timezone,
                               &$iyear_out, &$imonth_out, &$iday_out, &$ihour_out, &$imin_out, &$dsec_out) {
        return swe_utc_timezone($iyear, $imonth, $iday, $ihour, $imin, $dsec, $d_timezone,
                                $iyear_out, $imonth_out, $iday_out, $ihour_out, $imin_out, $dsec_out);
    }
}

if (!function_exists('swe_utc_to_jd')) {
    function swe_utc_to_jd($iyear, $imonth, $iday, $ihour, $imin, $dsec, $gregflag, &$dret, &$serr = null) {
        $serr = '';
        $dret = array(0.0, 0.0);
        $sec = (float)$dsec;
        if ((int)$ihour < 0 || (int)$ihour > 23 || (int)$imin < 0 || (int)$imin > 59 || $sec < 0.0 || $sec >= 61.0) {
            $serr = 'Invalid UTC time';
            return SE_ERR;
        }
        if ($sec >= 60.0) {
            if ((int)$ihour !== 23 || (int)$imin !== 59 || !swe_extra_is_leap_second_day($iyear, $imonth, $iday)) {
                $serr = 'Invalid leap second date/time';
                return SE_ERR;
            }
            $hour = 24.0 + ($sec - 60.0) / 3600.0;
            $jdUt = swe_julday((int)$iyear, (int)$imonth, (int)$iday, $hour, (int)$gregflag);
        } else {
            $hour = (int)$ihour + ((int)$imin) / 60.0 + $sec / 3600.0;
            $rc = swe_date_conversion($iyear, $imonth, $iday, $hour, ((int)$gregflag ? 'g' : 'j'), $jdUt);
            if ($rc !== SE_OK) {
                $serr = 'Invalid calendar date';
                return SE_ERR;
            }
        }
        $dt = swe_deltat($jdUt);
        $dret = array($jdUt + $dt, $jdUt);
        return SE_OK;
    }
}

if (!function_exists('swe_jdet_to_utc')) {
    function swe_jdet_to_utc($tjd_et, $gregflag, &$iyear, &$imonth, &$iday, &$ihour, &$imin, &$dsec) {
        $jdUt = (float)$tjd_et - swe_deltat((float)$tjd_et);
        // mala iterace kvuli zavislosti Delta T na UT
        $jdUt = (float)$tjd_et - swe_deltat($jdUt);
        swe_jdut1_to_utc($jdUt, $gregflag, $iyear, $imonth, $iday, $ihour, $imin, $dsec);
    }
}

if (!function_exists('swe_jdut1_to_utc')) {
    function swe_jdut1_to_utc($tjd_ut, $gregflag, &$iyear, &$imonth, &$iday, &$ihour, &$imin, &$dsec) {
        $h = 0.0;
        swe_revjul((float)$tjd_ut, $gregflag, $iyear, $imonth, $iday, $h);
        $ihour = (int)floor($h);
        $mf = ($h - $ihour) * 60.0;
        $imin = (int)floor($mf);
        $dsec = ($mf - $imin) * 60.0;
        if ($dsec >= 59.99999) { $dsec = 0.0; $imin++; }
        if ($imin >= 60) { $imin = 0; $ihour++; }
    }
}

if (!function_exists('swe_get_tid_acc')) {
    function swe_get_tid_acc() {
        return (float)$GLOBALS['SWETEST_EXTRA_TID_ACC'];
    }
}

if (!function_exists('swe_set_tid_acc')) {
    function swe_set_tid_acc($t_acc) {
        if ((float)$t_acc == (float)SE_TIDAL_AUTOMATIC) {
            $GLOBALS['SWETEST_EXTRA_TID_ACC_AUTOMATIC'] = true;
            $GLOBALS['SWETEST_EXTRA_TID_ACC'] = -25.858;
        } else {
            $GLOBALS['SWETEST_EXTRA_TID_ACC_AUTOMATIC'] = false;
            $GLOBALS['SWETEST_EXTRA_TID_ACC'] = (float)$t_acc;
        }
    }
}

if (!function_exists('swe_set_delta_t_userdef')) {
    function swe_set_delta_t_userdef($dt) {
        if ((float)$dt == (float)SE_DELTAT_AUTOMATIC) {
            $GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] = null;
        } else {
            $GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] = (float)$dt; // days
        }
    }
}

if (!function_exists('swe_time_equ')) {
    function swe_time_equ($tjd_et, &$e, &$serr = null) {
        $serr = '';
        $t = ((float)$tjd_et - 2451545.0) / 36525.0;
        $epsilon = 23.43929111 - 0.0130041667*$t - 0.0000001639*$t*$t + 0.0000005036*$t*$t*$t;
        $l0 = swe_extra_norm360(280.46646 + 36000.76983*$t + 0.0003032*$t*$t);
        $ecc = 0.016708634 - 0.000042037*$t - 0.0000001267*$t*$t;
        $m = swe_extra_norm360(357.52911 + 35999.05029*$t - 0.0001537*$t*$t);
        $y = tan(deg2rad($epsilon) / 2.0);
        $y *= $y;
        $l0r = deg2rad($l0);
        $mr = deg2rad($m);
        $eq = $y * sin(2*$l0r) - 2*$ecc*sin($mr) + 4*$ecc*$y*sin($mr)*cos(2*$l0r)
              - 0.5*$y*$y*sin(4*$l0r) - 1.25*$ecc*$ecc*sin(2*$mr);
        $minutes = rad2deg($eq) * 4.0;
        $e = $minutes / 1440.0; // dny, LAT - LMT
        return SE_OK;
    }
}

if (!function_exists('swe_lmt_to_lat')) {
    function swe_lmt_to_lat($tjd_lmt, $geolon, &$tjd_lat, &$serr = null) {
        $e = 0.0;
        $rc = swe_time_equ((float)$tjd_lmt, $e, $serr);
        if ($rc !== SE_OK) { $tjd_lat = 0.0; return SE_ERR; }
        $tjd_lat = (float)$tjd_lmt + $e;
        return SE_OK;
    }
}

if (!function_exists('swe_lat_to_lmt')) {
    function swe_lat_to_lmt($tjd_lat, $geolon, &$tjd_lmt, &$serr = null) {
        $guess = (float)$tjd_lat;
        for ($i = 0; $i < 3; $i++) {
            $e = 0.0;
            $rc = swe_time_equ($guess, $e, $serr);
            if ($rc !== SE_OK) { $tjd_lmt = 0.0; return SE_ERR; }
            $guess = (float)$tjd_lat - $e;
        }
        $tjd_lmt = $guess;
        return SE_OK;
    }
}

/* -------------------------------------------------------------------------
 * 18.4 Initialization, setup, closing
 * ------------------------------------------------------------------------- */

if (!function_exists('swe_set_ephe_path')) {
    function swe_set_ephe_path($path) {
        $GLOBALS['SWETEST_EXTRA_EPHE_PATH'] = rtrim(str_replace('\\', '/', (string)$path), '/');
        $GLOBALS['SWETEST_EXTRA_DT_TABLE'] = null;
        $GLOBALS['SWETEST_EXTRA_LEAP_SECONDS'] = null;
    }
}

if (!function_exists('swe_set_jpl_file')) {
    function swe_set_jpl_file($fname) {
        $GLOBALS['SWETEST_EXTRA_JPL_FILE'] = (string)$fname;
    }
}

if (!function_exists('swe_close')) {
    function swe_close() {
        // Pure PHP port nema globalni nativni handle. Stav jen vynulujeme.
        $GLOBALS['SWETEST_EXTRA_JPL_FILE'] = '';
    }
}

if (!function_exists('swe_version')) {
    function swe_version(&$svers = null) {
        $v = 'swetest pure PHP helper module 0.22; Swiss Ephemeris compatible subset';
        $svers = $v;
        return $v;
    }
}

if (!function_exists('swe_get_library_path')) {
    function swe_get_library_path(&$spath = null) {
        $p = str_replace('\\', '/', __DIR__);
        $spath = $p;
        return $p;
    }
}

if (!function_exists('swe_get_current_file_data')) {
    function swe_get_current_file_data($ifno, &$tfstart = null, &$tfend = null, &$denum = null) {
        $tfstart = 0.0; $tfend = 0.0; $denum = 0;
        $names = array(
            0 => 'sepl_18.se1',
            1 => 'semo_18.se1',
            2 => 'seas_18.se1',
        );
        $ifno = (int)$ifno;
        if (!isset($names[$ifno])) return '';
        $base = isset($GLOBALS['SWETEST_EXTRA_EPHE_PATH']) ? $GLOBALS['SWETEST_EXTRA_EPHE_PATH'] : '';
        if ($base === '' && function_exists('swetest_default_ephe_dir')) $base = swetest_default_ephe_dir();
        if ($base === '') return '';
        $file = rtrim(str_replace('\\', '/', $base), '/') . '/' . $names[$ifno];
        if (!is_file($file)) return '';
        if (class_exists('SweSe1File')) {
            try {
                $f = new SweSe1File($file);
                $tfstart = $f->tfstart;
                $tfend = $f->tfend;
                $denum = $f->denum;
                if (method_exists($f, 'close')) $f->close();
                return $file;
            } catch (Exception $e) {
                return '';
            } catch (Throwable $e) {
                return '';
            }
        }
        return $file;
    }
}


/* -------------------------------------------------------------------------
 * Asteroid ephemeris file lookup, Swiss-like order
 * -------------------------------------------------------------------------
 * Swiss source behaviour (swi_gen_filename() + open fallback):
 *   asteroid <= 99999 : astN/seNNNNN.se1, then astN/seNNNNNs.se1,
 *                       then seNNNNN.se1, then seNNNNNs.se1
 *   asteroid > 99999  : astN/sNNNNNN.se1, then astN/sNNNNNNs.se1,
 *                       then sNNNNNN.se1, then sNNNNNNs.se1
 * where N = floor(MPC number / 1000).
 */

if (!function_exists('swe_asteroid_subdir')) {
    function swe_asteroid_subdir($mpc_number) {
        $n = (int)$mpc_number;
        if ($n <= 0) return '';
        return 'ast' . (string)floor($n / 1000);
    }
}

if (!function_exists('swe_asteroid_long_filename')) {
    function swe_asteroid_long_filename($mpc_number) {
        $n = (int)$mpc_number;
        if ($n <= 0) return '';
        if ($n > 99999) return sprintf('s%06d.se1', $n);
        return sprintf('se%05d.se1', $n);
    }
}

if (!function_exists('swe_asteroid_short_filename')) {
    function swe_asteroid_short_filename($mpc_number) {
        $long = swe_asteroid_long_filename($mpc_number);
        if ($long === '') return '';
        if (substr($long, -5) === 's.se1') return $long;
        return substr($long, 0, -4) . 's.se1';
    }
}

if (!function_exists('swe_asteroid_file_candidates')) {
    /**
     * Vrati relativni cesty v poradi, ve kterem je zkousi Swiss Ephemeris.
     * @return array<int,string>
     */
    function swe_asteroid_file_candidates($mpc_number) {
        $n = (int)$mpc_number;
        if ($n <= 0) return array();
        $sub = swe_asteroid_subdir($n);
        $long = swe_asteroid_long_filename($n);
        $short = swe_asteroid_short_filename($n);
        $out = array();
        if ($sub !== '') {
            $out[] = $sub . '/' . $long;
            if ($short !== $long) $out[] = $sub . '/' . $short;
        }
        $out[] = $long;
        if ($short !== $long) $out[] = $short;
        return $out;
    }
}

if (!function_exists('swe_find_asteroid_file')) {
    /**
     * Najde asteroidovy .se1 soubor podle Swiss poradi.
     * Vraci absolutni cestu, nebo prazdny string. Detaily obsahuji seznam zkousenych cest.
     * @param int $mpc_number MPC cislo asteroidu, napr. 90377 Sedna, 136199 Eris
     * @param string|null $ephe_path adresar ephemerid; null = globalni swe_set_ephe_path/default
     * @param array|null $details vystupni diagnostika
     * @return string
     */
    function swe_find_asteroid_file($mpc_number, $ephe_path = null, &$details = null) {
        $base = $ephe_path;
        if ($base === null || $base === '') {
            $base = isset($GLOBALS['SWETEST_EXTRA_EPHE_PATH']) ? $GLOBALS['SWETEST_EXTRA_EPHE_PATH'] : '';
        }
        if (($base === null || $base === '') && function_exists('swetest_default_ephe_dir')) {
            $base = swetest_default_ephe_dir();
        }
        $base = rtrim(str_replace('\\', '/', (string)$base), '/');
        $rel = swe_asteroid_file_candidates($mpc_number);
        $tried = array();
        foreach ($rel as $r) {
            $path = $base === '' ? $r : $base . '/' . $r;
            $tried[] = $path;
            if (is_file($path)) {
                $details = array('ok' => true, 'mpc' => (int)$mpc_number, 'file' => $path, 'tried' => $tried, 'relative_candidates' => $rel);
                return $path;
            }
        }
        $details = array('ok' => false, 'mpc' => (int)$mpc_number, 'file' => '', 'tried' => $tried, 'relative_candidates' => $rel);
        return '';
    }
}

/* -------------------------------------------------------------------------
 * Bridge API: nativni swe_* kompatibilni volani postavena nad swetest.php
 * ------------------------------------------------------------------------- */

if (!function_exists('swe_extra_body_char')) {
    function swe_extra_body_char($ipl) {
        static $map = array(
            SE_SUN => '0',
            SE_MOON => '1',
            SE_MERCURY => '2',
            SE_VENUS => '3',
            SE_MARS => '4',
            SE_JUPITER => '5',
            SE_SATURN => '6',
            SE_URANUS => '7',
            SE_NEPTUNE => '8',
            SE_PLUTO => '9',
            SE_MEAN_NODE => 'm',
            SE_TRUE_NODE => 't',
            SE_MEAN_APOG => 'A',
            SE_OSCU_APOG => 'B',
            SE_EARTH => 'C',
            SE_CHIRON => 'D',
            SE_PHOLUS => 'E',
            SE_CERES => 'F',
            SE_PALLAS => 'G',
            SE_JUNO => 'H',
            SE_VESTA => 'I',
            SE_SELENA => 'Z',
            SE_WALDEMATH => 'w',
        );
        $key = (int)$ipl;
        return isset($map[$key]) ? $map[$key] : null;
    }
}

if (!function_exists('swe_set_sid_mode')) {
    function swe_set_sid_mode($sid_mode, $t0 = 0.0, $ayan_t0 = 0.0) {
        $GLOBALS['SWETEST_EXTRA_SID_MODE'] = (int)$sid_mode;
        $GLOBALS['SWETEST_EXTRA_SID_T0'] = (float)$t0;
        $GLOBALS['SWETEST_EXTRA_SID_AYAN_T0'] = (float)$ayan_t0;
    }
}

if (!function_exists('swe_get_ayanamsa_ut')) {
    function swe_get_ayanamsa_ut($tjd_ut) {
        if (class_exists('SweMath') && method_exists('SweMath', 'ayanamshaLahiri') && method_exists('SweMath', 'deltaTSeconds')) {
            $jdEt = (float)$tjd_ut + SweMath::deltaTSeconds((float)$tjd_ut) / 86400.0;
            return (float)SweMath::ayanamshaLahiri($jdEt);
        }
        return 0.0;
    }
}

if (!function_exists('swe_get_ayanamsa')) {
    function swe_get_ayanamsa($tjd_et) {
        if (class_exists('SweMath') && method_exists('SweMath', 'ayanamshaLahiri')) {
            return (float)SweMath::ayanamshaLahiri((float)$tjd_et);
        }
        return 0.0;
    }
}

if (!function_exists('swe_extra_fill_xx_from_row')) {
    /**
     * @param array<string,mixed> $row
     * @param array<int,float> $xx
     */
    function swe_extra_fill_xx_from_row(array $row, $tjd_ut, $iflag, &$xx) {
        $lon = (float)($row['longitude_deg'] ?? 0.0);
        $lat = (float)($row['latitude_deg'] ?? 0.0);
        $dist = (float)($row['distance_au'] ?? 0.0);
        $slon = (float)($row['speed_deg_per_day'] ?? 0.0);
        $iflag = (int)$iflag;
        $xx = array_fill(0, 6, 0.0);

        if (($iflag & SEFLG_EQUATORIAL) !== 0) {
            $epsDeg = 23.439291111111;
            if (class_exists('SweMath') && method_exists('SweMath', 'deltaTSeconds') && method_exists('SweMath', 'nutationShort')) {
                $jdEt = (float)$tjd_ut + SweMath::deltaTSeconds((float)$tjd_ut) / 86400.0;
                $nu = SweMath::nutationShort($jdEt);
                $epsDeg = (float)(($nu['epsTrue'] ?? 0.0) * 180.0 / M_PI);
            }
            $lonR = deg2rad($lon);
            $latR = deg2rad($lat);
            $epsR = deg2rad($epsDeg);
            $x = cos($latR) * cos($lonR);
            $y = cos($latR) * sin($lonR);
            $z = sin($latR);
            $ye = $y * cos($epsR) - $z * sin($epsR);
            $ze = $y * sin($epsR) + $z * cos($epsR);
            $ra = atan2($ye, $x);
            if ($ra < 0.0) {
                $ra += 2.0 * M_PI;
            }
            $dec = atan2($ze, sqrt($x * $x + $ye * $ye));
            $xx[0] = rad2deg($ra);
            $xx[1] = rad2deg($dec);
            $xx[2] = $dist;
            $xx[3] = 0.0;
        } elseif (($iflag & SEFLG_XYZ) !== 0) {
            $lonR = deg2rad($lon);
            $latR = deg2rad($lat);
            $xx[0] = $dist * cos($latR) * cos($lonR);
            $xx[1] = $dist * cos($latR) * sin($lonR);
            $xx[2] = $dist * sin($latR);
            $xx[3] = 0.0;
        } else {
            $xx[0] = $lon;
            $xx[1] = $lat;
            $xx[2] = $dist;
            $xx[3] = $slon;
        }

        if (($iflag & SEFLG_RADIANS) !== 0) {
            $xx[0] = deg2rad((float)$xx[0]);
            $xx[1] = deg2rad((float)$xx[1]);
            $xx[3] = deg2rad((float)$xx[3]);
        }
    }
}

if (!function_exists('swe_calc_ut')) {
    function swe_calc_ut($tjd_ut, $ipl, $iflag, &$xx, &$serr = null) {
        $serr = '';
        $xx = array_fill(0, 6, 0.0);
        $iflag = (int)$iflag;
        $ipl = (int)$ipl;

        if (!function_exists('swetest_calc')) {
            $serr = 'swetest.php neni nacten (chybi swetest_calc).';
            return SE_ERR;
        }

        if ($ipl === SE_ECL_NUT) {
            if (class_exists('SweMath') && method_exists('SweMath', 'deltaTSeconds') && method_exists('SweMath', 'nutationShort')) {
                $jdEt = (float)$tjd_ut + SweMath::deltaTSeconds((float)$tjd_ut) / 86400.0;
                $nu = SweMath::nutationShort($jdEt);
                $epsTrue = (float)(($nu['epsTrue'] ?? 0.0) * 180.0 / M_PI);
                $epsMean = (float)(($nu['epsMean'] ?? 0.0) * 180.0 / M_PI);
                $dpsi = (float)(($nu['dpsi'] ?? 0.0) * 180.0 / M_PI);
                $deps = (float)(($nu['deps'] ?? 0.0) * 180.0 / M_PI);
                $xx = array($epsTrue, $epsMean, $dpsi, $deps, 0.0, 0.0);
                return $iflag;
            }
            $serr = 'ECL_NUT vyzaduje SweMath::nutationShort().';
            return SE_ERR;
        }

        if ($ipl > SE_AST_OFFSET) {
            if (!class_exists('SweSe1') || !defined('SweSe1::SE_AST_OFFSET')) {
                $serr = 'Obecne asteroidy vyzaduji SweSe1 se SE_AST_OFFSET.';
                return SE_ERR;
            }
            try {
                $swe = new SweSe1(swe_extra_ephe_path());
                $row = $swe->calcUt(
                    (float)$tjd_ut,
                    SweSe1::SE_AST_OFFSET + ($ipl - SE_AST_OFFSET),
                    ($iflag & SEFLG_SIDEREAL) !== 0,
                    ($iflag & SEFLG_TRUEPOS) !== 0,
                    ($iflag & SEFLG_NOABERR) !== 0,
                    ($iflag & SEFLG_NONUT) !== 0
                );
                $swe->close();
            } catch (Throwable $e) {
                if (isset($swe) && $swe instanceof SweSe1) {
                    $swe->close();
                }
                $serr = 'swe_calc_ut asteroid: ' . $e->getMessage();
                return SE_ERR;
            }
            swe_extra_fill_xx_from_row(array(
                'longitude_deg' => (float)$row['lon'],
                'latitude_deg' => (float)$row['lat'],
                'distance_au' => (float)$row['dist'],
                'speed_deg_per_day' => (float)$row['slon'],
            ), (float)$tjd_ut, $iflag, $xx);
            return $iflag;
        }

        $bodyChar = swe_extra_body_char($ipl);
        if ($bodyChar === null) {
            $serr = 'Nepodporovany kod telesa: ' . $ipl;
            return SE_ERR;
        }

        $query = '-bj' . sprintf('%.10f', (float)$tjd_ut) . ' -p' . $bodyChar;
        if (($iflag & SEFLG_SIDEREAL) !== 0) {
            $query .= ' -sid1';
        }
        if (($iflag & SEFLG_TRUEPOS) !== 0) {
            $query .= ' -true';
        }
        if (($iflag & SEFLG_NOABERR) !== 0) {
            $query .= ' -noaberr';
        }
        if (($iflag & SEFLG_NONUT) !== 0) {
            $query .= ' -nonut';
        }

        try {
            $rows = swetest_calc($query, swe_extra_ephe_path());
        } catch (Throwable $e) {
            $serr = 'swe_calc_ut bridge: ' . $e->getMessage();
            return SE_ERR;
        }
        if (!is_array($rows) || count($rows) < 1 || !is_array($rows[0])) {
            $serr = 'swe_calc_ut bridge: swetest nevratil data.';
            return SE_ERR;
        }

        swe_extra_fill_xx_from_row($rows[0], (float)$tjd_ut, $iflag, $xx);
        return $iflag;
    }
}

if (!function_exists('swe_calc')) {
    function swe_calc($tjd_et, $ipl, $iflag, &$xx, &$serr = null) {
        $dt = swe_deltat_ex((float)$tjd_et, (int)$iflag, $serr);
        $tjd_ut = (float)$tjd_et - (float)$dt;
        return swe_calc_ut($tjd_ut, $ipl, $iflag, $xx, $serr);
    }
}


/* -----------------------------------------------------------------------------
 * Optional house module moved out of swetest.php core.
 * ----------------------------------------------------------------------------- */

/**
 * Minimal pure-PHP house module modelled after Swiss Ephemeris swehouse.c
 * for the house systems most useful in astrology charts.
 *
 * Implemented systems:
 *   P = Placidus (Porphyry fallback near polar circle)
 *   K = Koch (Porphyry fallback near polar circle)
 *   R = Regiomontanus
 *   W = Whole sign
 *   E/A = Equal houses from Ascendant
 *   O = Porphyry
 *   N = Aries = 1st house
 */
final class SweHouses
{
    private const VERY_SMALL = 1.0e-10;
    private const VERY_SMALL_PLAC_ITER = 1.0 / 360000.0;

    private static function d2r(float $x): float { return $x * SweMath::DEG2RAD; }
    private static function r2d(float $x): float { return $x * SweMath::RAD2DEG; }
    private static function sind(float $x): float { return sin(self::d2r($x)); }
    private static function cosd(float $x): float { return cos(self::d2r($x)); }
    private static function tand(float $x): float { return tan(self::d2r($x)); }
    private static function asind(float $x): float { return self::r2d(asin(max(-1.0, min(1.0, $x)))); }
    private static function atand(float $x): float { return self::r2d(atan($x)); }
    private static function difdeg2n(float $a, float $b): float { return SweMath::norm180($a - $b); }

    public static function houseName(string $hsys): string
    {
        $h = strtoupper($hsys !== '' ? $hsys[0] : 'P');
        switch ($h) {
            case 'A':
            case 'E':
                return 'Equal';
            case 'K':
                return 'Koch';
            case 'N':
                return 'Aries = 1st house';
            case 'O':
                return 'Porphyry';
            case 'R':
                return 'Regiomontanus';
            case 'W':
                return 'Whole sign';
            default:
                return 'Placidus';
        }
    }

    /**
     * Greenwich sidereal time in degrees. Port of Swiss swe_sidtime() /
     * swe_sidtime0() with the default model SEMOD_SIDT_LONGTERM.
     * $apparent=false returns mean sidereal time (nut = 0), like
     * swe_sidtime0(tjd, eps, 0).
     */
    public static function siderealTimeDeg(float $jdUt, bool $apparent = true): float
    {
        $jdEt = $jdUt + SweMath::deltaTSeconds($jdUt) / 86400.0;
        $nu = SweMath::nutationShort($jdEt);
        $epsDeg = $nu['epsTrue'] * SweMath::RAD2DEG;
        $nutDeg = $apparent ? $nu['dpsi'] * SweMath::RAD2DEG : 0.0;
        return SweMath::norm360(self::sidtime0Hours($jdUt, $epsDeg, $nutDeg) * 15.0);
    }

    /** swe_sidtime0() with SEMOD_SIDT_LONGTERM; returns hours 0..24. */
    private static function sidtime0Hours(float $tjd, float $epsDeg, float $nutDeg): float
    {
        // sidtime_long_term() is not used between 1 Jan 1850 and 1 Jan 2050.
        if ($tjd <= 2396758.5 || $tjd >= 2469807.5) {
            $gmst = self::sidtimeLongTermHours($tjd, $epsDeg, $nutDeg);
            if ($tjd <= 2396758.5) {
                $gmst -= 0.000378172 / 15.0;
            } else {
                $gmst -= 0.001385646 / 15.0;
            }
            if ($gmst >= 24.0) $gmst -= 24.0;
            if ($gmst < 0.0) $gmst += 24.0;
            return $gmst;
        }
        // ERA-based expression for GST, IAU 2006 precession (IERS Conv. 2010).
        $jdrel = $tjd - 2451545.0;
        $tt = ($tjd + SweMath::deltaTSeconds($tjd) / 86400.0 - 2451545.0) / 36525.0;
        $gmst = SweMath::norm360((0.7790572732640 + 1.00273781191135448 * $jdrel) * 360.0);
        $gmst += (0.014506 + $tt * (4612.156534 + $tt * (1.3915817 + $tt * (-0.00000044 + $tt * (-0.000029956 + $tt * -0.0000000368))))) / 3600.0;
        $gmst = SweMath::norm360($gmst + self::sidtimeNonPolynomialPart($tt));
        $gmst = $gmst / 15.0 * 3600.0;
        // equation of the equinoxes
        $gmst += 240.0 * $nutDeg * cos($epsDeg * SweMath::DEG2RAD);
        $gmst -= 86400.0 * floor($gmst / 86400.0);
        return $gmst / 3600.0;
    }

    /** Port of sidtime_non_polynomial_part(); tt = TT centuries, returns degrees. */
    private static function sidtimeNonPolynomialPart(float $tt): float
    {
        static $stcf = [
            2640.96, -0.39, 63.52, -0.02, 11.75, 0.01, 11.21, 0.01, -4.55, 0.00,
            2.02, 0.00, 1.98, 0.00, -1.72, 0.00, -1.41, -0.01, -1.26, -0.01,
            -0.63, 0.00, -0.63, 0.00, 0.46, 0.00, 0.45, 0.00, 0.36, 0.00,
            -0.24, -0.12, 0.32, 0.00, 0.28, 0.00, 0.27, 0.00, 0.26, 0.00,
            -0.21, 0.00, 0.19, 0.00, 0.18, 0.00, -0.10, 0.05, 0.15, 0.00,
            -0.14, 0.00, 0.14, 0.00, -0.14, 0.00, 0.14, 0.00, 0.13, 0.00,
            -0.11, 0.00, 0.11, 0.00, 0.11, 0.00,
        ];
        static $stfarg = [
            0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, -2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, -2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, -2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, 2, -2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, 2, -2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 4, -4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 1, -1, 1, 0, -8, 12, 0, 0, 0, 0, 0, 0,
            0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 2, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, -2, 2, -3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, -2, 2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 8, -13, 0, 0, 0, 0, 0, -1,
            0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            2, 0, -2, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 0, -2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 1, 2, -2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, 0, -2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 4, -2, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 2, -2, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, -2, 0, -3, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 0, -2, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        ];
        $radnorm = static function (float $x): float {
            $r = fmod($x, 2.0 * M_PI);
            return $r < 0.0 ? $r + 2.0 * M_PI : $r;
        };
        $delm = [
            $radnorm(2.35555598 + 8328.6914269554 * $tt),
            $radnorm(6.24006013 + 628.301955 * $tt),
            $radnorm(1.627905234 + 8433.466158131 * $tt),
            $radnorm(5.198466741 + 7771.3771468121 * $tt),
            $radnorm(2.18243920 - 33.757045 * $tt),
            $radnorm(4.402608842 + 2608.7903141574 * $tt),
            $radnorm(3.176146697 + 1021.3285546211 * $tt),
            $radnorm(1.753470314 + 628.3075849991 * $tt),
            $radnorm(6.203480913 + 334.0612426700 * $tt),
            $radnorm(0.599546497 + 52.9690962641 * $tt),
            $radnorm(0.874016757 + 21.3299104960 * $tt),
            $radnorm(5.481293871 + 7.4781598567 * $tt),
            $radnorm(5.321159000 + 3.8127774000 * $tt),
            (0.02438175 + 0.00000538691 * $tt) * $tt,
        ];
        $dadd = -0.87 * sin($delm[4]) * $tt;
        for ($i = 0; $i < 33; $i++) {
            $darg = 0.0;
            for ($j = 0; $j < 14; $j++) {
                $darg += $stfarg[$i * 14 + $j] * $delm[$j];
            }
            $dadd += $stcf[$i * 2] * sin($darg) + $stcf[$i * 2 + 1] * cos($darg);
        }
        return $dadd / (3600.0 * 1000000.0);
    }

    /** Port of sidtime_long_term(); returns hours. */
    private static function sidtimeLongTermHours(float $tjdUt, float $epsDeg, float $nutDeg): float
    {
        $dlt = SweMath::AUNIT_M / SweMath::CLIGHT_M_S / 86400.0;
        $tjdEt = $tjdUt + SweMath::deltaTSeconds($tjdUt) / 86400.0;
        $t = ($tjdEt - 2451545.0) / 365250.0;
        $t2 = $t * $t;
        $t3 = $t * $t2;
        /* mean longitude of earth J2000 */
        $dlon = 100.46645683 + (1295977422.83429 * $t - 2.04411 * $t2 - 0.00523 * $t3) / 3600.0;
        /* light time sun-earth */
        $dlon = SweMath::norm360($dlon - $dlt * 360.0 / 365.2425);
        $xs = [cos($dlon * SweMath::DEG2RAD), sin($dlon * SweMath::DEG2RAD), 0.0];
        /* to mean equator J2000, cartesian */
        $epsJ2000 = SweMath::meanObliquityDeg(2451545.0 + SweMath::deltaTSeconds(2451545.0) / 86400.0) * SweMath::DEG2RAD;
        $y = $xs[1] * cos($epsJ2000) - $xs[2] * sin($epsJ2000);
        $z = $xs[1] * sin($epsJ2000) + $xs[2] * cos($epsJ2000);
        $xs[1] = $y;
        $xs[2] = $z;
        /* precess to mean equinox of date */
        $xs = SweMath::precessJ2000ToDate([$xs[0], $xs[1], $xs[2], 0.0, 0.0, 0.0], $tjdEt);
        /* to mean ecliptic of date */
        $epsDateDeg = SweMath::meanObliquityDeg($tjdEt);
        $nu = SweMath::nutationShort($tjdEt);
        $epsTrueDateDeg = $epsDateDeg + $nu['deps'] * SweMath::RAD2DEG;
        $dpsiDateDeg = $nu['dpsi'] * SweMath::RAD2DEG;
        $e = $epsDateDeg * SweMath::DEG2RAD;
        $y = $xs[1] * cos($e) + $xs[2] * sin($e);
        $z = -$xs[1] * sin($e) + $xs[2] * cos($e);
        $lon = atan2($y, $xs[0]) * SweMath::RAD2DEG;
        $dhour = fmod($tjdUt - 0.5, 1.0) * 360.0;
        /* mean to true (if nut != 0) */
        if ($epsDeg == 0.0) {
            $lon += $dpsiDateDeg * cos($epsTrueDateDeg * SweMath::DEG2RAD);
        } else {
            $lon += $nutDeg * cos($epsDeg * SweMath::DEG2RAD);
        }
        $lon = SweMath::norm360($lon + $dhour);
        return $lon / 15.0;
    }

    private static function asc2(float $x, float $f, float $sine, float $cose): float
    {
        $ass = -self::tand($f) * $sine + $cose * self::cosd($x);
        if (abs($ass) < self::VERY_SMALL) $ass = 0.0;
        $sinx = self::sind($x);
        if (abs($sinx) < self::VERY_SMALL) $sinx = 0.0;
        if ($sinx == 0.0) {
            $ass = ($ass < 0.0) ? -self::VERY_SMALL : self::VERY_SMALL;
        } elseif ($ass == 0.0) {
            $ass = ($sinx < 0.0) ? -90.0 : 90.0;
        } else {
            $ass = self::atand($sinx / $ass);
        }
        if ($ass < 0.0) $ass = 180.0 + $ass;
        return $ass;
    }

    private static function asc1(float $x1, float $f, float $sine, float $cose): float
    {
        $x1 = SweMath::norm360($x1);
        $n = (int)(($x1 / 90.0) + 1.0);
        if (abs(90.0 - $f) < self::VERY_SMALL) return 180.0;
        if (abs(90.0 + $f) < self::VERY_SMALL) return 0.0;
        if ($n === 1) {
            $ass = self::asc2($x1, $f, $sine, $cose);
        } elseif ($n === 2) {
            $ass = 180.0 - self::asc2(180.0 - $x1, -$f, $sine, $cose);
        } elseif ($n === 3) {
            $ass = 180.0 + self::asc2($x1 - 180.0, -$f, $sine, $cose);
        } else {
            $ass = 360.0 - self::asc2(360.0 - $x1, $f, $sine, $cose);
        }
        $ass = SweMath::norm360($ass);
        foreach ([90.0, 180.0, 270.0, 360.0] as $snap) {
            if (abs($ass - $snap) < self::VERY_SMALL) $ass = ($snap >= 360.0 ? 0.0 : $snap);
        }
        return $ass;
    }

    private static function armcToMc(float $armc, float $eps): float
    {
        $cose = self::cosd($eps);
        if (abs($armc - 90.0) > self::VERY_SMALL && abs($armc - 270.0) > self::VERY_SMALL) {
            $mc = self::atand(self::tand($armc) / $cose);
            if ($armc > 90.0 && $armc <= 270.0) $mc = SweMath::norm360($mc + 180.0);
            return SweMath::norm360($mc);
        }
        return abs($armc - 90.0) <= self::VERY_SMALL ? 90.0 : 270.0;
    }

    /** @return array<int,float> */
    private static function opposites(array $c): array
    {
        $c[4] = SweMath::norm360($c[10] + 180.0);
        $c[5] = SweMath::norm360($c[11] + 180.0);
        $c[6] = SweMath::norm360($c[12] + 180.0);
        $c[7] = SweMath::norm360($c[1] + 180.0);
        $c[8] = SweMath::norm360($c[2] + 180.0);
        $c[9] = SweMath::norm360($c[3] + 180.0);
        ksort($c);
        return $c;
    }

    /** @return array<int,float> */
    private static function porphyry(float $ac, float $mc): array
    {
        $c = array_fill(0, 13, 0.0);
        $acmc = self::difdeg2n($ac, $mc);
        if ($acmc < 0.0) {
            $ac = SweMath::norm360($ac + 180.0);
            $acmc = self::difdeg2n($ac, $mc);
        }
        $c[1] = $ac;
        $c[10] = $mc;
        $c[2] = SweMath::norm360($ac + (180.0 - $acmc) / 3.0);
        $c[3] = SweMath::norm360($ac + (180.0 - $acmc) * 2.0 / 3.0);
        $c[11] = SweMath::norm360($mc + $acmc / 3.0);
        $c[12] = SweMath::norm360($mc + $acmc * 2.0 / 3.0);
        return self::opposites($c);
    }

    /**
     * @return array{jd_ut:float,geo_longitude:float,geo_latitude:float,house_system:string,house_system_name:string,armc:float,eps:float,asc:float,mc:float,cusps:array<int,float>,ascmc:array<string,float>,warning:?string,mode:string}
     */
    public static function calcUt(float $jdUt, float $geoLon, float $geoLat, string $hsys = 'P', bool $sidereal = false): array
    {
        $jdEt = $jdUt + SweMath::deltaTSeconds($jdUt) / 86400.0;
        $nu = SweMath::nutationShort($jdEt);
        $eps = $nu['epsTrue'] * SweMath::RAD2DEG;
        $armc = SweMath::norm360(self::siderealTimeDeg($jdUt, true) + $geoLon);
        $r = self::calcArmc($armc, $geoLat, $eps, $hsys);
        if ($sidereal) {
            // Sidereal houses intentionally use traditional Lahiri subtraction.
            // This matches the practical Vedic mode we need here; it is not the
            // full Swiss sidereal_houses_ecl_t0 / ssypl coordinate-axis variant.
            $ayan = SweMath::ayanamshaLahiri($jdEt);
            foreach ($r['cusps'] as $i => $v) $r['cusps'][$i] = SweMath::norm360($v - $ayan);
            $r['asc'] = SweMath::norm360($r['asc'] - $ayan);
            $r['mc'] = SweMath::norm360($r['mc'] - $ayan);
            foreach ($r['ascmc'] as $k => $v) if ($k !== 'armc') $r['ascmc'][$k] = SweMath::norm360($v - $ayan);
            // Whole sign domy ve sidereal modu: zacatek 1. domu musi byt
            // zacatek znameni sidereal Ascendentu (ne tropicky start pak posun).
            if (strtoupper($hsys !== '' ? $hsys[0] : 'P') === 'W') {
                $base = floor($r['asc'] / 30.0) * 30.0;
                for ($i = 1; $i <= 12; $i++) {
                    $r['cusps'][$i] = SweMath::norm360($base + ($i - 1) * 30.0);
                }
            }
        }
        return [
            'jd_ut' => $jdUt,
            'geo_longitude' => $geoLon,
            'geo_latitude' => $geoLat,
            'house_system' => strtoupper($hsys !== '' ? $hsys[0] : 'P'),
            'house_system_name' => self::houseName($hsys),
            'armc' => $armc,
            'eps' => $eps,
            'asc' => $r['asc'],
            'mc' => $r['mc'],
            'cusps' => $r['cusps'],
            'ascmc' => $r['ascmc'],
            'warning' => $r['warning'],
            'mode' => $sidereal ? 'sidereal_lahiri' : 'tropical',
        ];
    }

    /** @return array{asc:float,mc:float,cusps:array<int,float>,ascmc:array<string,float>,warning:?string} */
    private static function calcArmc(float $armc, float $lat, float $eps, string $hsys): array
    {
        $h = strtoupper($hsys !== '' ? $hsys[0] : 'P');
        $warning = null;
        if (abs(abs($lat) - 90.0) < self::VERY_SMALL) $lat = $lat < 0 ? -90.0 + self::VERY_SMALL : 90.0 - self::VERY_SMALL;
        $sine = self::sind($eps);
        $cose = self::cosd($eps);
        $tane = self::tand($eps);
        $tanfi = self::tand($lat);
        $mc = self::armcToMc($armc, $eps);
        $ac = self::asc1($armc + 90.0, $lat, $sine, $cose);
        $c = array_fill(0, 13, 0.0);
        $c[1] = $ac;
        $c[10] = $mc;

        if ($h === 'A' || $h === 'E') {
            $acmc = self::difdeg2n($ac, $mc);
            if ($acmc < 0.0) $ac = SweMath::norm360($ac + 180.0);
            $c[1] = $ac;
            for ($i = 2; $i <= 12; $i++) $c[$i] = SweMath::norm360($c[1] + ($i - 1) * 30.0);
        } elseif ($h === 'W') {
            $acmc = self::difdeg2n($ac, $mc);
            if ($acmc < 0.0) $ac = SweMath::norm360($ac + 180.0);
            $c[1] = floor($ac / 30.0) * 30.0;
            for ($i = 2; $i <= 12; $i++) $c[$i] = SweMath::norm360($c[1] + ($i - 1) * 30.0);
        } elseif ($h === 'N') {
            // C: within polar circle swap AC if it is on the wrong side.
            $acmc = self::difdeg2n($ac, $mc);
            if ($acmc < 0.0) $ac = SweMath::norm360($ac + 180.0);
            for ($i = 1; $i <= 12; $i++) $c[$i] = ($i - 1) * 30.0;
        } elseif ($h === 'O') {
            $c = self::porphyry($ac, $mc);
            $ac = $c[1]; // porphyry() may have flipped AC within polar circle
        } elseif ($h === 'K') {
            if (abs($lat) >= 90.0 - $eps) {
                $warning = 'Koch: polarni oblast, fallback Porphyry';
                $c = self::porphyry($ac, $mc);
                $ac = $c[1];
            } else {
                $sina = self::sind($mc) * $sine / max(self::cosd($lat), 1e-15);
                $sina = max(-1.0, min(1.0, $sina));
                $cosa = sqrt(max(0.0, 1.0 - $sina * $sina));
                $cc = self::atand($tanfi / max($cosa, 1e-15));
                $ad3 = self::asind(self::sind($cc) * $sina) / 3.0;
                $c[11] = self::asc1($armc + 30.0 - 2.0 * $ad3, $lat, $sine, $cose);
                $c[12] = self::asc1($armc + 60.0 - $ad3, $lat, $sine, $cose);
                $c[2] = self::asc1($armc + 120.0 + $ad3, $lat, $sine, $cose);
                $c[3] = self::asc1($armc + 150.0 + 2.0 * $ad3, $lat, $sine, $cose);
                $c = self::opposites($c);
            }
        } elseif ($h === 'R') {
            $fh1 = self::atand($tanfi * 0.5);
            $fh2 = self::atand($tanfi * self::cosd(30.0));
            $c[11] = self::asc1(30.0 + $armc, $fh1, $sine, $cose);
            $c[12] = self::asc1(60.0 + $armc, $fh2, $sine, $cose);
            $c[2] = self::asc1(120.0 + $armc, $fh2, $sine, $cose);
            $c[3] = self::asc1(150.0 + $armc, $fh1, $sine, $cose);
            if (abs($lat) >= 90.0 - $eps && self::difdeg2n($ac, $mc) < 0.0) {
                $ac = SweMath::norm360($ac + 180.0);
                $mc = SweMath::norm360($mc + 180.0);
                for ($i = 1; $i <= 12; $i++) if (!($i >= 4 && $i < 10)) $c[$i] = SweMath::norm360($c[$i] + 180.0);
            }
            $c = self::opposites($c);
        } else { // P = Placidus default
            if (abs($lat) >= 90.0 - $eps) {
                $warning = 'Placidus: polarni oblast, fallback Porphyry';
                $c = self::porphyry($ac, $mc);
                $ac = $c[1];
            } else {
                $a = self::asind($tanfi * $tane);
                $fh1 = self::atand(self::sind($a / 3.0) / $tane);
                $fh2 = self::atand(self::sind($a * 2.0 / 3.0) / $tane);
                $ok = true;
                $ok = self::placidusCusp($c, 11, SweMath::norm360(30.0 + $armc), $fh1, 3.0, $tanfi, $sine, $cose) && $ok;
                $ok = self::placidusCusp($c, 12, SweMath::norm360(60.0 + $armc), $fh2, 1.5, $tanfi, $sine, $cose) && $ok;
                $ok = self::placidusCusp($c, 2, SweMath::norm360(120.0 + $armc), $fh2, 1.5, $tanfi, $sine, $cose) && $ok;
                $ok = self::placidusCusp($c, 3, SweMath::norm360(150.0 + $armc), $fh1, 3.0, $tanfi, $sine, $cose) && $ok;
                if ($ok) {
                    $c = self::opposites($c);
                } else {
                    $warning = 'Placidus: iterace selhala, fallback Porphyry';
                    $c = self::porphyry($ac, $mc);
                    $ac = $c[1];
                }
            }
        }

        $vertexF = $lat >= 0.0 ? 90.0 - $lat : -90.0 - $lat;
        $vertex = self::asc1($armc - 90.0, $vertexF, $sine, $cose);
        if (abs($lat) <= $eps && self::difdeg2n($vertex, $mc) > 0.0) $vertex = SweMath::norm360($vertex + 180.0);
        $equasc = self::armcToMc(SweMath::norm360($armc + 90.0), $eps);
        $coasc1 = SweMath::norm360(self::asc1($armc - 90.0, $lat, $sine, $cose) + 180.0);
        $coasc2 = $lat >= 0.0 ? self::asc1($armc + 90.0, 90.0 - $lat, $sine, $cose) : self::asc1($armc + 90.0, -90.0 - $lat, $sine, $cose);
        $polasc = self::asc1($armc - 90.0, $lat, $sine, $cose);

        return [
            'asc' => $ac,
            'mc' => $mc,
            'cusps' => $c,
            'ascmc' => ['asc'=>$ac, 'mc'=>$mc, 'armc'=>$armc, 'vertex'=>$vertex, 'equasc'=>$equasc, 'coasc1'=>$coasc1, 'coasc2'=>$coasc2, 'polasc'=>$polasc],
            'warning' => $warning,
        ];
    }

    /** @param array<int,float> $c */
    private static function placidusCusp(array &$c, int $ih, float $rectasc, float $fh, float $divisor, float $tanfi, float $sine, float $cose): bool
    {
        $tant = self::tand(self::asind($sine * self::sind(self::asc1($rectasc, $fh, $sine, $cose))));
        if (abs($tant) < self::VERY_SMALL) {
            $c[$ih] = $rectasc;
            return true;
        }
        $f = self::atand(self::sind(self::asind($tanfi * $tant) / $divisor) / $tant);
        $c[$ih] = self::asc1($rectasc, $f, $sine, $cose);
        $prev = 0.0;
        for ($i = 1; $i <= 100; $i++) {
            $tant = self::tand(self::asind($sine * self::sind($c[$ih])));
            if (abs($tant) < self::VERY_SMALL) {
                $c[$ih] = $rectasc;
                return true;
            }
            $f = self::atand(self::sind(self::asind($tanfi * $tant) / $divisor) / $tant);
            $c[$ih] = self::asc1($rectasc, $f, $sine, $cose);
            if ($i > 1 && abs(self::difdeg2n($c[$ih], $prev)) < self::VERY_SMALL_PLAC_ITER) return true;
            $prev = $c[$ih];
        }
        return false;
    }

    /**
     * Vrati pozici v domu 1.0..12.999. Pro Placidus pouziva rovnikove souradnice
     * a diurnalni oblouky; ostatni systemy ponechavaji ekliptikalni interpolaci.
     *
     * @param array<int,float> $cusps
     */
    public static function housePosition(float $lon, float $lat, float $armc, float $geolat, float $eps, array $cusps, string $hsys = 'P'): float
    {
        $hsys = strtoupper($hsys !== '' ? $hsys[0] : 'P');
        $lon = SweMath::norm360($lon);

        if ($hsys === 'P') {
            $epsRad = self::d2r($eps);
            $lonRad = self::d2r($lon);
            $latRad = self::d2r($lat);

            $x = cos($latRad) * cos($lonRad);
            $y = cos($latRad) * sin($lonRad);
            $z = sin($latRad);

            // Ecliptic -> equatorial of date.
            $xeq = $x;
            $yeq = $y * cos($epsRad) - $z * sin($epsRad);
            $zeq = $y * sin($epsRad) + $z * cos($epsRad);

            $ra = SweMath::norm360(atan2($yeq, $xeq) * SweMath::RAD2DEG);
            $de = atan2($zeq, hypot($xeq, $yeq)) * SweMath::RAD2DEG;

            $mdd = SweMath::norm360($ra - $armc);
            $mdn = SweMath::norm360($mdd + 180.0);
            if ($mdd >= 180.0) $mdd -= 360.0;
            if ($mdn >= 180.0) $mdn -= 360.0;

            if (90.0 - abs($de) <= abs($geolat)) {
                // Otto Ludwig style fallback in circumpolar cases.
                if ($de * $geolat < 0.0) {
                    $xp = SweMath::norm360(90.0 + $mdn / 2.0);
                } else {
                    $xp = SweMath::norm360(270.0 + $mdd / 2.0);
                }
            } else {
                $sinad = self::tand($de) * self::tand($geolat);
                $sinad = max(-1.0, min(1.0, $sinad));
                $ad = self::asind($sinad);
                $isAboveHorizon = ($sinad + self::cosd($mdd)) >= 0.0;

                if ($isAboveHorizon) {
                    $xp = ($mdd / (90.0 + $ad) + 3.0) * 90.0;
                } else {
                    $xp = ($mdn / (90.0 - $ad) + 1.0) * 90.0;
                }
                $xp = SweMath::norm360($xp);
            }

            return $xp / 30.0 + 1.0;
        }

        for ($i = 1; $i <= 12; $i++) {
            $a = SweMath::norm360((float)$cusps[$i]);
            $b = SweMath::norm360((float)$cusps[$i === 12 ? 1 : $i + 1]);
            $width = SweMath::norm360($b - $a);
            if ($width <= 0.0) $width += 360.0;
            $d = SweMath::norm360($lon - $a);
            if ($d < $width || abs($d - $width) < 1e-9) {
                return $i + ($d / $width);
            }
        }
        return 0.0;
    }
}

if (!function_exists('swetest_split_args')) {
    function swetest_split_args(string $q): array
    {
        $q = trim($q);
        if ($q === '') return [];
        if (function_exists('str_getcsv')) {
            $parts = str_getcsv($q, ' ', '"', '\\');
            return array_values(array_filter(array_map('trim', $parts), static fn($v) => $v !== ''));
        }
        return preg_split('/\s+/', $q) ?: [];
    }
}


if (!function_exists('swetest_parse_house_option')) {
    /**
     * Nacte -houseLONG,LAT,SYSTEM z argumentu stejneho stylu jako swetest.c.
     * Priklad: -house14.42,50.08,P
     *
     * @param string[] $args
     * @return array{longitude:float,latitude:float,system:string}|null
     */
    function swetest_parse_house_option(array $args): ?array
    {
        for ($i = 0; $i < count($args); $i++) {
            $a = (string)$args[$i];
            if ($a === '-house') {
                $spec = (string)($args[$i + 1] ?? '');
            } elseif (swetest_starts_with($a, '-house')) {
                $spec = substr($a, 6);
            } else {
                continue;
            }
            $spec = trim($spec);
            if ($spec === '') return null;
            $p = array_map('trim', explode(',', $spec));
            if (count($p) < 2) throw new InvalidArgumentException('Spatne -house, pouzij napr. -house14.42,50.08,P');
            return [
                'longitude' => (float)$p[0],
                'latitude' => (float)$p[1],
                'system' => strtoupper((string)($p[2] ?? 'P')) ?: 'P',
            ];
        }
        return null;
    }
}

if (!function_exists('swetest_houses')) {
    /**
     * Vrati ASC/MC a 12 domu.
     *
     * @param array<string,mixed>|string $input napr. "-b24.1.1963 -ut02:06 -house14.42,50.08,P"
     * @return array<string,mixed>
     */
    function swetest_houses($input = [], ?string $edir = null): array
    {
        $args = swetest_build_args($input, $edir);
        $opts = SweAstroLongitudeCli::parseArgs($args);

        $house = swetest_parse_house_option($args);
        if ($house === null && is_array($input)) {
            if (isset($input['house'])) {
                if (is_string($input['house'])) {
                    $house = swetest_parse_house_option(['-house' . $input['house']]);
                } elseif (is_array($input['house'])) {
                    $house = [
                        'longitude' => (float)($input['house']['longitude'] ?? $input['house']['lon'] ?? 0.0),
                        'latitude' => (float)($input['house']['latitude'] ?? $input['house']['lat'] ?? 0.0),
                        'system' => strtoupper((string)($input['house']['system'] ?? $input['house']['hsys'] ?? 'P')),
                    ];
                }
            } elseif (isset($input['longitude'], $input['latitude'])) {
                $house = [
                    'longitude' => (float)$input['longitude'],
                    'latitude' => (float)$input['latitude'],
                    'system' => strtoupper((string)($input['house_system'] ?? $input['hsys'] ?? 'P')),
                ];
            }
        }
        if ($house === null) {
            throw new InvalidArgumentException('Chybi -houseLONG,LAT,SYSTEM, napr. -house14.42,50.08,P');
        }

        $h = SweHouses::calcUt(
            (float)$opts['jd'],
            (float)$house['longitude'],
            (float)$house['latitude'],
            (string)$house['system'],
            (bool)$opts['sidereal']
        );

        $h['cusps_zodiac'] = [];
        foreach ($h['cusps'] as $i => $lon) {
            if ($i < 1 || $i > 12) continue;
            $h['cusps_zodiac'][$i] = swetest_zodiac_parts((float)$lon);
        }
        $h['asc_zodiac'] = swetest_zodiac_parts((float)$h['asc']);
        $h['mc_zodiac'] = swetest_zodiac_parts((float)$h['mc']);
        return $h;
    }
}


if (!function_exists('swetest_houses_text')) {
    /**
     * @param array<string,mixed>|string $input
     */
    function swetest_houses_text($input = [], ?string $edir = null): string
    {
        $h = swetest_houses($input, $edir);
        $lines = [];
        $lines[] = 'House system: ' . $h['house_system'] . ' / ' . $h['house_system_name'] . '  mode=' . $h['mode'];
        $lines[] = 'Geo: lon=' . sprintf('%+.6f', (float)$h['geo_longitude']) . ' lat=' . sprintf('%+.6f', (float)$h['geo_latitude']);
        $lines[] = 'ASC: ' . $h['asc_zodiac']['position_cz'] . '  lon=' . sprintf('%.10f', (float)$h['asc']);
        $lines[] = 'MC : ' . $h['mc_zodiac']['position_cz'] . '  lon=' . sprintf('%.10f', (float)$h['mc']);
        $lines[] = 'ARMC=' . sprintf('%.10f', (float)$h['armc']) . '  eps=' . sprintf('%.10f', (float)$h['eps']);
        if (!empty($h['warning'])) $lines[] = 'WARNING: ' . $h['warning'];
        for ($i = 1; $i <= 12; $i++) {
            $z = $h['cusps_zodiac'][$i];
            $lines[] = sprintf('house %2d       %s  lon=%.10f', $i, $z['position_cz'], (float)$h['cusps'][$i]);
        }
        return implode(PHP_EOL, $lines);
    }
}

if (!function_exists('swe_houses_ex')) {
    function swe_houses_ex($tjd_ut, $iflag, $geolat, $geolon, $hsys, &$cusps, &$ascmc) {
        if (!function_exists('swetest_houses')) {
            return SE_ERR;
        }
        $iflag = (int)$iflag;
        $hs = strtoupper(substr((string)$hsys, 0, 1));
        if ($hs === '') {
            $hs = 'P';
        }
        $query = '-bj' . sprintf('%.10f', (float)$tjd_ut)
            . ' -house' . sprintf('%.8f', (float)$geolon) . ',' . sprintf('%.8f', (float)$geolat) . ',' . $hs;
        if (($iflag & SEFLG_SIDEREAL) !== 0) {
            $query .= ' -sid1';
        }
        try {
            $h = swetest_houses($query, swe_extra_ephe_path());
        } catch (Throwable $e) {
            return SE_ERR;
        }
        if (!is_array($h) || !isset($h['cusps']) || !is_array($h['cusps'])) {
            return SE_ERR;
        }
        $cusps = array_fill(0, 13, 0.0);
        for ($i = 1; $i <= 12; $i++) {
            $cusps[$i] = (float)($h['cusps'][$i] ?? 0.0);
        }
        $a = is_array($h['ascmc'] ?? null) ? $h['ascmc'] : array();
        $ascmc = array_fill(0, 10, 0.0);
        $ascmc[0] = (float)($h['asc'] ?? 0.0);
        $ascmc[1] = (float)($h['mc'] ?? 0.0);
        $ascmc[2] = (float)($h['armc'] ?? 0.0);
        $ascmc[3] = (float)($a['vertex'] ?? 0.0);
        $ascmc[4] = (float)($a['equasc'] ?? 0.0);
        $ascmc[5] = (float)($a['coasc1'] ?? 0.0);
        $ascmc[6] = (float)($a['coasc2'] ?? 0.0);
        $ascmc[7] = (float)($a['polasc'] ?? 0.0);
        $ascmc[8] = 0.0;
        $ascmc[9] = 0.0;
        return SE_OK;
    }
}

if (!function_exists('swe_houses')) {
    function swe_houses($tjd_ut, $geolat, $geolon, $hsys, &$cusps, &$ascmc) {
        return swe_houses_ex($tjd_ut, 0, $geolat, $geolon, $hsys, $cusps, $ascmc);
    }
}

if (!function_exists('swe_houses_ex2')) {
    function swe_houses_ex2($tjd_ut, $iflag, $geolat, $geolon, $hsys, &$cusps, &$ascmc, &$cusp_speed = null, &$ascmc_speed = null, &$serr = null) {
        $serr = '';
        $rc = swe_houses_ex($tjd_ut, $iflag, $geolat, $geolon, $hsys, $cusps, $ascmc);
        if ($rc !== SE_OK) {
            $serr = 'swe_houses_ex2 bridge selhal.';
            return SE_ERR;
        }
        $cusp_speed = array_fill(0, 13, 0.0);
        $ascmc_speed = array_fill(0, 10, 0.0);
        return SE_OK;
    }
}

if (!function_exists('swe_houses_armc')) {
    function swe_houses_armc($armc, $geolat, $eps, $hsys, &$cusps, &$ascmc) {
        // V pure PHP bridge zatim nepocitame domy primo z ARMC.
        $cusps = array_fill(0, 13, 0.0);
        $ascmc = array_fill(0, 10, 0.0);
        return SE_ERR;
    }
}

if (!function_exists('swe_house_pos')) {
    function swe_house_pos($armc, $geolat, $eps, $hsys, $xpin, &$serr = null) {
        $serr = 'swe_house_pos bridge neni zatim implementovan pro ARMC vstup.';
        return 0.0;
    }
}

if (!function_exists('swetest_extra_selftest')) {
    function swetest_extra_selftest() {
        $tests = array();
        $jd = swe_julday(2000, 1, 1, 12.0, SE_GREG_CAL);
        $tests[] = array('name' => 'swe_julday J2000', 'ok' => abs($jd - 2451545.0) < 1e-9, 'value' => $jd);
        $y = $m = $d = 0; $h = 0.0;
        swe_revjul(2451545.0, SE_GREG_CAL, $y, $m, $d, $h);
        $tests[] = array('name' => 'swe_revjul J2000', 'ok' => ($y == 2000 && $m == 1 && $d == 1 && abs($h - 12.0) < 1e-8), 'value' => array($y,$m,$d,$h));
        $tests[] = array('name' => 'swe_difdeg2n', 'ok' => abs(swe_difdeg2n(10, 350) - 20) < 1e-12, 'value' => swe_difdeg2n(10, 350));
        $tests[] = array('name' => 'swe_day_of_week', 'ok' => swe_day_of_week(2451544.5) === 5, 'value' => swe_day_of_week(2451544.5));
        $uy = $um = $ud = $uh = $umi = 0; $us = 0.0;
        swe_utc_time_zone(1963, 1, 24, 3, 6, 0.0, 1.0, $uy, $um, $ud, $uh, $umi, $us);
        $tests[] = array('name' => 'swe_utc_time_zone CET to UTC', 'ok' => ($uy == 1963 && $um == 1 && $ud == 24 && $uh == 2 && $umi == 6 && abs($us) < 1e-6), 'value' => array($uy,$um,$ud,$uh,$umi,$us));
        $dret = array(); $serr = '';
        $rc = swe_utc_to_jd(2000, 1, 1, 12, 0, 0.0, SE_GREG_CAL, $dret, $serr);
        $tests[] = array('name' => 'swe_utc_to_jd J2000', 'ok' => ($rc === SE_OK && count($dret) == 2 && abs($dret[1] - 2451545.0) < 1e-9 && $dret[0] > $dret[1]), 'value' => $dret, 'serr' => $serr);
        $dretLeap = array(); $serrLeap = '';
        $rcLeap = swe_utc_to_jd(2016, 12, 31, 23, 59, 60.0, SE_GREG_CAL, $dretLeap, $serrLeap);
        $tests[] = array('name' => 'leap second accepted 2016-12-31', 'ok' => ($rcLeap === SE_OK && count($dretLeap) == 2), 'value' => $dretLeap, 'serr' => $serrLeap);
        $dretBad = array(); $serrBad = '';
        $rcBad = swe_utc_to_jd(2017, 1, 1, 23, 59, 60.0, SE_GREG_CAL, $dretBad, $serrBad);
        $tests[] = array('name' => 'invalid leap second rejected', 'ok' => ($rcBad === SE_ERR), 'value' => $dretBad, 'serr' => $serrBad);
        $oldUserDef = $GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'];
        swe_set_delta_t_userdef(70.0 / 86400.0);
        $dt = swe_deltat(2451545.0);
        $tests[] = array('name' => 'swe_set_delta_t_userdef', 'ok' => abs($dt - 70.0 / 86400.0) < 1e-14, 'value' => $dt);
        $GLOBALS['SWETEST_EXTRA_DELTA_T_USERDEF'] = $oldUserDef;
        $candSedna = swe_asteroid_file_candidates(90377);
        $tests[] = array('name' => 'asteroid candidates Sedna 90377', 'ok' => ($candSedna === array('ast90/se90377.se1','ast90/se90377s.se1','se90377.se1','se90377s.se1')), 'value' => $candSedna);
        $candEris = swe_asteroid_file_candidates(136199);
        $tests[] = array('name' => 'asteroid candidates Eris 136199', 'ok' => ($candEris === array('ast136/s136199.se1','ast136/s136199s.se1','s136199.se1','s136199s.se1')), 'value' => $candEris);
        $ok = true;
        foreach ($tests as $t) { if (!$t['ok']) { $ok = false; break; } }
        return array('ok' => $ok, 'tests' => $tests);
    }
}
