# Notice

This package contains an experimental PHP implementation around Swiss Ephemeris
data formats and `swetest`-style calculation workflows.

Swiss Ephemeris is created and maintained by Astrodienst AG and its authors.
Swiss Ephemeris is distributed under a dual licensing model: GNU Affero General
Public License (AGPL) or Swiss Ephemeris Professional License.

Official Swiss Ephemeris references:

- https://www.astro.com/swisseph/
- https://www.astro.com/swisseph/swisseph.htm
- https://www.astro.com/swisseph/secont_e.pdf
- https://www.astro.com/ftp/swisseph/
- https://www.gnu.org/licenses/agpl-3.0.html

This package does not include Swiss Ephemeris `.se1` data files or native
Swiss Ephemeris binaries. Users must obtain data files from the official
distribution and comply with the license that applies to their use case.

License note: this package does not include Swiss Ephemeris `.se1` data files,
`swetest.exe`, or other native Swiss Ephemeris binaries. It also does not grant
any Swiss Ephemeris license rights. Users who apply the package in their own
software, distributed app, or public service must choose and comply with the
applicable Swiss Ephemeris license model themselves.

Development note: this package is a project-specific, AI-assisted PHP conversion
around Swiss Ephemeris / `swetest` workflows. Most of the technical conversion
was carried out with Codex under the project author's direction and review.
Cursor was also used with a selected Gemini model as a supporting tool. Google
Antigravity, Google's agentic development platform, was used mainly for result
checking and review of changes. In July 2026, Claude (Anthropic)
performed an independent line-by-line audit against the Swiss Ephemeris 2.10.03
C sources and a numeric verification against the official `swetest` 2.10.03
binary; the resulting fixes are included since version 0.1.3-preview (see
`CHANGELOG.md`).

Recommended release posture:

- preserve copyright and license notices;
- do not imply that this package is an official Astrodienst distribution;
- make clear that this is an experimental PHP port/helper, not the full official
  Swiss Ephemeris C library.
- make clear that third-party users must comply with their own applicable Swiss
  Ephemeris license model.

