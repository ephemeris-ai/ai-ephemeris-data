# Manifest

Package: swetest-php-0.1.3-preview

Included:

- src/swetest.php
- src/swetest_sweph_extra.php
- src/swetest_fixstars.php
- examples/quickstart.php
- README.md
- CHANGELOG.md
- LICENSE.md
- NOTICE.md
- VERSION
- ephe/README.md

Runtime:

- PHP 7.4 or newer
- tested with PHP 7.4.6

License note:

- This ZIP package does not include Swiss Ephemeris .se1 data files,
  swetest.exe, or other native Swiss Ephemeris binaries.
- This ZIP package does not grant any Swiss Ephemeris license rights.
- ZIP users must choose and comply with the applicable Swiss Ephemeris license
  model themselves.

Excluded:

- swetest.exe
- swetest64.exe
- Swiss Ephemeris .se1 data files
- application configuration
- private data
