# Changelog

## 0.1.3-preview (2026-07-10)

This release is the result of an independent line-by-line audit of the PHP
port against the Swiss Ephemeris **2.10.03** C sources, followed by a numeric
verification against the official `swetest` **2.10.03** binary. The audit and
the fixes below were carried out with **Claude (Anthropic)** under
the project author's direction and review.

Verification result: on a grid of 18 dates (years −500 … +2300) and 20 bodies
(Sun–Pluto, mean/true node, mean/osculating apogee, Chiron–Vesta), the PHP
output now agrees with the official binary within its printing precision:
longitudes and latitudes ≤ 0.0002", distances ≤ 5e-10 AU, house cusps
(Placidus/Koch/Regiomontanus/Porphyry/Whole-sign/Equal, incl. polar latitudes)
≤ 0.0002", Lahiri sidereal longitudes ≤ 0.009", daily speeds ≤ 1e-4 °/day
(speeds are derived numerically by design).

Fixes and improvements:

- Mean obliquity of the ecliptic now uses the Vondrák/Capitaine/Wallace 2011
  model (port of `swi_ldp_peps()`), which is the actual Swiss Ephemeris
  default — previously the IAU 2006 polynomial was used.
- `.se1` coefficient unpacking now reproduces the C integer divisions exactly
  (half-byte and quarter-byte packed coefficients no longer leak lower bits).
- Chebyshev evaluation term count (`neval`) now matches the C reference
  behaviour exactly.
- The Moon no longer receives gravitational light deflection, matching
  `app_pos_etc_moon()` in the C original.
- Mean node, true node, mean apogee, and osculating apogee now return proper
  geocentric distances (C formulas, including the osculating-ellipse node
  distance from `lunar_osc_elem()`).
- Added the DE431-fit correction tables for the mean lunar node and mean
  apogee (`corr_mean_node` / `corr_mean_apog`, 2×304 values). These are zero
  for the years 0–3000 and matter only outside that range (they removed a
  ~4.7" deviation at year −500).
- Sidereal time is now a full port of `swe_sidtime0()` with the default
  SEMOD_SIDT_LONGTERM model (ERA-based IERS 2010 expression with the 33-term
  non-polynomial part; `sidtime_long_term()` outside 1850–2050). House cusps
  now match the C reference to the printing precision.
- Houses: fixed a 180° Ascendant flip at polar latitudes in the Porphyry
  fallback used by Placidus/Koch/Porphyry, and in the "Aries = 1st house"
  system.

No public API changes: all function signatures and result array shapes are
unchanged. The only externally visible data change is that node/apogee
distances are now real values instead of 0.0.

## 0.1.2-preview (2026-07-02)

Earlier preview refinements of the core and helper modules (not tracked in
detail in this changelog).

## 0.1.1-preview (2026-06-25)

Earlier preview refinements (not tracked in detail in this changelog).

## 0.1.0-preview (2026-05-21)

First public preview.

