# Ephemeris Files

Place Swiss Ephemeris .se1 files in this directory, or pass another ephemeris
directory as the second argument to the PHP helper functions.

The release ZIP intentionally does not bundle .se1 data files. Download them
from the official Astrodienst Swiss Ephemeris distribution:

https://www.astro.com/ftp/swisseph/
