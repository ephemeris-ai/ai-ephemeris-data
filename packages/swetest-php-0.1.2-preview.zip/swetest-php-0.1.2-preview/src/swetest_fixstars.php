<?php
/**
 * Optional fixed-star helper for the pure PHP Swiss backend.
 *
 * This file intentionally lives outside swetest.php so the fixed-star catalog
 * is loaded only when a caller asks for stars.
 */

require_once __DIR__ . DIRECTORY_SEPARATOR . 'swetest.php';

if (!defined('SE_OK'))  define('SE_OK', 0);
if (!defined('SE_ERR')) define('SE_ERR', -1);
if (!defined('SE_FIXSTAR')) define('SE_FIXSTAR', -10);
if (!defined('SEFLG_TRUEPOS')) define('SEFLG_TRUEPOS', 16);
if (!defined('SEFLG_NONUT')) define('SEFLG_NONUT', 64);
if (!defined('SEFLG_SPEED')) define('SEFLG_SPEED', 256);
if (!defined('SEFLG_NOABERR')) define('SEFLG_NOABERR', 1024);
if (!defined('SEFLG_RADIANS')) define('SEFLG_RADIANS', 8192);
if (!defined('SEFLG_SIDEREAL')) define('SEFLG_SIDEREAL', 65536);

if (!function_exists('swetest_fixstar_catalog_path')) {
    function swetest_fixstar_catalog_path(?string $edir = null): string
    {
        $candidates = [];
        if ($edir !== null && trim($edir) !== '') {
            $edir = rtrim(str_replace('\\', '/', trim($edir)), '/');
            $candidates[] = $edir . '/sefstars.txt';
        }
        $candidates[] = __DIR__ . '/../ephe/sefstars.txt';
        $candidates[] = __DIR__ . '/sefstars.txt';
        foreach ($candidates as $path) {
            if (is_file($path)) {
                return str_replace('\\', '/', realpath($path) ?: $path);
            }
        }
        throw new RuntimeException('Nenalezen katalog stalic sefstars.txt.');
    }
}

if (!function_exists('swetest_fixstar_search_key')) {
    function swetest_fixstar_search_key(string $name): string
    {
        $name = trim($name);
        $name = str_replace(["\t", ' '], '', $name);
        return strtolower($name);
    }
}

if (!function_exists('swetest_fixstar_parse_record')) {
    /**
     * @return array<string,mixed>|null
     */
    function swetest_fixstar_parse_record(string $line, int $number): ?array
    {
        $cols = str_getcsv($line);
        if (count($cols) < 14) {
            return null;
        }

        $traditional = rtrim((string)$cols[0]);
        $bayer = trim((string)$cols[1]);
        $epochRaw = strtoupper(trim((string)$cols[2]));
        $epoch = $epochRaw === 'ICRS' ? 0.0 : (float)$epochRaw;

        $ra = (((float)$cols[3]) + ((float)$cols[4]) / 60.0 + ((float)$cols[5]) / 3600.0) * 15.0;
        $decDeg = (float)$cols[6];
        $decSign = strpos(trim((string)$cols[6]), '-') === false ? 1.0 : -1.0;
        if ($decSign < 0.0) {
            $dec = $decDeg - ((float)$cols[7]) / 60.0 - ((float)$cols[8]) / 3600.0;
        } else {
            $dec = $decDeg + ((float)$cols[7]) / 60.0 + ((float)$cols[8]) / 3600.0;
        }

        $cosDec = cos($dec * SweMath::DEG2RAD);
        if (abs($cosDec) < 1e-12) {
            $cosDec = $cosDec < 0.0 ? -1e-12 : 1e-12;
        }

        // sefstars.txt stores proper motion in 0.001"/year.
        // The RA value includes cos(dec), as in Swiss C fixstar_cut_string().
        $raPm = ((float)$cols[9]) / 10.0 / 3600.0 / $cosDec;  // deg / century
        $decPm = ((float)$cols[10]) / 10.0 / 3600.0;          // deg / century
        $parallaxArcsec = abs((float)$cols[12]) / 1000.0;
        $distanceAu = $parallaxArcsec > 0.0 ? 206264.80624709636 / $parallaxArcsec : 1000000000.0;

        return [
            'number' => $number,
            'traditional' => $traditional,
            'bayer' => $bayer,
            'name' => trim($traditional !== '' ? $traditional . ',' . $bayer : ',' . $bayer),
            'epoch' => $epoch,
            'epoch_raw' => $epochRaw,
            'ra_deg' => SweMath::norm360($ra),
            'dec_deg' => $dec,
            'ra_pm_deg_century' => $raPm,
            'dec_pm_deg_century' => $decPm,
            'radial_velocity_km_s' => (float)$cols[11],
            'parallax_arcsec' => $parallaxArcsec,
            'distance_au' => $distanceAu,
            'magnitude' => (float)$cols[13],
            'raw' => $line,
        ];
    }
}

if (!function_exists('swetest_fixstar_catalog')) {
    /**
     * @return array{records:array<int,array<string,mixed>>,name_index:array<string,int>,bayer_index:array<string,int>,number_index:array<int,int>}
     */
    function swetest_fixstar_catalog(?string $edir = null): array
    {
        static $cache = [];
        $path = swetest_fixstar_catalog_path($edir);
        if (isset($cache[$path])) {
            return $cache[$path];
        }

        $records = [];
        $nameIndex = [];
        $bayerIndex = [];
        $numberIndex = [];
        $lines = file($path, FILE_IGNORE_NEW_LINES);
        if (!is_array($lines)) {
            throw new RuntimeException('Katalog stalic nelze nacist: ' . $path);
        }

        $number = 0;
        foreach ($lines as $line) {
            $trim = trim((string)$line);
            if ($trim === '' || $trim[0] === '#') {
                continue;
            }
            $number++;
            $record = swetest_fixstar_parse_record((string)$line, $number);
            if ($record === null) {
                continue;
            }
            $idx = count($records);
            $records[] = $record;
            $numberIndex[$number] = $idx;

            $traditional = (string)$record['traditional'];
            if ($traditional !== '') {
                $key = swetest_fixstar_search_key($traditional);
                if (!isset($nameIndex[$key])) {
                    $nameIndex[$key] = $idx;
                }
            }

            $bayer = (string)$record['bayer'];
            if ($bayer !== '') {
                $key = ',' . swetest_fixstar_search_key($bayer);
                if (!isset($bayerIndex[$key])) {
                    $bayerIndex[$key] = $idx;
                }
            }
        }

        $cache[$path] = [
            'records' => $records,
            'name_index' => $nameIndex,
            'bayer_index' => $bayerIndex,
            'number_index' => $numberIndex,
        ];
        return $cache[$path];
    }
}

if (!function_exists('swetest_fixstars')) {
    /**
     * @return array<int,array<string,mixed>>
     */
    function swetest_fixstars(?string $edir = null): array
    {
        $catalog = swetest_fixstar_catalog($edir);
        return $catalog['records'];
    }
}

if (!function_exists('swetest_fixstar_find')) {
    /**
     * @return array<string,mixed>|null
     */
    function swetest_fixstar_find(string $name, ?string $edir = null): ?array
    {
        $catalog = swetest_fixstar_catalog($edir);
        $query = trim($name);
        if ($query === '') {
            return null;
        }

        if (preg_match('/^\d+$/', $query) === 1) {
            $num = (int)$query;
            if (isset($catalog['number_index'][$num])) {
                return $catalog['records'][$catalog['number_index'][$num]];
            }
            return null;
        }

        if ($query[0] === ',') {
            $key = ',' . swetest_fixstar_search_key(substr($query, 1));
            return isset($catalog['bayer_index'][$key]) ? $catalog['records'][$catalog['bayer_index'][$key]] : null;
        }

        $comma = strpos($query, ',');
        if ($comma !== false) {
            $query = substr($query, 0, $comma);
        }

        $key = swetest_fixstar_search_key($query);
        if (substr($key, -1) === '%') {
            $prefix = substr($key, 0, -1);
            foreach ($catalog['name_index'] as $candidate => $idx) {
                if (strncmp($candidate, $prefix, strlen($prefix)) === 0) {
                    return $catalog['records'][$idx];
                }
            }
            return null;
        }

        return isset($catalog['name_index'][$key]) ? $catalog['records'][$catalog['name_index'][$key]] : null;
    }
}

if (!function_exists('swetest_fixstar_options')) {
    /**
     * @param array<string,mixed>|string|float|int $input
     * @return array{jd_ut:float,sidereal:bool,true_pos:bool,no_aberr:bool,no_nutation:bool,edir:string}
     */
    function swetest_fixstar_options($input = [], ?string $edir = null): array
    {
        if (is_numeric($input) && !is_array($input)) {
            $jd = (float)$input;
            $opts = [
                'sidereal' => false,
                'truePos' => false,
                'noAberr' => false,
                'noNutation' => false,
                'edir' => swetest_normalize_ephe_dir($edir),
            ];
        } else {
            $args = swetest_build_args($input, $edir);
            $opts = SweAstroLongitudeCli::parseArgs($args);
            $jd = (float)$opts['jd'];
        }
        return [
            'jd_ut' => $jd,
            'sidereal' => (bool)$opts['sidereal'],
            'true_pos' => (bool)$opts['truePos'],
            'no_aberr' => (bool)$opts['noAberr'],
            'no_nutation' => (bool)$opts['noNutation'],
            'edir' => (string)$opts['edir'],
        ];
    }
}

if (!function_exists('swetest_fixstar_vector')) {
    /**
     * @param array<string,mixed> $record
     * @return array{0:float,1:float,2:float}
     */
    function swetest_fixstar_vector(array $record, float $jdEt): array
    {
        $epoch = (float)$record['epoch'];
        $epochJd = abs($epoch - 1950.0) < 0.1 ? 2433282.42345905 : 2451545.0;
        $tCent = ($jdEt - $epochJd) / 36525.0;

        $ra = SweMath::norm360((float)$record['ra_deg'] + (float)$record['ra_pm_deg_century'] * $tCent) * SweMath::DEG2RAD;
        $dec = ((float)$record['dec_deg'] + (float)$record['dec_pm_deg_century'] * $tCent) * SweMath::DEG2RAD;
        $dist = (float)$record['distance_au'];

        $cd = cos($dec);
        return [
            $dist * $cd * cos($ra),
            $dist * $cd * sin($ra),
            $dist * sin($dec),
        ];
    }
}

if (!function_exists('swetest_fixstar_position_at_jd')) {
    /**
     * @param array<string,mixed> $record
     * @param array<string,mixed> $opts
     * @return array{lon:float,lat:float,dist:float}
     */
    function swetest_fixstar_position_at_jd(array $record, float $jdUt, array $opts, SweSe1 $swe): array
    {
        $jdEt = $jdUt + SweMath::deltaTSeconds($jdUt) / 86400.0;
        $x = swetest_fixstar_vector($record, $jdEt);

        $earth = $swe->earthBaryState($jdEt);
        for ($i = 0; $i < 3; $i++) {
            $x[$i] -= $earth[$i];
        }
        $state = [$x[0], $x[1], $x[2], 0.0, 0.0, 0.0];

        if (empty($opts['true_pos'])) {
            $sun = $swe->sunBaryState($jdEt);
            $state = SweMath::deflectLight($state, $earth, $sun, 0.0);
            if (empty($opts['no_aberr'])) {
                $state = SweMath::aberrLight($state, $earth);
            }
        }

        $state = SweMath::frameBiasGcrsToJ2000($state);
        $state = SweMath::precessJ2000ToDate($state, $jdEt);
        if (empty($opts['no_nutation'])) {
            $nu = SweMath::nutationShort($jdEt);
            $state = SweMath::applyNutation($state, $jdEt);
            $ecl = SweMath::equToEclWithEps($state, $nu['epsTrue']);
        } else {
            $ecl = SweMath::equToEclWithEps($state, SweMath::meanObliquityDeg($jdEt) * SweMath::DEG2RAD);
        }

        if (!empty($opts['sidereal'])) {
            $ecl['lon'] = SweMath::norm360($ecl['lon'] - SweMath::ayanamshaLahiri($jdEt));
        }

        return $ecl;
    }
}

if (!function_exists('swetest_fixstar')) {
    /**
     * @param array<string,mixed>|string|float|int $input
     * @return array<string,mixed>
     */
    function swetest_fixstar(string $name, $input = [], ?string $edir = null): array
    {
        $opts = swetest_fixstar_options($input, $edir);
        $record = swetest_fixstar_find($name, $opts['edir']);
        if ($record === null) {
            throw new RuntimeException('Stalice nenalezena: ' . $name);
        }

        $swe = new SweSe1($opts['edir']);
        try {
            $jdUt = (float)$opts['jd_ut'];
            $pos = swetest_fixstar_position_at_jd($record, $jdUt, $opts, $swe);
            $h = 5.0;
            $prev = swetest_fixstar_position_at_jd($record, $jdUt - $h, $opts, $swe);
            $next = swetest_fixstar_position_at_jd($record, $jdUt + $h, $opts, $swe);
        } finally {
            $swe->close();
        }

        $z = swetest_zodiac_parts((float)$pos['lon']);
        return [
            'name' => (string)$record['name'],
            'traditional' => (string)$record['traditional'],
            'bayer' => (string)$record['bayer'],
            'number' => (int)$record['number'],
            'jd_ut' => $jdUt,
            'mode' => (!empty($opts['sidereal']) ? 'sidereal_lahiri' : 'tropical') . (!empty($opts['true_pos']) ? '_geometric' : '_apparent'),
            'longitude_deg' => (float)$pos['lon'],
            'latitude_deg' => (float)$pos['lat'],
            'distance_au' => (float)$pos['dist'],
            'speed_deg_per_day' => SweMath::norm180((float)$next['lon'] - (float)$prev['lon']) / (2.0 * $h),
            'latitude_speed_deg_per_day' => ((float)$next['lat'] - (float)$prev['lat']) / (2.0 * $h),
            'magnitude' => (float)$record['magnitude'],
            'epoch' => (string)$record['epoch_raw'],
        ] + $z;
    }
}

if (!function_exists('swetest_nearby_fixstars')) {
    /**
     * @param array<string,mixed>|string|float|int $input
     * @return array<int,array<string,mixed>>
     */
    function swetest_nearby_fixstars(float $longitude, float $orbDeg = 1.0, $input = [], ?string $edir = null, ?float $maxMagnitude = 5.0, int $limit = 50): array
    {
        $opts = swetest_fixstar_options($input, $edir);
        $records = swetest_fixstars($opts['edir']);
        $swe = new SweSe1($opts['edir']);
        $out = [];
        $seen = [];
        try {
            foreach ($records as $record) {
                if ($maxMagnitude !== null && (float)$record['magnitude'] > $maxMagnitude) {
                    continue;
                }
                $bayerKey = trim((string)$record['bayer']);
                $key = $bayerKey !== ''
                    ? ',' . swetest_fixstar_search_key($bayerKey)
                    : swetest_fixstar_search_key((string)$record['traditional']);
                if (isset($seen[$key])) {
                    continue;
                }
                $pos = swetest_fixstar_position_at_jd($record, (float)$opts['jd_ut'], $opts, $swe);
                $orb = SweMath::norm180((float)$pos['lon'] - $longitude);
                if (abs($orb) > $orbDeg) {
                    continue;
                }
                $seen[$key] = true;
                $z = swetest_zodiac_parts((float)$pos['lon']);
                $out[] = [
                    'name' => (string)$record['name'],
                    'traditional' => (string)$record['traditional'],
                    'bayer' => (string)$record['bayer'],
                    'longitude_deg' => (float)$pos['lon'],
                    'latitude_deg' => (float)$pos['lat'],
                    'orb_deg' => $orb,
                    'orb_abs_deg' => abs($orb),
                    'magnitude' => (float)$record['magnitude'],
                ] + $z;
            }
        } finally {
            $swe->close();
        }

        usort($out, static function (array $a, array $b): int {
            if ($a['orb_abs_deg'] == $b['orb_abs_deg']) {
                return $a['magnitude'] <=> $b['magnitude'];
            }
            return $a['orb_abs_deg'] <=> $b['orb_abs_deg'];
        });

        return array_slice($out, 0, max(1, $limit));
    }
}

if (!function_exists('swetest_fixstar_text')) {
    /**
     * @param array<string,mixed>|string|float|int $input
     */
    function swetest_fixstar_text(string $name, $input = [], ?string $edir = null): string
    {
        $r = swetest_fixstar($name, $input, $edir);
        return sprintf(
            '%s  %s  lon=%.10f  lat=%+.10f  speed=%+.8f deg/day  mag=%.2f  %s',
            $r['name'],
            $r['position_cz'],
            (float)$r['longitude_deg'],
            (float)$r['latitude_deg'],
            (float)$r['speed_deg_per_day'],
            (float)$r['magnitude'],
            (string)$r['mode']
        );
    }
}

if (!function_exists('swe_fixstar_ut')) {
    function swe_fixstar_ut(&$star, $tjd_ut, $iflag, &$xx, &$serr = null) {
        $serr = '';
        $xx = array_fill(0, 6, 0.0);
        try {
            $r = swetest_fixstar((string)$star, [
                'jd' => (float)$tjd_ut,
                'sidereal' => (((int)$iflag & SEFLG_SIDEREAL) !== 0),
                'geometric' => (((int)$iflag & SEFLG_TRUEPOS) !== 0),
                'noaberr' => (((int)$iflag & SEFLG_NOABERR) !== 0),
                'nonut' => (((int)$iflag & SEFLG_NONUT) !== 0),
            ]);
            $star = (string)$r['name'];
            $xx[0] = (float)$r['longitude_deg'];
            $xx[1] = (float)$r['latitude_deg'];
            $xx[2] = (float)$r['distance_au'];
            $xx[3] = (((int)$iflag & SEFLG_SPEED) !== 0) ? (float)$r['speed_deg_per_day'] : 0.0;
            $xx[4] = (((int)$iflag & SEFLG_SPEED) !== 0) ? (float)$r['latitude_speed_deg_per_day'] : 0.0;
            $xx[5] = 0.0;
            if (((int)$iflag & SEFLG_RADIANS) !== 0) {
                $xx[0] = deg2rad($xx[0]);
                $xx[1] = deg2rad($xx[1]);
                $xx[3] = deg2rad($xx[3]);
                $xx[4] = deg2rad($xx[4]);
            }
            return (int)$iflag;
        } catch (Throwable $e) {
            $serr = $e->getMessage();
            return SE_ERR;
        }
    }
}

if (!function_exists('swe_fixstar')) {
    function swe_fixstar(&$star, $tjd_et, $iflag, &$xx, &$serr = null) {
        $dt = SweMath::deltaTSeconds((float)$tjd_et) / 86400.0;
        $tjdUt = (float)$tjd_et - $dt;
        return swe_fixstar_ut($star, $tjdUt, $iflag, $xx, $serr);
    }
}

if (!function_exists('swe_fixstar_mag')) {
    function swe_fixstar_mag($star, &$mag, &$serr = null) {
        $serr = '';
        $record = swetest_fixstar_find((string)$star);
        if ($record === null) {
            $mag = 0.0;
            $serr = 'Stalice nenalezena: ' . (string)$star;
            return SE_ERR;
        }
        $mag = (float)$record['magnitude'];
        return SE_OK;
    }
}
