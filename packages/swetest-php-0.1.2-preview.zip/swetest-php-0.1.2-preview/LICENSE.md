# License

This preview package contains an experimental PHP implementation around Swiss
Ephemeris data formats and `swetest`-style workflows.

SPDX-License-Identifier: LicenseRef-Swiss-Ephemeris-Dual-License-Notice

Swiss Ephemeris itself is distributed by Astrodienst under a dual licensing
model:

- GNU Affero General Public License (AGPL)
- Swiss Ephemeris Professional License

Before distributing this package or activating a public service that uses it,
review the official Swiss Ephemeris licensing terms and choose the license model
that applies to your project.

This ZIP package does not include Swiss Ephemeris `.se1` data files,
`swetest.exe`, or other native Swiss Ephemeris binaries. It also does not grant
any Swiss Ephemeris license rights. Users who apply the package in their own
software, distributed app, or public service must choose and comply with the
applicable Swiss Ephemeris license model themselves.

Official references:

- https://www.astro.com/swisseph/
- https://www.astro.com/swisseph/swisseph.htm
- https://www.astro.com/swisseph/secont_e.pdf
- https://www.gnu.org/licenses/agpl-3.0.html

No warranty is provided. Validate all results against the official Swiss
Ephemeris tools before relying on them in production.
