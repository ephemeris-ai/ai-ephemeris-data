<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/swetest.php';

$epheDir = dirname(__DIR__) . '/ephe';

if (!is_dir($epheDir)) {
    fwrite(STDERR, "Missing ephemeris directory: {$epheDir}\n");
    fwrite(STDERR, "Create it and add Swiss Ephemeris .se1 files from Astrodienst.\n");
    exit(1);
}

$chart = swetest_full_chart([
    'date' => '24.1.1963',
    'ut' => '02:06',
    'bodies' => '0123456789mtAB',
    'decimal' => true,
    'house' => [
        'longitude' => 14.42076,
        'latitude' => 50.08804,
        'system' => 'P',
    ],
], $epheDir);

echo json_encode(
    $chart,
    JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
) . PHP_EOL;

